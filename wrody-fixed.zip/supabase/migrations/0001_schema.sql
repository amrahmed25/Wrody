-- ============================================================================
-- Wrody (ورودي) — 0001 core schema
-- Handmade pipe-cleaner flower store.
-- Apply order: 0001_schema -> 0002_functions -> 0003_rls -> 0004_storage -> seed
-- ============================================================================

create extension if not exists pgcrypto;
create extension if not exists pg_trgm;
create extension if not exists citext;

-- ----------------------------------------------------------------------------
-- Enums
-- ----------------------------------------------------------------------------
do $$ begin create type public.user_role as enum ('customer','admin'); exception when duplicate_object then null; end $$;
do $$ begin create type public.order_status as enum ('pending','confirmed','preparing','out_for_delivery','delivered','cancelled'); exception when duplicate_object then null; end $$;
do $$ begin create type public.payment_status as enum ('pending','paid','failed','refunded'); exception when duplicate_object then null; end $$;
do $$ begin create type public.payment_method as enum ('cod','card','wallet'); exception when duplicate_object then null; end $$;
do $$ begin create type public.discount_type as enum ('percentage','fixed'); exception when duplicate_object then null; end $$;
do $$ begin create type public.bouquet_option_kind as enum ('size','wrapping','card'); exception when duplicate_object then null; end $$;
do $$ begin create type public.custom_bouquet_status as enum ('draft','in_cart','ordered','in_production','completed','cancelled'); exception when duplicate_object then null; end $$;

-- ----------------------------------------------------------------------------
-- profiles (1:1 with auth.users, created by trigger)
-- ----------------------------------------------------------------------------
create table if not exists public.profiles (
	id uuid primary key references auth.users(id) on delete cascade,
	full_name text,
	email citext,
	phone text,
	avatar_url text,
	role public.user_role not null default 'customer',
	created_at timestamptz not null default now(),
	updated_at timestamptz not null default now(),
	constraint profiles_full_name_len check (full_name is null or char_length(full_name) between 2 and 120),
	constraint profiles_phone_fmt check (phone is null or phone ~ '^[0-9+ -]{8,20}$')
);
create index if not exists profiles_role_idx on public.profiles (role);

-- ----------------------------------------------------------------------------
-- categories
-- ----------------------------------------------------------------------------
create table if not exists public.categories (
	id uuid primary key default gen_random_uuid(),
	name text not null,
	slug text not null unique,
	description text,
	image_url text,
	sort_order int not null default 0,
	is_active boolean not null default true,
	created_at timestamptz not null default now(),
	updated_at timestamptz not null default now(),
	constraint categories_slug_fmt check (slug ~ '^[a-z0-9-]+$')
);
create index if not exists categories_active_idx on public.categories (is_active, sort_order);

-- ----------------------------------------------------------------------------
-- products
-- ----------------------------------------------------------------------------
create table if not exists public.products (
	id uuid primary key default gen_random_uuid(),
	category_id uuid references public.categories(id) on delete set null,
	name text not null,
	slug text not null unique,
	description text,
	short_description text,
	price numeric(10,2) not null check (price >= 0),
	compare_at_price numeric(10,2) check (compare_at_price is null or compare_at_price >= 0),
	stock int not null default 0 check (stock >= 0),
	sku text unique,
	is_active boolean not null default true,
	is_featured boolean not null default false,
	is_best_seller boolean not null default false,
	sales_count int not null default 0 check (sales_count >= 0),
	rating_avg numeric(3,2) not null default 0 check (rating_avg between 0 and 5),
	rating_count int not null default 0 check (rating_count >= 0),
	created_at timestamptz not null default now(),
	updated_at timestamptz not null default now(),
	search_vector tsvector generated always as (
		to_tsvector('simple'::regconfig,
			coalesce(name,'') || ' ' || coalesce(short_description,'') || ' ' || coalesce(description,''))
	) stored,
	constraint products_slug_fmt check (slug ~ '^[a-z0-9-]+$'),
	constraint products_compare_gt_price check (compare_at_price is null or compare_at_price >= price)
);
create index if not exists products_slug_idx on public.products (slug);
create index if not exists products_category_idx on public.products (category_id);
create index if not exists products_active_created_idx on public.products (is_active, created_at desc);
create index if not exists products_featured_idx on public.products (is_featured) where is_active;
create index if not exists products_best_seller_idx on public.products (is_best_seller) where is_active;
create index if not exists products_price_idx on public.products (price);
create index if not exists products_sales_idx on public.products (sales_count desc);
create index if not exists products_search_idx on public.products using gin (search_vector);
create index if not exists products_name_trgm_idx on public.products using gin (name gin_trgm_ops);

-- ----------------------------------------------------------------------------
-- product_images
-- ----------------------------------------------------------------------------
create table if not exists public.product_images (
	id uuid primary key default gen_random_uuid(),
	product_id uuid not null references public.products(id) on delete cascade,
	image_url text not null,
	alt_text text,
	sort_order int not null default 0,
	created_at timestamptz not null default now()
);
create index if not exists product_images_product_idx on public.product_images (product_id, sort_order);

-- ----------------------------------------------------------------------------
-- product_variants
-- `options` keeps multiple attributes (color / size / wrapping / bouquet size)
-- in one normalised row: {"اللون":"وردي","المقاس":"وسط"} — no attribute-table sprawl.
-- price NULL => inherit the parent product price (single source of truth).
-- ----------------------------------------------------------------------------
create table if not exists public.product_variants (
	id uuid primary key default gen_random_uuid(),
	product_id uuid not null references public.products(id) on delete cascade,
	name text not null,
	options jsonb not null default '{}'::jsonb,
	sku text unique,
	price numeric(10,2) check (price is null or price >= 0),
	stock int not null default 0 check (stock >= 0),
	sort_order int not null default 0,
	is_active boolean not null default true,
	created_at timestamptz not null default now(),
	updated_at timestamptz not null default now(),
	unique (product_id, name),
	constraint product_variants_options_obj check (jsonb_typeof(options) = 'object')
);
create index if not exists product_variants_product_idx on public.product_variants (product_id, sort_order);
create index if not exists product_variants_options_idx on public.product_variants using gin (options);

-- ----------------------------------------------------------------------------
-- custom bouquet catalogue (flowers + size/wrapping/card options)
-- Prices live in the DB so the server is always the pricing authority.
-- ----------------------------------------------------------------------------
create table if not exists public.bouquet_flowers (
	id uuid primary key default gen_random_uuid(),
	name text not null,
	slug text not null unique,
	color text,
	image_url text,
	unit_price numeric(10,2) not null check (unit_price >= 0),
	is_active boolean not null default true,
	sort_order int not null default 0,
	created_at timestamptz not null default now(),
	updated_at timestamptz not null default now()
);

create table if not exists public.bouquet_options (
	id uuid primary key default gen_random_uuid(),
	kind public.bouquet_option_kind not null,
	name text not null,
	slug text not null,
	description text,
	image_url text,
	price numeric(10,2) not null default 0 check (price >= 0),
	min_flowers int check (min_flowers is null or min_flowers >= 0),
	max_flowers int check (max_flowers is null or max_flowers >= 0),
	is_active boolean not null default true,
	sort_order int not null default 0,
	created_at timestamptz not null default now(),
	updated_at timestamptz not null default now(),
	unique (kind, slug)
);

create table if not exists public.custom_bouquets (
	id uuid primary key default gen_random_uuid(),
	user_id uuid references public.profiles(id) on delete set null,
	session_id text,
	size_slug text not null,
	wrapping_slug text not null,
	card_slug text,
	message text,
	items jsonb not null default '[]'::jsonb,
	breakdown jsonb not null default '{}'::jsonb,
	total_price numeric(10,2) not null check (total_price >= 0),
	status public.custom_bouquet_status not null default 'draft',
	order_id uuid,
	created_at timestamptz not null default now(),
	updated_at timestamptz not null default now(),
	constraint custom_bouquets_items_arr check (jsonb_typeof(items) = 'array'),
	constraint custom_bouquets_message_len check (message is null or char_length(message) <= 300)
);
create index if not exists custom_bouquets_user_idx on public.custom_bouquets (user_id, created_at desc);
create index if not exists custom_bouquets_status_idx on public.custom_bouquets (status, created_at desc);

-- ----------------------------------------------------------------------------
-- coupons
-- ----------------------------------------------------------------------------
create table if not exists public.coupons (
	id uuid primary key default gen_random_uuid(),
	code text not null unique,
	description text,
	discount_type public.discount_type not null,
	discount_value numeric(10,2) not null check (discount_value > 0),
	minimum_order numeric(10,2) check (minimum_order is null or minimum_order >= 0),
	maximum_discount numeric(10,2) check (maximum_discount is null or maximum_discount >= 0),
	usage_limit int check (usage_limit is null or usage_limit > 0),
	usage_limit_per_user int check (usage_limit_per_user is null or usage_limit_per_user > 0),
	usage_count int not null default 0 check (usage_count >= 0),
	starts_at timestamptz,
	expires_at timestamptz,
	is_active boolean not null default true,
	created_at timestamptz not null default now(),
	updated_at timestamptz not null default now(),
	constraint coupons_code_fmt check (code = upper(code) and char_length(code) between 3 and 32),
	constraint coupons_percentage_range check (discount_type <> 'percentage' or discount_value <= 100)
);
create unique index if not exists coupons_code_idx on public.coupons (code);

-- ----------------------------------------------------------------------------
-- carts (guest carts use session_id, customer carts use user_id)
-- ----------------------------------------------------------------------------
create table if not exists public.carts (
	id uuid primary key default gen_random_uuid(),
	user_id uuid references public.profiles(id) on delete cascade,
	session_id text,
	created_at timestamptz not null default now(),
	updated_at timestamptz not null default now(),
	constraint carts_owner_check check (num_nonnulls(user_id, session_id) = 1)
);
create unique index if not exists carts_user_idx on public.carts (user_id) where user_id is not null;
create unique index if not exists carts_session_idx on public.carts (session_id) where session_id is not null;

create table if not exists public.cart_items (
	id uuid primary key default gen_random_uuid(),
	cart_id uuid not null references public.carts(id) on delete cascade,
	product_id uuid references public.products(id) on delete cascade,
	variant_id uuid references public.product_variants(id) on delete cascade,
	custom_bouquet_id uuid references public.custom_bouquets(id) on delete cascade,
	quantity int not null default 1 check (quantity between 1 and 99),
	created_at timestamptz not null default now(),
	updated_at timestamptz not null default now(),
	constraint cart_items_target_check check (num_nonnulls(product_id, custom_bouquet_id) = 1),
	constraint cart_items_variant_check check (custom_bouquet_id is null or variant_id is null)
);
create index if not exists cart_items_cart_idx on public.cart_items (cart_id);
-- one row per (cart, product, variant) for catalogue products; bouquets stay unique rows
create unique index if not exists cart_items_unique_product_idx
	on public.cart_items (cart_id, product_id, coalesce(variant_id, '00000000-0000-0000-0000-000000000000'::uuid))
	where custom_bouquet_id is null;

-- ----------------------------------------------------------------------------
-- addresses
-- ----------------------------------------------------------------------------
create table if not exists public.addresses (
	id uuid primary key default gen_random_uuid(),
	user_id uuid not null references public.profiles(id) on delete cascade,
	full_name text not null,
	phone text not null,
	city text not null,
	area text not null,
	street text not null,
	building text,
	floor text,
	apartment text,
	additional_info text,
	is_default boolean not null default false,
	created_at timestamptz not null default now(),
	updated_at timestamptz not null default now()
);
create index if not exists addresses_user_idx on public.addresses (user_id);
create unique index if not exists addresses_single_default_idx on public.addresses (user_id) where is_default;

-- ----------------------------------------------------------------------------
-- delivery zones + settings (admin managed store configuration)
-- ----------------------------------------------------------------------------
create table if not exists public.delivery_zones (
	id uuid primary key default gen_random_uuid(),
	city text not null unique,
	fee numeric(10,2) not null check (fee >= 0),
	estimated_days text,
	is_active boolean not null default true,
	sort_order int not null default 0,
	created_at timestamptz not null default now(),
	updated_at timestamptz not null default now()
);

create table if not exists public.site_settings (
	key text primary key,
	value jsonb not null default '{}'::jsonb,
	is_public boolean not null default true,
	updated_at timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- orders (+ immutable snapshots) — order_number is separate from the UUID
-- ----------------------------------------------------------------------------
create table if not exists public.order_counters (
	year int primary key,
	last_number bigint not null default 0
);

create table if not exists public.orders (
	id uuid primary key default gen_random_uuid(),
	order_number text not null unique,
	user_id uuid references public.profiles(id) on delete set null,
	status public.order_status not null default 'pending',
	payment_method public.payment_method not null default 'cod',
	payment_status public.payment_status not null default 'pending',
	subtotal numeric(10,2) not null check (subtotal >= 0),
	delivery_fee numeric(10,2) not null default 0 check (delivery_fee >= 0),
	discount numeric(10,2) not null default 0 check (discount >= 0),
	total numeric(10,2) not null check (total >= 0),
	coupon_code text,
	coupon_id uuid references public.coupons(id) on delete set null,
	customer_name text not null,
	customer_phone text not null,
	customer_email text,
	shipping_address_snapshot jsonb not null,
	notes text,
	idempotency_key text unique,
	stock_restored boolean not null default false,
	payment_reference text,
	created_at timestamptz not null default now(),
	updated_at timestamptz not null default now()
);
create index if not exists orders_user_idx on public.orders (user_id, created_at desc);
create index if not exists orders_status_idx on public.orders (status, created_at desc);
create index if not exists orders_created_idx on public.orders (created_at desc);
create index if not exists orders_number_idx on public.orders (order_number);
create index if not exists orders_phone_idx on public.orders (customer_phone);

create table if not exists public.order_items (
	id uuid primary key default gen_random_uuid(),
	order_id uuid not null references public.orders(id) on delete cascade,
	product_id uuid references public.products(id) on delete set null,
	variant_id uuid references public.product_variants(id) on delete set null,
	custom_bouquet_id uuid references public.custom_bouquets(id) on delete set null,
	product_name text not null,
	variant_name text,
	image_url text,
	custom_bouquet jsonb,
	quantity int not null check (quantity > 0),
	unit_price numeric(10,2) not null check (unit_price >= 0),
	total_price numeric(10,2) not null check (total_price >= 0),
	created_at timestamptz not null default now()
);
create index if not exists order_items_order_idx on public.order_items (order_id);
create index if not exists order_items_product_idx on public.order_items (product_id);

create table if not exists public.order_events (
	id uuid primary key default gen_random_uuid(),
	order_id uuid not null references public.orders(id) on delete cascade,
	status public.order_status not null,
	note text,
	created_by uuid references public.profiles(id) on delete set null,
	created_at timestamptz not null default now()
);
create index if not exists order_events_order_idx on public.order_events (order_id, created_at);

create table if not exists public.coupon_redemptions (
	id uuid primary key default gen_random_uuid(),
	coupon_id uuid not null references public.coupons(id) on delete cascade,
	order_id uuid not null references public.orders(id) on delete cascade,
	user_id uuid references public.profiles(id) on delete set null,
	created_at timestamptz not null default now(),
	unique (coupon_id, order_id)
);
create index if not exists coupon_redemptions_user_idx on public.coupon_redemptions (coupon_id, user_id);

-- custom_bouquets.order_id FK (declared after orders exists)
do $$ begin
	alter table public.custom_bouquets
		add constraint custom_bouquets_order_fk foreign key (order_id) references public.orders(id) on delete set null;
exception when duplicate_object then null; end $$;

-- ----------------------------------------------------------------------------
-- reviews + wishlist
-- ----------------------------------------------------------------------------
create table if not exists public.reviews (
	id uuid primary key default gen_random_uuid(),
	user_id uuid not null references public.profiles(id) on delete cascade,
	product_id uuid not null references public.products(id) on delete cascade,
	order_id uuid references public.orders(id) on delete set null,
	rating int not null check (rating between 1 and 5),
	comment text check (comment is null or char_length(comment) <= 1000),
	is_approved boolean not null default false,
	created_at timestamptz not null default now(),
	updated_at timestamptz not null default now(),
	unique (user_id, product_id)
);
create index if not exists reviews_product_idx on public.reviews (product_id, is_approved, created_at desc);
create index if not exists reviews_user_idx on public.reviews (user_id);

create table if not exists public.wishlist (
	id uuid primary key default gen_random_uuid(),
	user_id uuid not null references public.profiles(id) on delete cascade,
	product_id uuid not null references public.products(id) on delete cascade,
	created_at timestamptz not null default now(),
	unique (user_id, product_id)
);
create index if not exists wishlist_user_idx on public.wishlist (user_id, created_at desc);

-- ----------------------------------------------------------------------------
-- Table privileges.
-- PostgREST authorises through RLS, but privileges are the first gate:
-- carts, cart_items, coupon_redemptions and order_counters are never exposed
-- to anon/authenticated — they are only touched by trusted server code.
-- ----------------------------------------------------------------------------
revoke all on all tables in schema public from anon, authenticated;

grant select on public.categories, public.products, public.product_images, public.product_variants,
	public.bouquet_flowers, public.bouquet_options, public.delivery_zones, public.site_settings,
	public.reviews to anon, authenticated;

grant select, insert, update on public.profiles to authenticated;
grant select, insert, update, delete on public.addresses, public.wishlist to authenticated;
grant select, insert, update on public.reviews to authenticated;
grant select on public.orders, public.order_items, public.order_events, public.custom_bouquets,
	public.coupons to authenticated;

-- Admin write paths (each one is still gated by an is_admin() RLS policy)
grant insert, update, delete on public.categories, public.products, public.product_images,
	public.product_variants, public.coupons, public.bouquet_flowers, public.bouquet_options,
	public.delivery_zones, public.site_settings to authenticated;
grant update, delete on public.orders, public.custom_bouquets, public.reviews to authenticated;
grant insert on public.order_events to authenticated;
