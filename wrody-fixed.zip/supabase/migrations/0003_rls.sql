-- ============================================================================
-- Wrody — 0003 Row Level Security
-- Rule of thumb:
--   * public may read ACTIVE catalogue content only
--   * a customer may read/write ONLY their own rows
--   * only admins may write catalogue, orders, coupons and settings
--   * carts/cart_items/coupon_redemptions/order_counters have no anon or
--     authenticated privileges at all (trusted server code only)
-- ============================================================================

alter table public.profiles            enable row level security;
alter table public.categories          enable row level security;
alter table public.products            enable row level security;
alter table public.product_images      enable row level security;
alter table public.product_variants    enable row level security;
alter table public.bouquet_flowers     enable row level security;
alter table public.bouquet_options     enable row level security;
alter table public.custom_bouquets     enable row level security;
alter table public.coupons             enable row level security;
alter table public.coupon_redemptions  enable row level security;
alter table public.carts               enable row level security;
alter table public.cart_items          enable row level security;
alter table public.addresses           enable row level security;
alter table public.delivery_zones      enable row level security;
alter table public.site_settings       enable row level security;
alter table public.orders              enable row level security;
alter table public.order_items         enable row level security;
alter table public.order_events        enable row level security;
alter table public.order_counters      enable row level security;
alter table public.reviews             enable row level security;
alter table public.wishlist            enable row level security;

-- ---------------------------------------------------------------- profiles --
drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select to authenticated
	using (id = auth.uid() or public.is_admin());

drop policy if exists profiles_insert on public.profiles;
create policy profiles_insert on public.profiles for insert to authenticated
	with check (id = auth.uid());

-- role changes are reverted by the protect_profile_role() trigger
drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles for update to authenticated
	using (id = auth.uid() or public.is_admin())
	with check (id = auth.uid() or public.is_admin());

-- ------------------------------------------------------- catalogue (read) --
drop policy if exists categories_read on public.categories;
create policy categories_read on public.categories for select to anon, authenticated
	using (is_active or public.is_admin());

drop policy if exists products_read on public.products;
create policy products_read on public.products for select to anon, authenticated
	using (is_active or public.is_admin());

drop policy if exists product_images_read on public.product_images;
create policy product_images_read on public.product_images for select to anon, authenticated
	using (exists (select 1 from public.products p
	                where p.id = product_images.product_id and (p.is_active or public.is_admin())));

drop policy if exists product_variants_read on public.product_variants;
create policy product_variants_read on public.product_variants for select to anon, authenticated
	using (exists (select 1 from public.products p
	                where p.id = product_variants.product_id and (p.is_active or public.is_admin()))
	       and (is_active or public.is_admin()));

drop policy if exists bouquet_flowers_read on public.bouquet_flowers;
create policy bouquet_flowers_read on public.bouquet_flowers for select to anon, authenticated
	using (is_active or public.is_admin());

drop policy if exists bouquet_options_read on public.bouquet_options;
create policy bouquet_options_read on public.bouquet_options for select to anon, authenticated
	using (is_active or public.is_admin());

drop policy if exists delivery_zones_read on public.delivery_zones;
create policy delivery_zones_read on public.delivery_zones for select to anon, authenticated
	using (is_active or public.is_admin());

drop policy if exists site_settings_read on public.site_settings;
create policy site_settings_read on public.site_settings for select to anon, authenticated
	using (is_public or public.is_admin());

-- ------------------------------------------------------ catalogue (write) --
do $$
declare t text;
begin
	foreach t in array array['categories','products','product_images','product_variants',
	                         'bouquet_flowers','bouquet_options','delivery_zones','site_settings'] loop
		execute format('drop policy if exists %I on public.%I', t || '_admin_write', t);
		execute format($p$create policy %I on public.%I for all to authenticated
			using (public.is_admin()) with check (public.is_admin())$p$, t || '_admin_write', t);
	end loop;
end $$;

-- --------------------------------------------------------------- coupons --
drop policy if exists coupons_admin_all on public.coupons;
create policy coupons_admin_all on public.coupons for all to authenticated
	using (public.is_admin()) with check (public.is_admin());
-- NOTE: customers never read coupons directly; validation happens through the
-- evaluate_coupon() RPC executed by trusted server code.

-- ------------------------------------------------------------- addresses --
drop policy if exists addresses_own on public.addresses;
create policy addresses_own on public.addresses for all to authenticated
	using (user_id = auth.uid()) with check (user_id = auth.uid());

-- -------------------------------------------------------------- wishlist --
drop policy if exists wishlist_own on public.wishlist;
create policy wishlist_own on public.wishlist for all to authenticated
	using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ---------------------------------------------------------------- orders --
drop policy if exists orders_read_own on public.orders;
create policy orders_read_own on public.orders for select to authenticated
	using (user_id = auth.uid() or public.is_admin());

drop policy if exists orders_admin_write on public.orders;
create policy orders_admin_write on public.orders for update to authenticated
	using (public.is_admin()) with check (public.is_admin());

drop policy if exists orders_admin_delete on public.orders;
create policy orders_admin_delete on public.orders for delete to authenticated
	using (public.is_admin());
-- Orders are created exclusively by the place_order() RPC (service role):
-- there is intentionally no INSERT policy for customers.

drop policy if exists order_items_read on public.order_items;
create policy order_items_read on public.order_items for select to authenticated
	using (exists (select 1 from public.orders o
	                where o.id = order_items.order_id
	                  and (o.user_id = auth.uid() or public.is_admin())));

drop policy if exists order_events_read on public.order_events;
create policy order_events_read on public.order_events for select to authenticated
	using (exists (select 1 from public.orders o
	                where o.id = order_events.order_id
	                  and (o.user_id = auth.uid() or public.is_admin())));

drop policy if exists order_events_admin_insert on public.order_events;
create policy order_events_admin_insert on public.order_events for insert to authenticated
	with check (public.is_admin());

-- --------------------------------------------------------------- reviews --
drop policy if exists reviews_read on public.reviews;
create policy reviews_read on public.reviews for select to anon, authenticated
	using (is_approved or user_id = auth.uid() or public.is_admin());

-- Only a customer who actually received the product can write a review.
drop policy if exists reviews_insert_purchased on public.reviews;
create policy reviews_insert_purchased on public.reviews for insert to authenticated
	with check (
		user_id = auth.uid()
		and exists (
			select 1 from public.orders o
			  join public.order_items oi on oi.order_id = o.id
			 where o.user_id = auth.uid()
			   and oi.product_id = reviews.product_id
			   and o.status = 'delivered'
			   and (reviews.order_id is null or o.id = reviews.order_id)
		)
	);

drop policy if exists reviews_update on public.reviews;
create policy reviews_update on public.reviews for update to authenticated
	using (user_id = auth.uid() or public.is_admin())
	with check (user_id = auth.uid() or public.is_admin());

drop policy if exists reviews_delete on public.reviews;
create policy reviews_delete on public.reviews for delete to authenticated
	using (public.is_admin());

-- ------------------------------------------------------- custom bouquets --
drop policy if exists custom_bouquets_read on public.custom_bouquets;
create policy custom_bouquets_read on public.custom_bouquets for select to authenticated
	using (user_id = auth.uid() or public.is_admin());

drop policy if exists custom_bouquets_admin_write on public.custom_bouquets;
create policy custom_bouquets_admin_write on public.custom_bouquets for update to authenticated
	using (public.is_admin()) with check (public.is_admin());

-- --------------------------------------------------- server-only surfaces --
-- carts, cart_items, coupon_redemptions and order_counters have RLS enabled
-- and NO policies: anon/authenticated can never touch them (they also hold no
-- table privileges). Only the service role, used by validated server actions,
-- bypasses RLS for these tables.
