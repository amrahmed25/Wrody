-- ============================================================================
-- Wrody — 0004 Supabase Storage buckets and policies
-- Buckets are public for READ (product photography is public content) but only
-- admins may write to catalogue buckets. Avatars are writable by their owner
-- inside a folder named after the user id.
-- ============================================================================

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
	('product-images', 'product-images', true, 5242880,
		array['image/jpeg','image/png','image/webp','image/avif','image/svg+xml']),
	('category-images', 'category-images', true, 5242880,
		array['image/jpeg','image/png','image/webp','image/avif','image/svg+xml']),
	('avatars', 'avatars', true, 2097152,
		array['image/jpeg','image/png','image/webp','image/avif'])
on conflict (id) do update
	set public = excluded.public,
	    file_size_limit = excluded.file_size_limit,
	    allowed_mime_types = excluded.allowed_mime_types;

-- ---------------------------------------------------------------- read ------
drop policy if exists "wrody public read" on storage.objects;
create policy "wrody public read" on storage.objects for select to anon, authenticated
	using (bucket_id in ('product-images', 'category-images', 'avatars'));

-- --------------------------------------------------- catalogue write (admin) --
drop policy if exists "wrody admin upload" on storage.objects;
create policy "wrody admin upload" on storage.objects for insert to authenticated
	with check (bucket_id in ('product-images', 'category-images') and public.is_admin());

drop policy if exists "wrody admin update" on storage.objects;
create policy "wrody admin update" on storage.objects for update to authenticated
	using (bucket_id in ('product-images', 'category-images') and public.is_admin())
	with check (bucket_id in ('product-images', 'category-images') and public.is_admin());

drop policy if exists "wrody admin delete" on storage.objects;
create policy "wrody admin delete" on storage.objects for delete to authenticated
	using (bucket_id in ('product-images', 'category-images') and public.is_admin());

-- ------------------------------------------------------- avatars (owner) ----
-- Path convention: avatars/<auth.uid()>/<filename>
drop policy if exists "wrody avatar write" on storage.objects;
create policy "wrody avatar write" on storage.objects for insert to authenticated
	with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "wrody avatar update" on storage.objects;
create policy "wrody avatar update" on storage.objects for update to authenticated
	using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text)
	with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "wrody avatar delete" on storage.objects;
create policy "wrody avatar delete" on storage.objects for delete to authenticated
	using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
