-- ============================================================================
-- Wrody — 0002 functions, triggers and transactional business logic
-- Every money/stock decision in the platform is taken here, inside Postgres.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- Generic helpers
-- ----------------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
	new.updated_at := now();
	return new;
end $$;

-- Role lookup used by RLS. SECURITY DEFINER avoids recursive policy evaluation
-- when a policy on `profiles` needs to know whether the caller is an admin.
create or replace function public.is_admin(p_uid uuid default auth.uid())
returns boolean language sql stable security definer set search_path = public as $$
	select exists (select 1 from public.profiles p where p.id = p_uid and p.role = 'admin');
$$;

do $$
declare t text;
begin
	foreach t in array array[
		'profiles','categories','products','product_variants','carts','cart_items','addresses',
		'orders','coupons','reviews','custom_bouquets','bouquet_flowers','bouquet_options',
		'delivery_zones','site_settings'
	] loop
		execute format('drop trigger if exists set_updated_at on public.%I', t);
		execute format('create trigger set_updated_at before update on public.%I for each row execute function public.set_updated_at()', t);
	end loop;
end $$;

-- ----------------------------------------------------------------------------
-- Auth: create a profile for every new auth user
-- ----------------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
	insert into public.profiles (id, email, full_name, phone)
	values (
		new.id,
		new.email,
		nullif(btrim(coalesce(new.raw_user_meta_data->>'full_name','')), ''),
		nullif(btrim(coalesce(new.raw_user_meta_data->>'phone','')), '')
	)
	on conflict (id) do nothing;
	return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
	after insert on auth.users
	for each row execute function public.handle_new_user();

-- Privilege escalation guard: a customer can never promote themselves.
create or replace function public.protect_profile_role()
returns trigger language plpgsql security definer set search_path = public as $$
begin
	if new.role is distinct from old.role and auth.uid() is not null and not public.is_admin() then
		new.role := old.role;
	end if;
	new.id := old.id;
	return new;
end $$;

drop trigger if exists protect_profile_role on public.profiles;
create trigger protect_profile_role before update on public.profiles
	for each row execute function public.protect_profile_role();

-- ----------------------------------------------------------------------------
-- Reviews: moderation + rating aggregates
-- ----------------------------------------------------------------------------
create or replace function public.force_review_moderation()
returns trigger language plpgsql security definer set search_path = public as $$
begin
	-- Customers can never approve their own review; admins and trusted server
	-- code (auth.uid() is null => service role) keep full control.
	if auth.uid() is not null and not public.is_admin() then
		new.is_approved := false;
		if tg_op = 'UPDATE' then
			new.user_id := old.user_id;
			new.product_id := old.product_id;
		end if;
	end if;
	return new;
end $$;

drop trigger if exists force_review_moderation on public.reviews;
create trigger force_review_moderation before insert or update on public.reviews
	for each row execute function public.force_review_moderation();

create or replace function public.refresh_product_rating()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_product uuid := coalesce(new.product_id, old.product_id);
begin
	update public.products p
	   set rating_avg = coalesce(s.avg_rating, 0),
	       rating_count = coalesce(s.cnt, 0)
	  from (
		select round(avg(r.rating)::numeric, 2) as avg_rating, count(*) as cnt
		  from public.reviews r
		 where r.product_id = v_product and r.is_approved
	  ) s
	 where p.id = v_product;
	return null;
end $$;

drop trigger if exists refresh_product_rating on public.reviews;
create trigger refresh_product_rating after insert or update or delete on public.reviews
	for each row execute function public.refresh_product_rating();

-- Can the current user review this product? (purchased + delivered)
create or replace function public.can_review(p_product_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
	select exists (
		select 1
		  from public.orders o
		  join public.order_items oi on oi.order_id = o.id
		 where o.user_id = auth.uid()
		   and oi.product_id = p_product_id
		   and o.status = 'delivered'
	);
$$;

-- ----------------------------------------------------------------------------
-- Order numbers: WRD-2026-000124 (human readable, separate from the UUID)
-- ----------------------------------------------------------------------------
create or replace function public.next_order_number()
returns text language plpgsql security definer set search_path = public as $$
declare
	v_year int := extract(year from (now() at time zone 'Africa/Cairo'))::int;
	v_num bigint;
begin
	insert into public.order_counters (year, last_number)
	values (v_year, 1)
	on conflict (year) do update set last_number = public.order_counters.last_number + 1
	returning last_number into v_num;

	return 'WRD-' || v_year::text || '-' || lpad(v_num::text, 6, '0');
end $$;

-- ----------------------------------------------------------------------------
-- Coupons: single source of truth for discount maths
-- ----------------------------------------------------------------------------
create or replace function public.evaluate_coupon(p_code text, p_subtotal numeric, p_user_id uuid default null)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
	c public.coupons;
	v_discount numeric(10,2);
	v_used int;
begin
	if p_code is null or btrim(p_code) = '' then
		return jsonb_build_object('valid', false, 'discount', 0, 'message', 'اكتب كود الخصم الأول');
	end if;

	select * into c from public.coupons where code = upper(btrim(p_code));
	if not found or not c.is_active then
		return jsonb_build_object('valid', false, 'discount', 0, 'message', 'كود الخصم غير صحيح');
	end if;
	if c.starts_at is not null and now() < c.starts_at then
		return jsonb_build_object('valid', false, 'discount', 0, 'message', 'كود الخصم لم يبدأ بعد');
	end if;
	if c.expires_at is not null and now() > c.expires_at then
		return jsonb_build_object('valid', false, 'discount', 0, 'message', 'انتهت صلاحية كود الخصم');
	end if;
	if c.usage_limit is not null and c.usage_count >= c.usage_limit then
		return jsonb_build_object('valid', false, 'discount', 0, 'message', 'تم استهلاك هذا الكود');
	end if;
	if c.minimum_order is not null and p_subtotal < c.minimum_order then
		return jsonb_build_object('valid', false, 'discount', 0,
			'message', 'الحد الأدنى لاستخدام الكود ' || trim(to_char(c.minimum_order, 'FM999999990.00')) || ' ج.م');
	end if;
	if p_user_id is not null and c.usage_limit_per_user is not null then
		select count(*) into v_used from public.coupon_redemptions r
		 where r.coupon_id = c.id and r.user_id = p_user_id;
		if v_used >= c.usage_limit_per_user then
			return jsonb_build_object('valid', false, 'discount', 0, 'message', 'استخدمت هذا الكود من قبل');
		end if;
	end if;

	v_discount := case c.discount_type
		when 'percentage' then round(p_subtotal * c.discount_value / 100.0, 2)
		else c.discount_value
	end;
	if c.maximum_discount is not null then
		v_discount := least(v_discount, c.maximum_discount);
	end if;
	v_discount := least(v_discount, p_subtotal);

	return jsonb_build_object(
		'valid', true, 'code', c.code, 'coupon_id', c.id, 'discount', v_discount,
		'discount_type', c.discount_type, 'discount_value', c.discount_value,
		'message', 'تم تطبيق الخصم ❤');
end $$;

-- ----------------------------------------------------------------------------
-- Delivery fee resolution (zone based, with free-delivery threshold)
-- ----------------------------------------------------------------------------
create or replace function public.delivery_fee_for(p_city text, p_amount numeric default 0)
returns numeric language plpgsql stable security definer set search_path = public as $$
declare
	v_settings jsonb;
	v_fee numeric(10,2);
	v_threshold numeric(10,2);
begin
	select value into v_settings from public.site_settings where key = 'store.delivery';
	v_threshold := nullif(v_settings->>'free_threshold','')::numeric;
	if v_threshold is not null and p_amount >= v_threshold then
		return 0;
	end if;

	select z.fee into v_fee
	  from public.delivery_zones z
	 where z.is_active and lower(btrim(z.city)) = lower(btrim(coalesce(p_city, '')))
	 limit 1;

	return coalesce(v_fee, nullif(v_settings->>'default_fee','')::numeric, 60);
end $$;

-- ----------------------------------------------------------------------------
-- Custom bouquet pricing — the ONLY place a bouquet price is computed.
-- items: [{"slug":"tulip","quantity":5}, ...]
-- ----------------------------------------------------------------------------
create or replace function public.price_custom_bouquet(
	p_size_slug text,
	p_wrapping_slug text,
	p_card_slug text,
	p_items jsonb
) returns jsonb language plpgsql stable security definer set search_path = public as $$
declare
	v_size public.bouquet_options;
	v_wrap public.bouquet_options;
	v_card public.bouquet_options;
	v_lines jsonb := '[]'::jsonb;
	v_flowers_total numeric(10,2) := 0;
	v_count int := 0;
	r record;
begin
	select * into v_size from public.bouquet_options where kind = 'size' and slug = p_size_slug and is_active;
	if not found then raise exception 'BOUQUET_SIZE_INVALID'; end if;

	select * into v_wrap from public.bouquet_options where kind = 'wrapping' and slug = p_wrapping_slug and is_active;
	if not found then raise exception 'BOUQUET_WRAPPING_INVALID'; end if;

	if p_card_slug is not null and btrim(p_card_slug) <> '' then
		select * into v_card from public.bouquet_options where kind = 'card' and slug = p_card_slug and is_active;
		if not found then raise exception 'BOUQUET_CARD_INVALID'; end if;
	end if;

	for r in
		select f.slug, f.name, f.color, f.unit_price, (i->>'quantity')::int as qty
		  from jsonb_array_elements(coalesce(p_items, '[]'::jsonb)) i
		  join public.bouquet_flowers f on f.slug = (i->>'slug') and f.is_active
	loop
		if r.qty is null or r.qty < 1 or r.qty > 50 then raise exception 'BOUQUET_QUANTITY_INVALID'; end if;
		v_count := v_count + r.qty;
		v_flowers_total := v_flowers_total + round(r.unit_price * r.qty, 2);
		v_lines := v_lines || jsonb_build_object(
			'slug', r.slug, 'name', r.name, 'color', r.color,
			'quantity', r.qty, 'unit_price', r.unit_price, 'total', round(r.unit_price * r.qty, 2));
	end loop;

	-- every submitted flower must exist and be active
	if jsonb_array_length(v_lines) <> jsonb_array_length(coalesce(p_items, '[]'::jsonb)) then
		raise exception 'BOUQUET_FLOWER_INVALID';
	end if;
	if v_count < coalesce(v_size.min_flowers, 1) then
		raise exception 'BOUQUET_MIN_FLOWERS:%', coalesce(v_size.min_flowers, 1);
	end if;
	if v_size.max_flowers is not null and v_count > v_size.max_flowers then
		raise exception 'BOUQUET_MAX_FLOWERS:%', v_size.max_flowers;
	end if;

	return jsonb_build_object(
		'size_slug', v_size.slug, 'size_name', v_size.name, 'base_price', v_size.price,
		'wrapping_slug', v_wrap.slug, 'wrapping_name', v_wrap.name, 'wrapping_price', v_wrap.price,
		'card_slug', v_card.slug, 'card_name', v_card.name, 'card_price', coalesce(v_card.price, 0),
		'flowers', v_lines, 'flowers_total', v_flowers_total, 'flower_count', v_count,
		'total', round(v_size.price + v_wrap.price + coalesce(v_card.price, 0) + v_flowers_total, 2));
end $$;

-- ----------------------------------------------------------------------------
-- Cart merge on login (guest cart -> customer cart)
-- ----------------------------------------------------------------------------
create or replace function public.merge_guest_cart(p_user_id uuid, p_session_id text)
returns uuid language plpgsql security definer set search_path = public as $$
declare
	v_guest public.carts;
	v_user public.carts;
begin
	if p_user_id is null or p_session_id is null then return null; end if;

	select * into v_guest from public.carts where session_id = p_session_id for update;
	if not found then
		select * into v_user from public.carts where user_id = p_user_id;
		return v_user.id;
	end if;

	select * into v_user from public.carts where user_id = p_user_id for update;
	if not found then
		update public.carts set user_id = p_user_id, session_id = null where id = v_guest.id;
		update public.custom_bouquets set user_id = p_user_id
		 where session_id = p_session_id and user_id is null;
		return v_guest.id;
	end if;

	-- merge quantities for lines that already exist (clamped to stock later)
	update public.cart_items ui
	   set quantity = least(ui.quantity + gi.quantity, 99), updated_at = now()
	  from public.cart_items gi
	 where gi.cart_id = v_guest.id
	   and ui.cart_id = v_user.id
	   and ui.custom_bouquet_id is null and gi.custom_bouquet_id is null
	   and ui.product_id is not distinct from gi.product_id
	   and ui.variant_id is not distinct from gi.variant_id;

	insert into public.cart_items (cart_id, product_id, variant_id, custom_bouquet_id, quantity)
	select v_user.id, gi.product_id, gi.variant_id, gi.custom_bouquet_id, gi.quantity
	  from public.cart_items gi
	 where gi.cart_id = v_guest.id
	on conflict do nothing;

	update public.custom_bouquets set user_id = p_user_id
	 where session_id = p_session_id and user_id is null;

	delete from public.cart_items where cart_id = v_guest.id;
	delete from public.carts where id = v_guest.id;
	return v_user.id;
end $$;

-- ----------------------------------------------------------------------------
-- ORDER PLACEMENT — one atomic transaction.
-- Recomputes every price from the database, validates stock under row locks,
-- validates the coupon, resolves delivery, decrements inventory and clears
-- the cart. Client-supplied totals are never read.
-- ----------------------------------------------------------------------------
create or replace function public.place_order(
	p_cart_id uuid,
	p_user_id uuid,
	p_customer jsonb,
	p_address jsonb,
	p_payment_method public.payment_method default 'cod',
	p_coupon_code text default null,
	p_notes text default null,
	p_idempotency_key text default null
) returns jsonb language plpgsql security definer set search_path = public as $fn$
declare
	v_cart public.carts;
	v_existing public.orders;
	v_order public.orders;
	v_item record;
	v_lines jsonb := '[]'::jsonb;
	v_unit numeric(10,2);
	v_subtotal numeric(10,2) := 0;
	v_discount numeric(10,2) := 0;
	v_delivery numeric(10,2) := 0;
	v_total numeric(10,2) := 0;
	v_coupon jsonb;
	v_coupon_id uuid;
	v_price jsonb;
	v_name text;
	v_phone text;
	v_key text := nullif(btrim(coalesce(p_idempotency_key, '')), '');
begin
	-- 1) Idempotency: a repeated submit returns the original order.
	if v_key is not null then
		select * into v_existing from public.orders where idempotency_key = v_key;
		if found then
			return jsonb_build_object('order_id', v_existing.id, 'order_number', v_existing.order_number,
				'total', v_existing.total, 'duplicate', true);
		end if;
	end if;

	-- 2) Cart ownership
	select * into v_cart from public.carts where id = p_cart_id for update;
	if not found then raise exception 'CART_NOT_FOUND'; end if;
	if p_user_id is not null and v_cart.user_id is not null and v_cart.user_id <> p_user_id then
		raise exception 'CART_FORBIDDEN';
	end if;
	if p_user_id is null and v_cart.user_id is not null then
		raise exception 'CART_FORBIDDEN';
	end if;

	v_name := btrim(coalesce(p_customer->>'name', ''));
	v_phone := btrim(coalesce(p_customer->>'phone', ''));
	if v_name = '' or v_phone = '' then raise exception 'CUSTOMER_INVALID'; end if;
	if coalesce(btrim(p_address->>'city'), '') = '' or coalesce(btrim(p_address->>'street'), '') = '' then
		raise exception 'ADDRESS_INVALID';
	end if;

	-- 3) Lock every touched inventory row in a deterministic order (no deadlocks,
	--    no oversell under concurrency).
	perform 1 from public.products p
	 where p.id in (select ci.product_id from public.cart_items ci
	                 where ci.cart_id = p_cart_id and ci.product_id is not null)
	 order by p.id for update;

	perform 1 from public.product_variants v
	 where v.id in (select ci.variant_id from public.cart_items ci
	                 where ci.cart_id = p_cart_id and ci.variant_id is not null)
	 order by v.id for update;

	-- 4) Rebuild every line from database prices
	for v_item in
		select ci.quantity, ci.product_id, ci.variant_id, ci.custom_bouquet_id,
		       p.name as product_name, p.price as product_price, p.stock as product_stock,
		       p.is_active as product_active,
		       v.name as variant_name, v.price as variant_price, v.stock as variant_stock,
		       v.is_active as variant_active,
		       cb.id as bouquet_id, cb.size_slug, cb.wrapping_slug, cb.card_slug,
		       cb.message as bouquet_message, cb.items as bouquet_items
		  from public.cart_items ci
		  left join public.products p on p.id = ci.product_id
		  left join public.product_variants v on v.id = ci.variant_id
		  left join public.custom_bouquets cb on cb.id = ci.custom_bouquet_id
		 where ci.cart_id = p_cart_id
		 order by ci.created_at
	loop
		if v_item.quantity is null or v_item.quantity < 1 then raise exception 'QUANTITY_INVALID'; end if;

		if v_item.custom_bouquet_id is not null then
			if v_item.bouquet_id is null then raise exception 'BOUQUET_NOT_FOUND'; end if;
			v_price := public.price_custom_bouquet(v_item.size_slug, v_item.wrapping_slug,
				v_item.card_slug, v_item.bouquet_items);
			v_unit := (v_price->>'total')::numeric;
			v_lines := v_lines || jsonb_build_object(
				'product_id', null, 'variant_id', null,
				'product_name', 'بوكيه مخصص — ' || coalesce(v_price->>'size_name', ''),
				'variant_name', coalesce(v_price->>'wrapping_name', ''),
				'quantity', v_item.quantity, 'unit_price', v_unit,
				'custom_bouquet_id', v_item.bouquet_id,
				'custom_bouquet', v_price || jsonb_build_object('message', v_item.bouquet_message),
				'image_url', null);
		else
			if v_item.product_id is null or coalesce(v_item.product_active, false) = false then
				raise exception 'PRODUCT_UNAVAILABLE:%', coalesce(v_item.product_name, 'منتج');
			end if;
			if v_item.variant_id is not null and coalesce(v_item.variant_active, false) = false then
				raise exception 'PRODUCT_UNAVAILABLE:%', v_item.product_name;
			end if;

			v_unit := round(coalesce(v_item.variant_price, v_item.product_price), 2);

			if v_item.variant_id is not null then
				if coalesce(v_item.variant_stock, 0) < v_item.quantity then
					raise exception 'OUT_OF_STOCK:%', v_item.product_name;
				end if;
			else
				if coalesce(v_item.product_stock, 0) < v_item.quantity then
					raise exception 'OUT_OF_STOCK:%', v_item.product_name;
				end if;
			end if;

			v_lines := v_lines || jsonb_build_object(
				'product_id', v_item.product_id, 'variant_id', v_item.variant_id,
				'product_name', v_item.product_name, 'variant_name', v_item.variant_name,
				'quantity', v_item.quantity, 'unit_price', v_unit,
				'custom_bouquet_id', null, 'custom_bouquet', null,
				'image_url', (select pi.image_url from public.product_images pi
				               where pi.product_id = v_item.product_id
				               order by pi.sort_order, pi.created_at limit 1));
		end if;

		v_subtotal := v_subtotal + round(v_unit * v_item.quantity, 2);
	end loop;

	if jsonb_array_length(v_lines) = 0 then raise exception 'CART_EMPTY'; end if;

	-- 5) Coupon + delivery, server side only
	if p_coupon_code is not null and btrim(p_coupon_code) <> '' then
		v_coupon := public.evaluate_coupon(p_coupon_code, v_subtotal, p_user_id);
		if coalesce((v_coupon->>'valid')::boolean, false) = false then
			raise exception 'COUPON_INVALID:%', coalesce(v_coupon->>'message', 'كود الخصم غير صالح');
		end if;
		v_discount := (v_coupon->>'discount')::numeric;
		v_coupon_id := nullif(v_coupon->>'coupon_id', '')::uuid;
	end if;

	v_delivery := public.delivery_fee_for(p_address->>'city', v_subtotal - v_discount);
	v_total := greatest(round(v_subtotal - v_discount + v_delivery, 2), 0);

	-- 6) Persist the order with immutable snapshots
	insert into public.orders (
		order_number, user_id, status, payment_method, payment_status,
		subtotal, delivery_fee, discount, total, coupon_code, coupon_id,
		customer_name, customer_phone, customer_email, shipping_address_snapshot, notes, idempotency_key)
	values (
		public.next_order_number(), p_user_id, 'pending', p_payment_method, 'pending',
		v_subtotal, v_delivery, v_discount, v_total, v_coupon->>'code', v_coupon_id,
		v_name, v_phone, nullif(btrim(coalesce(p_customer->>'email', '')), ''),
		p_address, nullif(btrim(coalesce(p_notes, '')), ''), v_key)
	returning * into v_order;

	insert into public.order_items (
		order_id, product_id, variant_id, custom_bouquet_id, product_name, variant_name,
		image_url, custom_bouquet, quantity, unit_price, total_price)
	select v_order.id,
	       nullif(e->>'product_id', '')::uuid,
	       nullif(e->>'variant_id', '')::uuid,
	       nullif(e->>'custom_bouquet_id', '')::uuid,
	       e->>'product_name',
	       nullif(e->>'variant_name', ''),
	       nullif(e->>'image_url', ''),
	       case when e->'custom_bouquet' = 'null'::jsonb then null else e->'custom_bouquet' end,
	       (e->>'quantity')::int,
	       (e->>'unit_price')::numeric,
	       round((e->>'unit_price')::numeric * (e->>'quantity')::int, 2)
	  from jsonb_array_elements(v_lines) e;

	-- 7) Inventory (never negative: CHECK + row locks above)
	update public.product_variants v
	   set stock = v.stock - x.qty
	  from (select (e->>'variant_id')::uuid as vid, sum((e->>'quantity')::int) as qty
	          from jsonb_array_elements(v_lines) e
	         where nullif(e->>'variant_id', '') is not null group by 1) x
	 where v.id = x.vid;

	update public.products p
	   set stock = p.stock - x.qty, sales_count = p.sales_count + x.qty
	  from (select (e->>'product_id')::uuid as pid, sum((e->>'quantity')::int) as qty
	          from jsonb_array_elements(v_lines) e
	         where nullif(e->>'product_id', '') is not null group by 1) x
	 where p.id = x.pid;

	-- 8) Coupon accounting (guards against a race on usage_limit)
	if v_coupon_id is not null then
		update public.coupons
		   set usage_count = usage_count + 1
		 where id = v_coupon_id
		   and (usage_limit is null or usage_count < usage_limit);
		if not found then raise exception 'COUPON_INVALID:%', 'تم استهلاك كود الخصم'; end if;
		insert into public.coupon_redemptions (coupon_id, order_id, user_id)
		values (v_coupon_id, v_order.id, p_user_id);
	end if;

	update public.custom_bouquets
	   set status = 'ordered', order_id = v_order.id
	 where id in (select nullif(e->>'custom_bouquet_id', '')::uuid
	                from jsonb_array_elements(v_lines) e
	               where nullif(e->>'custom_bouquet_id', '') is not null);

	insert into public.order_events (order_id, status, note, created_by)
	values (v_order.id, 'pending', 'تم استلام الطلب', p_user_id);

	delete from public.cart_items where cart_id = p_cart_id;
	update public.carts set updated_at = now() where id = p_cart_id;

	return jsonb_build_object(
		'order_id', v_order.id, 'order_number', v_order.order_number,
		'subtotal', v_order.subtotal, 'discount', v_order.discount,
		'delivery_fee', v_order.delivery_fee, 'total', v_order.total, 'duplicate', false);
end $fn$;

-- ----------------------------------------------------------------------------
-- Order status lifecycle
-- ----------------------------------------------------------------------------
create or replace function public.restore_order_stock(p_order_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare v_order public.orders;
begin
	select * into v_order from public.orders where id = p_order_id for update;
	if not found or v_order.stock_restored then return; end if;

	update public.product_variants v
	   set stock = v.stock + x.qty
	  from (select oi.variant_id as vid, sum(oi.quantity) as qty
	          from public.order_items oi
	         where oi.order_id = p_order_id and oi.variant_id is not null group by 1) x
	 where v.id = x.vid;

	update public.products p
	   set stock = p.stock + x.qty,
	       sales_count = greatest(p.sales_count - x.qty, 0)
	  from (select oi.product_id as pid, sum(oi.quantity) as qty
	          from public.order_items oi
	         where oi.order_id = p_order_id and oi.product_id is not null group by 1) x
	 where p.id = x.pid;

	update public.orders set stock_restored = true where id = p_order_id;
end $$;

create or replace function public.set_order_status(p_order_id uuid, p_status public.order_status, p_note text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
	v_order public.orders;
	v_allowed public.order_status[];
begin
	if not public.is_admin() then raise exception 'FORBIDDEN'; end if;

	select * into v_order from public.orders where id = p_order_id for update;
	if not found then raise exception 'ORDER_NOT_FOUND'; end if;
	if v_order.status = p_status then
		return jsonb_build_object('status', p_status, 'changed', false);
	end if;

	v_allowed := case v_order.status
		when 'pending' then array['confirmed','cancelled']::public.order_status[]
		when 'confirmed' then array['preparing','cancelled']::public.order_status[]
		when 'preparing' then array['out_for_delivery','cancelled']::public.order_status[]
		when 'out_for_delivery' then array['delivered','cancelled']::public.order_status[]
		else array[]::public.order_status[]
	end;

	if not (p_status = any(v_allowed)) then raise exception 'STATUS_TRANSITION_INVALID'; end if;
	if p_status = 'cancelled' then perform public.restore_order_stock(v_order.id); end if;

	update public.orders
	   set status = p_status,
	       payment_status = case
	         when p_status = 'delivered' and payment_method = 'cod' and payment_status = 'pending'
	           then 'paid'::public.payment_status
	         else payment_status end
	 where id = v_order.id;

	insert into public.order_events (order_id, status, note, created_by)
	values (v_order.id, p_status, nullif(btrim(coalesce(p_note, '')), ''), auth.uid());

	return jsonb_build_object('status', p_status, 'changed', true);
end $$;

create or replace function public.set_payment_status(p_order_id uuid, p_status public.payment_status, p_reference text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
	if not public.is_admin() then raise exception 'FORBIDDEN'; end if;
	update public.orders
	   set payment_status = p_status,
	       payment_reference = coalesce(nullif(btrim(coalesce(p_reference, '')), ''), payment_reference)
	 where id = p_order_id;
	if not found then raise exception 'ORDER_NOT_FOUND'; end if;
	return jsonb_build_object('payment_status', p_status);
end $$;

-- Customer-initiated cancellation, only while the order has not been prepared.
create or replace function public.cancel_own_order(p_order_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_order public.orders;
begin
	select * into v_order from public.orders where id = p_order_id for update;
	if not found or v_order.user_id is distinct from auth.uid() then raise exception 'FORBIDDEN'; end if;
	if v_order.status not in ('pending', 'confirmed') then raise exception 'CANCEL_NOT_ALLOWED'; end if;

	perform public.restore_order_stock(v_order.id);
	update public.orders set status = 'cancelled' where id = v_order.id;
	insert into public.order_events (order_id, status, note, created_by)
	values (v_order.id, 'cancelled', 'تم الإلغاء بواسطة العميل', auth.uid());
	return jsonb_build_object('status', 'cancelled');
end $$;

-- Guest order tracking: order number + matching phone, nothing else exposed.
create or replace function public.track_order(p_order_number text, p_phone text)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_order public.orders;
begin
	select * into v_order
	  from public.orders
	 where upper(btrim(order_number)) = upper(btrim(coalesce(p_order_number, '')))
	   and regexp_replace(customer_phone, '[^0-9]', '', 'g') = regexp_replace(coalesce(p_phone, ''), '[^0-9]', '', 'g')
	   and length(regexp_replace(coalesce(p_phone, ''), '[^0-9]', '', 'g')) >= 8;
	if not found then return jsonb_build_object('found', false); end if;

	return jsonb_build_object(
		'found', true,
		'order_number', v_order.order_number,
		'status', v_order.status,
		'payment_status', v_order.payment_status,
		'payment_method', v_order.payment_method,
		'total', v_order.total,
		'created_at', v_order.created_at,
		'customer_name', v_order.customer_name,
		'city', v_order.shipping_address_snapshot->>'city',
		'items', (select coalesce(jsonb_agg(jsonb_build_object(
				'product_name', oi.product_name, 'variant_name', oi.variant_name,
				'quantity', oi.quantity, 'total_price', oi.total_price) order by oi.created_at), '[]'::jsonb)
			from public.order_items oi where oi.order_id = v_order.id),
		'events', (select coalesce(jsonb_agg(jsonb_build_object(
				'status', e.status, 'note', e.note, 'created_at', e.created_at) order by e.created_at), '[]'::jsonb)
			from public.order_events e where e.order_id = v_order.id));
end $$;

-- ----------------------------------------------------------------------------
-- Admin analytics (single round trip, no N+1)
-- ----------------------------------------------------------------------------
create or replace function public.admin_dashboard_stats(p_days int default 30)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_from date := current_date - (greatest(coalesce(p_days, 30), 1) - 1);
begin
	if not public.is_admin() then raise exception 'FORBIDDEN'; end if;

	return jsonb_build_object(
		'revenue_total', (select coalesce(sum(total), 0) from public.orders where status <> 'cancelled'),
		'revenue_period', (select coalesce(sum(total), 0) from public.orders
		                    where status <> 'cancelled' and created_at::date >= v_from),
		'orders_total', (select count(*) from public.orders),
		'orders_pending', (select count(*) from public.orders where status = 'pending'),
		'orders_delivered', (select count(*) from public.orders where status = 'delivered'),
		'orders_period', (select count(*) from public.orders where created_at::date >= v_from),
		'customers_total', (select count(*) from public.profiles where role = 'customer'),
		'products_total', (select count(*) from public.products where is_active),
		'bouquets_pending', (select count(*) from public.custom_bouquets where status in ('ordered', 'in_production')),
		'reviews_pending', (select count(*) from public.reviews where not is_approved),
		'avg_order_value', (select coalesce(round(avg(total), 2), 0) from public.orders where status <> 'cancelled'),
		'low_stock', (select coalesce(jsonb_agg(x order by x.stock), '[]'::jsonb) from (
			select p.id, p.name, p.slug, p.stock from public.products p
			 where p.is_active and p.stock <= 5 order by p.stock limit 8) x),
		'series', (select coalesce(jsonb_agg(jsonb_build_object(
				'date', d.day, 'revenue', coalesce(s.revenue, 0), 'orders', coalesce(s.orders, 0)) order by d.day), '[]'::jsonb)
			from (select generate_series(v_from, current_date, interval '1 day')::date as day) d
			left join (
				select created_at::date as day, sum(total) as revenue, count(*) as orders
				  from public.orders where status <> 'cancelled' and created_at::date >= v_from
				 group by 1) s on s.day = d.day),
		'top_products', (select coalesce(jsonb_agg(x order by x.quantity desc), '[]'::jsonb) from (
			select oi.product_name as name, sum(oi.quantity)::int as quantity, sum(oi.total_price) as revenue
			  from public.order_items oi
			  join public.orders o on o.id = oi.order_id and o.status <> 'cancelled'
			 group by oi.product_name order by sum(oi.quantity) desc limit 6) x),
		'category_performance', (select coalesce(jsonb_agg(x order by x.revenue desc), '[]'::jsonb) from (
			select coalesce(c.name, 'بوكيهات مخصصة') as name, sum(oi.total_price) as revenue
			  from public.order_items oi
			  join public.orders o on o.id = oi.order_id and o.status <> 'cancelled'
			  left join public.products p on p.id = oi.product_id
			  left join public.categories c on c.id = p.category_id
			 group by 1 order by sum(oi.total_price) desc limit 6) x),
		'recent_orders', (select coalesce(jsonb_agg(x order by x.created_at desc), '[]'::jsonb) from (
			select o.id, o.order_number, o.customer_name, o.total, o.status, o.created_at
			  from public.orders o order by o.created_at desc limit 6) x));
end $$;

create or replace function public.admin_customers(p_search text default null, p_limit int default 20, p_offset int default 0)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_q text := nullif(btrim(coalesce(p_search, '')), '');
begin
	if not public.is_admin() then raise exception 'FORBIDDEN'; end if;

	return jsonb_build_object(
		'total', (select count(*) from public.profiles p
		           where v_q is null or p.full_name ilike '%' || v_q || '%'
		              or p.email::text ilike '%' || v_q || '%' or p.phone ilike '%' || v_q || '%'),
		'rows', (select coalesce(jsonb_agg(x order by x.created_at desc), '[]'::jsonb) from (
			select p.id, p.full_name, p.email::text as email, p.phone, p.role, p.created_at,
			       coalesce(o.orders_count, 0) as orders_count,
			       coalesce(o.total_spent, 0) as total_spent,
			       o.last_order_at
			  from public.profiles p
			  left join (
				select user_id, count(*) as orders_count, sum(total) as total_spent, max(created_at) as last_order_at
				  from public.orders where status <> 'cancelled' and user_id is not null group by user_id) o
				on o.user_id = p.id
			 where v_q is null or p.full_name ilike '%' || v_q || '%'
			    or p.email::text ilike '%' || v_q || '%' or p.phone ilike '%' || v_q || '%'
			 order by p.created_at desc
			 limit greatest(coalesce(p_limit, 20), 1) offset greatest(coalesce(p_offset, 0), 0)) x));
end $$;

-- ----------------------------------------------------------------------------
-- Function privileges. Postgres grants EXECUTE to PUBLIC by default, so every
-- sensitive routine is revoked first and then granted to the exact role.
-- ----------------------------------------------------------------------------
revoke all on function public.place_order(uuid, uuid, jsonb, jsonb, public.payment_method, text, text, text) from public, anon, authenticated;
revoke all on function public.evaluate_coupon(text, numeric, uuid) from public, anon, authenticated;
revoke all on function public.price_custom_bouquet(text, text, text, jsonb) from public, anon, authenticated;
revoke all on function public.delivery_fee_for(text, numeric) from public;
revoke all on function public.next_order_number() from public, anon, authenticated;
revoke all on function public.merge_guest_cart(uuid, text) from public, anon, authenticated;
revoke all on function public.restore_order_stock(uuid) from public, anon, authenticated;
revoke all on function public.handle_new_user() from public, anon, authenticated;

grant execute on function public.place_order(uuid, uuid, jsonb, jsonb, public.payment_method, text, text, text) to service_role;
grant execute on function public.evaluate_coupon(text, numeric, uuid) to service_role;
grant execute on function public.price_custom_bouquet(text, text, text, jsonb) to service_role;
grant execute on function public.delivery_fee_for(text, numeric) to service_role, authenticated, anon;
grant execute on function public.next_order_number() to service_role;
grant execute on function public.merge_guest_cart(uuid, text) to service_role;
grant execute on function public.restore_order_stock(uuid) to service_role;

grant execute on function public.is_admin(uuid) to authenticated, service_role;
grant execute on function public.can_review(uuid) to authenticated, service_role;
grant execute on function public.cancel_own_order(uuid) to authenticated, service_role;
grant execute on function public.track_order(text, text) to anon, authenticated, service_role;
grant execute on function public.set_order_status(uuid, public.order_status, text) to authenticated, service_role;
grant execute on function public.set_payment_status(uuid, public.payment_status, text) to authenticated, service_role;
grant execute on function public.admin_dashboard_stats(int) to authenticated, service_role;
grant execute on function public.admin_customers(text, int, int) to authenticated, service_role;
