-- ============================================================================
-- Wrody — seed data (محتوى تجريبي واقعي)
-- Idempotent: safe to run more than once.
--   supabase db reset            (runs migrations + this file)
--   psql "$DATABASE_URL" -f supabase/seed.sql
-- Images point at the bundled brand illustrations in /public (npm run art).
-- Replace them with real photography from Supabase Storage in production.
-- ============================================================================

-- ------------------------------------------------------------- settings ----
insert into public.site_settings (key, value, is_public) values
	('store.delivery', '{"default_fee": 60, "free_threshold": 1500}'::jsonb, true),
	('store.contact', '{"phone": "+20 100 000 0000", "email": "hello@wrody.shop", "instagram": "wrody.handmade", "tiktok": "wrody.handmade", "address": "القاهرة ، مصر"}'::jsonb, true),
	('homepage.hero', '{"headline": "ورد معمول بحب، عشان يفضل معاك.", "subheadline": "بوكيهات ورد هاند ميد من الـPipe Cleaners، مصممة مخصوص عشان كل مناسبة تبقى ذكرى.", "cta": "تسوق الآن", "secondary_cta": "اصنع بوكيهك", "badge": "شغل إيد مصري 100%"}'::jsonb, true),
	('homepage.cta', '{"headline": "اختار وردك، وخليه يحكي عنك.", "body": "كل بوكيه بيتلف بإيدينا قبل ما يوصلك، ويفضل زي ما هو لسنين."}'::jsonb, true),
	('homepage.gallery', '{"source": "placeholder", "note": "معرض تجريبي — اربط حساب إنستجرام الحقيقي من الإعدادات", "items": [{"image": "/gallery/g1.svg", "caption": "بوكيه توليب وردي"}, {"image": "/gallery/g2.svg", "caption": "علبة هدية فاخرة"}, {"image": "/gallery/g3.svg", "caption": "بوكيه لافندر"}, {"image": "/gallery/g4.svg", "caption": "وردة مفردة"}, {"image": "/gallery/g5.svg", "caption": "بوكيه باستيل"}, {"image": "/gallery/g6.svg", "caption": "بوكيه تخرج"}]}'::jsonb, true),
	('store.whatsapp', '{"enabled": true, "note": "رقم واتساب المتجر يُضبط من NEXT_PUBLIC_WHATSAPP_NUMBER"}'::jsonb, true)
on conflict (key) do update set value = excluded.value, is_public = excluded.is_public;

-- -------------------------------------------------------- delivery zones ----
insert into public.delivery_zones (city, fee, estimated_days, sort_order) values
	('القاهرة', 50, '1-2 يوم عمل', 1),
	('الجيزة', 55, '1-2 يوم عمل', 2),
	('القاهرة الجديدة', 60, '1-2 يوم عمل', 3),
	('الإسكندرية', 75, '2-3 أيام عمل', 4),
	('المنصورة', 80, '2-4 أيام عمل', 5),
	('طنطا', 80, '2-4 أيام عمل', 6),
	('أسيوط', 90, '3-5 أيام عمل', 7)
on conflict (city) do update set fee = excluded.fee, estimated_days = excluded.estimated_days;

-- ------------------------------------------------------------ categories ----
insert into public.categories (name, slug, description, image_url, sort_order) values
	('بوكيهات', 'bouquets', 'باقات ورد هاند ميد بأحجام وألوان مختلفة، ملفوفة بإتقان.', '/categories/bouquets.svg', 1),
	('بوكيهات ميني', 'mini', 'بوكيهات صغيرة لطيفة، مثالية كهدية بسيطة أو لمسة ديكور.', '/categories/mini.svg', 2),
	('وردة مفردة', 'single-flowers', 'وردات مفردة مصنوعة يدويًا تقدر تجمعها زي ما تحب.', '/categories/single-flowers.svg', 3),
	('علب هدايا', 'gift-boxes', 'علب مجهزة بالورد والكرت وجاهزة للإهداء مباشرة.', '/categories/gift-boxes.svg', 4),
	('مناسبات', 'occasions', 'تصميمات مخصصة للتخرج والخطوبة وعيد الأم والمواليد.', '/categories/occasions.svg', 5),
	('ديكور المنزل', 'home-decor', 'فازات وتنسيقات دائمة تفضل معاك طول السنة.', '/categories/home-decor.svg', 6)
on conflict (slug) do update set name = excluded.name, description = excluded.description,
	image_url = excluded.image_url, sort_order = excluded.sort_order;

-- -------------------------------------------------------------- products ----
insert into public.products (category_id, name, slug, short_description, description, price, compare_at_price, stock, sku, is_featured, is_best_seller, sales_count)
select c.id, v.name, v.slug, v.short_description, v.description, v.price, v.compare_at_price, v.stock, v.sku, v.is_featured, v.is_best_seller, v.sales_count
from (values
	('bouquets','بوكيه توليب وردي','tulip-pink-bouquet',
		'عشر وردات توليب هاند ميد بدرجات الوردي الهادئة.',
		'بوكيه مشغول بالكامل باليد من خامة الـPipe Cleaners الناعمة. كل وردة بتتلف بتلة بتلة وتتثبت على ساق مرن يسمح لك تظبط شكل البوكيه زي ما تحب. مناسب للإهداء في أي مناسبة، وبيفضل بنفس شكله لسنين من غير ما يذبل.',
		450, 520, 24, 'WRD-TLP-001', true, true, 38),
	('bouquets','بوكيه لافندر','lavender-bouquet',
		'تنسيق لافندر بنفسجي هادئ برباط كتان.',
		'لافندر هاند ميد بدرجات بنفسجي متدرجة، ملفوف بورق كرافت طبيعي ورباط كتان. اختيار ممتاز للمكاتب وغرف النوم أو كهدية رقيقة تعبر عن الهدوء.',
		420, null, 18, 'WRD-LVN-002', true, false, 21),
	('bouquets','بوكيه شمس','sunflower-bouquet',
		'سبع وردات عباد شمس بلون أصفر دافئ.',
		'بوكيه مبهج بدرجات الأصفر والعسلي، معمول يدويًا بتفاصيل دقيقة في قلب الزهرة. هدية مثالية للأصدقاء وللمناسبات السعيدة.',
		480, 540, 15, 'WRD-SUN-003', false, true, 29),
	('occasions','بوكيه حب','love-bouquet',
		'اثنا عشر وردة حمراء مخملية مع كارت إهداء.',
		'اثنا عشر وردة مشغولة بدرجة أحمر مخملي عميق، مع لف فاخر ورباط ساتان وكارت إهداء مكتوب بخط اليد. الأكثر طلبًا في مناسبات الخطوبة والذكرى السنوية.',
		650, 750, 12, 'WRD-LOV-004', true, true, 44),
	('mini','بوكيه ميني وردي','mini-pink-bouquet',
		'خمس وردات صغيرة في لفة واحدة لطيفة.',
		'بوكيه ميني مناسب للمكتب أو كإضافة لطيفة مع أي هدية. حجمه صغير بس تفاصيله مشغولة بنفس دقة البوكيهات الكبيرة.',
		180, null, 40, 'WRD-MIN-005', false, true, 62),
	('bouquets','بوكيه باستيل','pastel-bouquet',
		'توليفة ألوان باستيل ناعمة في بوكيه واحد.',
		'خليط من تسع وردات بدرجات باستيل متناغمة: وردي فاتح، أزرق هادئ، أصفر فاتح وكريمي. مناسب جدًا للمواليد وحفلات التخرج.',
		520, null, 16, 'WRD-PST-006', true, false, 17),
	('bouquets','بوكيه ديزي أبيض','white-daisy-bouquet',
		'ديزي أبيض بقلب أصفر ولفة كرافت.',
		'بساطة وأناقة: أحد عشر وردة ديزي بيضاء بقلب أصفر، ملفوفة بورق كرافت وخيط قطني. هدية رقيقة بميزانية لطيفة.',
		390, 430, 22, 'WRD-DSY-007', false, false, 12),
	('single-flowers','وردة توليب مفردة','single-tulip',
		'وردة توليب واحدة جاهزة للإهداء.',
		'وردة توليب مفردة مشغولة باليد، تقدر تجمع منها العدد اللي تحب وتعمل بوكيهك بنفسك، أو تهديها لوحدها مع كارت صغير.',
		65, null, 120, 'WRD-SGL-008', false, true, 140),
	('single-flowers','وردة روز مخملية','velvet-rose-single',
		'وردة روز بخامة مخملية فاخرة.',
		'وردة واحدة بخامة شينيل مخملية أثقل وأفخم من العادي، بتفاصيل بتلات متداخلة تدي إحساس الورد الطبيعي.',
		75, 90, 90, 'WRD-SGL-009', false, false, 55),
	('gift-boxes','علبة هدية صغيرة','gift-box-small',
		'علبة مجهزة بثلاث وردات وكارت.',
		'علبة دائرية مبطنة بورق حريري، جواها ثلاث وردات هاند ميد وكارت إهداء. توصل جاهزة للتقديم من غير ما تحتاج تغليف إضافي.',
		320, null, 30, 'WRD-BOX-010', false, false, 26),
	('gift-boxes','علبة هدية فاخرة','gift-box-premium',
		'علبة فاخرة بـ٢١ وردة ولمسات ذهبية.',
		'علبة مربعة فاخرة مجهزة بـ٢١ وردة بدرجات الروز والذهبي، مع رباط ساتان وكارت مطبوع باسم المهدى له. الأفخم في مجموعتنا.',
		690, 780, 8, 'WRD-BOX-011', true, false, 9),
	('occasions','بوكيه تخرج','graduation-bouquet',
		'بوكيه بألوان الجامعة مع شرايط.',
		'بوكيه مصمم مخصوص للتخرج، تقدر تختار لونين يناسبوا ألوان الكلية، مع شريط مكتوب عليه سنة التخرج.',
		560, null, 14, 'WRD-GRD-012', false, false, 19),
	('occasions','بوكيه عيد الأم','mothers-day-bouquet',
		'تنسيق دافئ بدرجات الروز والكريمي.',
		'بوكيه هادئ بدرجات الروز والكريمي والذهبي الخفيف، مع كارت إهداء يتكتب بخط اليد. أجمل هدية تفضل مع ماما بعد المناسبة.',
		610, 680, 11, 'WRD-MOM-013', true, false, 23),
	('home-decor','فازة ورد دائم','everlasting-vase',
		'فازة جاهزة بتنسيق ثابت.',
		'فازة سيراميك بلون كريمي مع تنسيق ثابت من الورد الهاند ميد، جاهزة للوضع على الترابيزة مباشرة من غير مياه ولا صيانة.',
		540, null, 9, 'WRD-VAS-014', false, false, 7),
	('mini','بوكيه ميني لافندر','mini-lavender',
		'لافندر ميني في لفة كتان.',
		'نسخة ميني من بوكيه اللافندر، مناسبة كهدية رمزية أو إضافة لطيفة للتغليف.',
		195, null, 35, 'WRD-MIN-015', false, false, 33)
) as v(cat_slug, name, slug, short_description, description, price, compare_at_price, stock, sku, is_featured, is_best_seller, sales_count)
join public.categories c on c.slug = v.cat_slug
on conflict (slug) do update set
	name = excluded.name, short_description = excluded.short_description, description = excluded.description,
	price = excluded.price, compare_at_price = excluded.compare_at_price, stock = excluded.stock,
	category_id = excluded.category_id, is_featured = excluded.is_featured,
	is_best_seller = excluded.is_best_seller;

-- --------------------------------------------------------- product images ---
delete from public.product_images pi
 using public.products p
 where p.id = pi.product_id and pi.image_url like '/products/%';

insert into public.product_images (product_id, image_url, alt_text, sort_order)
select p.id, '/products/' || p.slug || '-' || g.n || '.svg',
       p.name || ' — صورة ' || g.n, g.n
  from public.products p
  cross join (select generate_series(1, 3) as n) g;

-- ------------------------------------------------------- product variants ---
insert into public.product_variants (product_id, name, options, sku, price, stock, sort_order)
select p.id, v.name, v.options::jsonb, p.sku || '-' || v.suffix,
       case when v.price_delta is null then null else p.price + v.price_delta end,
       v.stock, v.sort_order
from (values
	('tulip-pink-bouquet','وردي فاتح — وسط','{"اللون":"وردي فاتح","الحجم":"وسط"}','PNK-M', 0::numeric, 10, 1),
	('tulip-pink-bouquet','وردي فاتح — كبير','{"اللون":"وردي فاتح","الحجم":"كبير"}','PNK-L', 150::numeric, 6, 2),
	('tulip-pink-bouquet','روز داكن — وسط','{"اللون":"روز داكن","الحجم":"وسط"}','ROS-M', 0::numeric, 8, 3),
	('lavender-bouquet','لفة كتان','{"التغليف":"كتان"}','LIN', 0::numeric, 10, 1),
	('lavender-bouquet','لفة ورق كرافت','{"التغليف":"كرافت"}','KRF', 0::numeric, 8, 2),
	('love-bouquet','٢١ وردة','{"عدد الورد":"٢١"}','21R', 220::numeric, 5, 1),
	('love-bouquet','١٢ وردة','{"عدد الورد":"١٢"}','12R', 0::numeric, 7, 2),
	('pastel-bouquet','باستيل وردي','{"الدرجة":"وردي"}','PP', 0::numeric, 8, 1),
	('pastel-bouquet','باستيل أزرق','{"الدرجة":"أزرق"}','PB', 0::numeric, 8, 2),
	('gift-box-premium','علبة كريمي','{"لون العلبة":"كريمي"}','CRM', 0::numeric, 4, 1),
	('gift-box-premium','علبة سوداء','{"لون العلبة":"أسود"}','BLK', 40::numeric, 4, 2),
	('single-tulip','أبيض','{"اللون":"أبيض"}','WHT', 0::numeric, 40, 1),
	('single-tulip','وردي','{"اللون":"وردي"}','PNK', 0::numeric, 40, 2),
	('single-tulip','أصفر','{"اللون":"أصفر"}','YLW', 0::numeric, 40, 3)
) as v(product_slug, name, options, suffix, price_delta, stock, sort_order)
join public.products p on p.slug = v.product_slug
on conflict (product_id, name) do update set
	options = excluded.options, price = excluded.price, stock = excluded.stock;

-- ------------------------------------------------- custom bouquet catalogue --
insert into public.bouquet_flowers (name, slug, color, unit_price, image_url, sort_order) values
	('توليب', 'tulip', '#E4AEB9', 45, '/flowers/tulip.svg', 1),
	('روز', 'rose', '#C05C6E', 55, '/flowers/rose.svg', 2),
	('عباد الشمس', 'sunflower', '#E0A63C', 50, '/flowers/sunflower.svg', 3),
	('لافندر', 'lavender', '#9B8CC4', 40, '/flowers/lavender.svg', 4),
	('ديزي', 'daisy', '#F2EDE4', 35, '/flowers/daisy.svg', 5),
	('بيوني', 'peony', '#EFB8C2', 60, '/flowers/peony.svg', 6),
	('جبسوفيليا', 'gypsophila', '#FFFFFF', 30, '/flowers/gypsophila.svg', 7)
on conflict (slug) do update set unit_price = excluded.unit_price, color = excluded.color,
	image_url = excluded.image_url, sort_order = excluded.sort_order;

insert into public.bouquet_options (kind, name, slug, description, price, min_flowers, max_flowers, sort_order) values
	('size', 'صغير', 'small', 'من ٣ إلى ٦ وردات', 80, 3, 6, 1),
	('size', 'وسط', 'medium', 'من ٧ إلى ١٢ وردة', 140, 7, 12, 2),
	('size', 'كبير', 'large', 'من ١٣ إلى ٢٤ وردة', 220, 13, 24, 3),
	('wrapping', 'أبيض كلاسيك', 'white', 'ورق أبيض مطفي مع رباط ساتان', 0, null, null, 1),
	('wrapping', 'وردي ناعم', 'pink', 'ورق وردي باستيل مزدوج', 25, null, null, 2),
	('wrapping', 'كرافت طبيعي', 'kraft', 'ورق كرافت مع خيط كتان', 20, null, null, 3),
	('wrapping', 'بريميوم', 'premium', 'تغليف مزدوج فاخر مع لمسة ذهبية', 70, null, null, 4),
	('card', 'بدون كارت', 'none', 'مفيش كارت مع البوكيه', 0, null, null, 1),
	('card', 'كارت بسيط', 'simple', 'كارت أبيض بخط يد', 15, null, null, 2),
	('card', 'كارت فاخر', 'premium', 'كارت مطبوع بحبر ذهبي في ظرف', 35, null, null, 3)
on conflict (kind, slug) do update set name = excluded.name, description = excluded.description,
	price = excluded.price, min_flowers = excluded.min_flowers, max_flowers = excluded.max_flowers,
	sort_order = excluded.sort_order;

-- --------------------------------------------------------------- coupons ----
insert into public.coupons (code, description, discount_type, discount_value, minimum_order, maximum_discount, usage_limit, usage_limit_per_user, starts_at, expires_at) values
	('WELCOME10', 'خصم ١٠% لأول طلب', 'percentage', 10, 300, 150, 500, 1, now() - interval '7 days', now() + interval '180 days'),
	('WRODY50', 'خصم ٥٠ جنيه على الطلبات فوق ٨٠٠ جنيه', 'fixed', 50, 800, null, null, null, now() - interval '7 days', now() + interval '90 days'),
	('GIFT15', 'خصم ١٥% على علب الهدايا', 'percentage', 15, 500, 200, 200, 2, now() - interval '2 days', now() + interval '45 days')
on conflict (code) do update set description = excluded.description, discount_type = excluded.discount_type,
	discount_value = excluded.discount_value, minimum_order = excluded.minimum_order,
	maximum_discount = excluded.maximum_discount, expires_at = excluded.expires_at, is_active = true;

-- ============================================================================
-- Demo customers, orders and reviews.
-- Creating auth users from SQL only works with elevated access (SQL editor,
-- supabase db reset, psql as postgres). If it is not permitted the block is
-- skipped with a notice instead of failing the whole seed.
-- Demo password for every seeded customer: Wrody#12345
-- ============================================================================
do $$
declare
	v_email text;
	v_name text;
	v_phone text;
	v_uid uuid;
begin
	foreach v_email in array array['sara.demo@wrody.shop','mariam.demo@wrody.shop','omar.demo@wrody.shop'] loop
		if exists (select 1 from auth.users u where u.email = v_email) then continue; end if;

		v_name := case v_email
			when 'sara.demo@wrody.shop' then 'سارة محمد'
			when 'mariam.demo@wrody.shop' then 'مريم عبد الرحمن'
			else 'عمر خالد' end;
		v_phone := case v_email
			when 'sara.demo@wrody.shop' then '01000000001'
			when 'mariam.demo@wrody.shop' then '01000000002'
			else '01000000003' end;
		v_uid := gen_random_uuid();

		insert into auth.users (
			instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
			raw_app_meta_data, raw_user_meta_data, created_at, updated_at)
		values (
			'00000000-0000-0000-0000-000000000000', v_uid, 'authenticated', 'authenticated', v_email,
			crypt('Wrody#12345', gen_salt('bf')), now(),
			'{"provider":"email","providers":["email"]}'::jsonb,
			jsonb_build_object('full_name', v_name, 'phone', v_phone), now(), now());

		begin
			insert into auth.identities (id, user_id, identity_data, provider, provider_id, last_sign_in_at, created_at, updated_at)
			values (gen_random_uuid(), v_uid,
				jsonb_build_object('sub', v_uid::text, 'email', v_email, 'email_verified', true),
				'email', v_email, now(), now(), now());
		exception when others then
			raise notice 'auth.identities not seeded for % (%). Sign-in may need a password reset.', v_email, sqlerrm;
		end;

		update public.profiles set full_name = v_name, phone = v_phone where id = v_uid;
	end loop;
exception when insufficient_privilege then
	raise notice 'Skipping demo auth users: run this seed with elevated privileges to create them.';
end $$;

-- addresses for demo customers
insert into public.addresses (user_id, full_name, phone, city, area, street, building, floor, apartment, is_default)
select p.id, p.full_name, coalesce(p.phone, '01000000000'), 'القاهرة الجديدة', 'التجمع الخامس', 'شارع النرجس', '١٢', '٣', '٥', true
  from public.profiles p
 where p.email::text like '%.demo@wrody.shop'
   and not exists (select 1 from public.addresses a where a.user_id = p.id);

-- demo orders (one per demo customer, different lifecycle stages)
do $$
declare
	r record;
	v_order public.orders;
	v_status public.order_status;
	v_idx int := 0;
	v_product public.products;
	v_qty int;
	v_subtotal numeric(10,2);
	v_delivery numeric(10,2) := 60;
begin
	for r in select p.* from public.profiles p where p.email::text like '%.demo@wrody.shop' order by p.created_at loop
		if exists (select 1 from public.orders o where o.user_id = r.id) then continue; end if;
		v_idx := v_idx + 1;
		v_status := (array['delivered','preparing','pending']::public.order_status[])[least(v_idx, 3)];

		select * into v_product from public.products
		 where slug = (array['tulip-pink-bouquet','love-bouquet','mini-pink-bouquet'])[least(v_idx, 3)];
		v_qty := least(v_idx, 2);
		v_subtotal := round(v_product.price * v_qty, 2);

		insert into public.orders (
			order_number, user_id, status, payment_method, payment_status, subtotal, delivery_fee,
			discount, total, customer_name, customer_phone, customer_email,
			shipping_address_snapshot, notes, created_at)
		values (
			public.next_order_number(), r.id, v_status, 'cod',
			case when v_status = 'delivered' then 'paid'::public.payment_status else 'pending'::public.payment_status end,
			v_subtotal, v_delivery, 0, v_subtotal + v_delivery,
			coalesce(r.full_name, 'عميل ورودي'), coalesce(r.phone, '01000000000'), r.email::text,
			jsonb_build_object('full_name', r.full_name, 'phone', r.phone, 'city', 'القاهرة الجديدة',
				'area', 'التجمع الخامس', 'street', 'شارع النرجس', 'building', '١٢', 'floor', '٣', 'apartment', '٥'),
			case when v_idx = 1 then 'برجاء التوصيل بعد ٥ مساءً' else null end,
			now() - (v_idx * interval '6 days'))
		returning * into v_order;

		insert into public.order_items (order_id, product_id, product_name, image_url, quantity, unit_price, total_price)
		values (v_order.id, v_product.id, v_product.name,
			'/products/' || v_product.slug || '-1.svg', v_qty, v_product.price, v_subtotal);

		insert into public.order_events (order_id, status, note, created_at)
		select v_order.id, s.status, s.note, v_order.created_at + (s.step * interval '10 hours')
		  from (values
			(1, 'pending'::public.order_status, 'تم استلام الطلب'),
			(2, 'confirmed'::public.order_status, 'تم تأكيد الطلب هاتفيًا'),
			(3, 'preparing'::public.order_status, 'جاري تجهيز البوكيه'),
			(4, 'out_for_delivery'::public.order_status, 'مع مندوب الشحن'),
			(5, 'delivered'::public.order_status, 'تم التسليم بنجاح')
		  ) as s(step, status, note)
		 where s.step <= (case v_status
			when 'pending' then 1 when 'confirmed' then 2 when 'preparing' then 3
			when 'out_for_delivery' then 4 else 5 end);
	end loop;
end $$;

-- demo reviews (only for delivered orders — mirrors the production rule)
insert into public.reviews (user_id, product_id, order_id, rating, comment, is_approved, created_at)
select o.user_id, oi.product_id, o.id, 5,
       'البوكيه وصل متغلف بعناية والشغل أدق من الصور. بقاله شهر ولسة زي ما هو بالظبط ❤',
       true, now() - interval '3 days'
  from public.orders o
  join public.order_items oi on oi.order_id = o.id
 where o.status = 'delivered' and o.user_id is not null and oi.product_id is not null
   and not exists (select 1 from public.reviews r where r.user_id = o.user_id and r.product_id = oi.product_id);

-- a couple of extra approved reviews spread over the catalogue for social proof
insert into public.reviews (user_id, product_id, order_id, rating, comment, is_approved, created_at)
select p.id, pr.id, null, 5,
       'أجمل هدية اتطلبت من زمان، التغليف والتفاصيل فوق المتوقع.', true, now() - interval '9 days'
  from public.profiles p
  cross join lateral (
	select id from public.products where slug = 'mini-pink-bouquet') pr
 where p.email::text = 'omar.demo@wrody.shop'
   and not exists (select 1 from public.reviews r where r.user_id = p.id and r.product_id = pr.id);

-- refresh aggregates for any rows inserted before the triggers existed
update public.products p
   set rating_avg = coalesce(s.avg_rating, 0), rating_count = coalesce(s.cnt, 0)
  from (select product_id, round(avg(rating)::numeric, 2) as avg_rating, count(*) as cnt
          from public.reviews where is_approved group by product_id) s
 where s.product_id = p.id;
