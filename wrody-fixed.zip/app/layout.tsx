
import type { Metadata, Viewport } from "next"
import { Cairo, El_Messiri } from "next/font/google"
import type { ReactNode } from "react"
import { JsReady } from "@/components/layout/js-ready"
import { Splash } from "@/components/layout/splash"
import { ToastProvider } from "@/components/ui/toast"
import { siteConfig } from "@/lib/config/site"
import "./globals.css"

const body = Cairo({
	subsets: ["arabic", "latin"],
	variable: "--font-body",
	display: "swap",
	weight: ["400", "500", "600", "700"],
})

const display = El_Messiri({
	subsets: ["arabic", "latin"],
	variable: "--font-display",
	display: "swap",
	weight: ["500", "600", "700"],
})

export const metadata: Metadata = {
	metadataBase: new URL(siteConfig.url),
	title: {
		default: `${siteConfig.name} | ${siteConfig.tagline}`,
		template: `%s | ${siteConfig.name}`,
	},
	description: siteConfig.description,
	applicationName: siteConfig.nameEn,
	keywords: [
		"ورودي",
		"Wrody",
		"ورد هاند ميد",
		"pipe cleaner flowers",
		"بوكيه هدايا",
		"ورد يدوي",
	],
	alternates: { canonical: "/" },
	openGraph: {
		type: "website",
		locale: siteConfig.locale,
		url: siteConfig.url,
		siteName: siteConfig.name,
		title: `${siteConfig.name} | ${siteConfig.tagline}`,
		description: siteConfig.description,
		images: [{ url: "/og.png", width: 1200, height: 630, alt: siteConfig.name }],
	},
	twitter: {
		card: "summary_large_image",
		title: `${siteConfig.name} | ${siteConfig.tagline}`,
		description: siteConfig.description,
		images: ["/og.png"],
	},
	robots: { index: true, follow: true },
}

export const viewport: Viewport = {
	themeColor: "#FBF7F2",
	width: "device-width",
	initialScale: 1,
}

export default function RootLayout({ children }: { children: ReactNode }) {
	return (
		<html lang="ar" dir="rtl" className={`${body.variable} ${display.variable}`}>
			<body className="min-h-dvh bg-cream">
				<JsReady />
				<Splash />
				<ToastProvider>{children}</ToastProvider>
			</body>
		</html>
	)
}
