import type { Metadata } from "next"
import { SettingsForm, type SettingsFormValues } from "@/components/admin/forms"
import { DeliveryZoneManager } from "@/components/admin/managers"
import { listAdminDeliveryZones } from "@/lib/services/admin"
import { getSetting, type ContactSettings } from "@/lib/services/settings"

export const metadata: Metadata = { title: "الإعدادات" }

export default async function AdminSettingsPage() {
	const [delivery, hero, cta, contactRaw, zones] = await Promise.all([
		getSetting("store.delivery"),
		getSetting("homepage.hero"),
		getSetting("homepage.cta"),
		getSetting("store.contact"),
		listAdminDeliveryZones(),
	])

	const contact = contactRaw as ContactSettings

	const values: SettingsFormValues = {
		deliveryFee: delivery.default_fee,
		freeDeliveryThreshold: delivery.free_threshold,
		heroHeadline: hero.headline,
		heroSubheadline: hero.subheadline,
		heroBadge: hero.badge ?? "",
		ctaHeadline: cta.headline,
		ctaBody: cta.body ?? "",
		contactPhone: contact.phone ?? "",
		contactEmail: contact.email ?? "",
		instagram: contact.instagram ?? "",
	}

	return (
		<div className="space-y-6">
			<header>
				<h1 className="font-display text-2xl font-bold">الإعدادات</h1>
				<p className="mt-1 text-sm text-ink-soft">
					المحتوى والأسعار دي بتتخزن في جدول `site_settings` وبتظهر فورًا على المتجر.
				</p>
			</header>

			<SettingsForm values={values} />

			<section className="surface space-y-4 p-5">
				<div>
					<h2 className="text-sm font-semibold text-ink-soft">مناطق التوصيل</h2>
					<p className="mt-1 text-xs text-ink-muted">
						لو المدينة موجودة هنا، هيتحسب سعرها؛ غير كده هيتحسب سعر التوصيل الافتراضي.
					</p>
				</div>
				<DeliveryZoneManager zones={zones} />
			</section>
		</div>
	)
}
