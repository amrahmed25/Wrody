import type { Metadata } from "next"
import Link from "next/link"
import { BOUQUET_STATUS_LABELS, BouquetStatusControl } from "@/components/admin/managers"
import { Badge, EmptyState } from "@/components/ui/display"
import { listAdminBouquets } from "@/lib/services/admin"
import { formatDateTime, formatPrice } from "@/lib/utils/format"

export const metadata: Metadata = { title: "البوكيهات المخصصة" }

const TABS = [
	{ value: "all", label: "الكل" },
	{ value: "ordered", label: "مطلوب" },
	{ value: "in_production", label: "تحت التنفيذ" },
	{ value: "completed", label: "تم التسليم" },
	{ value: "cancelled", label: "ملغي" },
] as const

type BouquetRow = {
	id: string
	size_slug: string
	wrapping_slug: string
	card_slug: string | null
	message: string | null
	total_price: number
	status: string
	created_at: string
	breakdown: {
		size_name?: string
		wrapping_name?: string
		card_name?: string
		flowers?: Array<{ name: string; quantity: number }>
	} | null
	customer: { full_name: string | null; phone: string | null } | null
	order: { order_number: string; status: string; customer_name: string; customer_phone: string } | null
}

export default async function AdminBouquetsPage({
	searchParams,
}: {
	searchParams: Promise<{ status?: string }>
}) {
	const params = await searchParams
	const status = params.status ?? "all"
	const bouquets = (await listAdminBouquets(status)) as unknown as BouquetRow[]

	return (
		<div className="space-y-5">
			<header>
				<h1 className="font-display text-2xl font-bold">البوكيهات المخصصة</h1>
				<p className="mt-1 text-sm text-ink-soft">
					كل بوكيه اتعمل من صفحة "اصنع بوكيهك" بسعر محسوب على السيرفر.
				</p>
			</header>

			<nav className="flex flex-wrap gap-2" aria-label="تصفية البوكيهات">
				{TABS.map((tab) => (
					<Link
						key={tab.value}
						href={`/admin/bouquets?status=${tab.value}`}
						className={status === tab.value ? "chip chip-active" : "chip"}
					>
						{tab.label}
					</Link>
				))}
			</nav>

			{bouquets.length ? (
				<ul className="grid gap-3 lg:grid-cols-2">
					{bouquets.map((bouquet) => (
						<li key={bouquet.id} className="surface space-y-3 p-5">
							<div className="flex flex-wrap items-start justify-between gap-3">
								<div>
									<p className="text-sm font-semibold">
										بوكيه {bouquet.breakdown?.size_name ?? bouquet.size_slug}
									</p>
									<p className="text-xs text-ink-muted">{formatDateTime(bouquet.created_at)}</p>
								</div>
								<div className="flex items-center gap-2">
									<Badge tone="rose">{formatPrice(bouquet.total_price)}</Badge>
									<Badge tone="muted">{BOUQUET_STATUS_LABELS[bouquet.status] ?? bouquet.status}</Badge>
								</div>
							</div>

							<dl className="grid gap-1 text-xs text-ink-soft sm:grid-cols-2">
								<div>
									<dt className="inline text-ink-muted">الورد: </dt>
									<dd className="inline">
										{bouquet.breakdown?.flowers?.length
											? bouquet.breakdown.flowers
													.map((flower) => `${flower.name} ×${flower.quantity}`)
													.join(" · ")
											: "—"}
									</dd>
								</div>
								<div>
									<dt className="inline text-ink-muted">التغليف: </dt>
									<dd className="inline">{bouquet.breakdown?.wrapping_name ?? bouquet.wrapping_slug}</dd>
								</div>
								<div>
									<dt className="inline text-ink-muted">الكارت: </dt>
									<dd className="inline">{bouquet.breakdown?.card_name ?? bouquet.card_slug ?? "بدون"}</dd>
								</div>
								<div>
									<dt className="inline text-ink-muted">العميل: </dt>
									<dd className="inline">
										{bouquet.order?.customer_name ?? bouquet.customer?.full_name ?? "زائر"}
									</dd>
								</div>
							</dl>

							{bouquet.message ? (
								<p className="rounded-2xl bg-cream p-3 text-xs text-ink-soft">رسالة الكارت: {bouquet.message}</p>
							) : null}

							<div className="flex flex-wrap items-center justify-between gap-3">
								{bouquet.order ? (
									<span className="nums text-xs text-ink-muted" dir="ltr">
										{bouquet.order.order_number}
									</span>
								) : (
									<span className="text-xs text-ink-muted">مرتبط بعربة لسة ماتأكدتش</span>
								)}
								<BouquetStatusControl bouquetId={bouquet.id} status={bouquet.status} />
							</div>
						</li>
					))}
				</ul>
			) : (
				<EmptyState title="مفيش بوكيهات في الحالة دي" description="جرب تبويب تاني أو استنى أول طلب بوكيه مخصص." />
			)}
		</div>
	)
}
