import type { Metadata } from "next"
import Link from "next/link"
import { AdminTable, type AdminColumn } from "@/components/admin/table"
import { Badge } from "@/components/ui/display"
import { Input } from "@/components/ui/field"
import { listAdminCustomers } from "@/lib/services/admin"
import { formatDate, formatPrice } from "@/lib/utils/format"
import type { AdminCustomerRow } from "@/types"

export const metadata: Metadata = { title: "العملاء" }

export default async function AdminCustomersPage({
	searchParams,
}: {
	searchParams: Promise<{ q?: string; page?: string }>
}) {
	const params = await searchParams
	const page = Math.max(1, Number(params.page ?? "1") || 1)
	const { customers, perPage } = await listAdminCustomers(params.q, page)

	const columns: AdminColumn<AdminCustomerRow>[] = [
		{
			key: "name",
			header: "العميل",
			render: (row) => (
				<div>
					<p className="font-medium">
						{row.full_name ?? "بدون اسم"}{" "}
						{row.role === "admin" ? <Badge tone="gold">مشرف</Badge> : null}
					</p>
					<p className="text-xs text-ink-muted" dir="ltr">
						{row.email ?? "—"}
					</p>
				</div>
			),
		},
		{
			key: "phone",
			header: "الموبايل",
			hideOnMobile: true,
			render: (row) => (
				<span className="nums text-sm" dir="ltr">
					{row.phone ?? "—"}
				</span>
			),
		},
		{
			key: "orders",
			header: "الطلبات",
			align: "center",
			render: (row) => <span className="nums">{row.orders_count}</span>,
		},
		{
			key: "spent",
			header: "إجمالي الإنفاق",
			align: "end",
			render: (row) => <span className="nums font-semibold">{formatPrice(row.total_spent)}</span>,
		},
		{
			key: "last",
			header: "آخر طلب",
			align: "center",
			hideOnMobile: true,
			render: (row) => (
				<span className="text-xs text-ink-muted">
					{row.last_order_at ? formatDate(row.last_order_at) : "لسة مفيش"}
				</span>
			),
		},
	]

	const prevHref = `/admin/customers?${new URLSearchParams({
		...(params.q ? { q: params.q } : {}),
		...(page > 2 ? { page: String(page - 1) } : {}),
	}).toString()}`
	const nextHref = `/admin/customers?${new URLSearchParams({
		...(params.q ? { q: params.q } : {}),
		page: String(page + 1),
	}).toString()}`

	return (
		<div className="space-y-5">
			<header>
				<h1 className="font-display text-2xl font-bold">العملاء</h1>
				<p className="mt-1 text-sm text-ink-soft">الإجماليات محسوبة من الطلبات المسلّمة والمؤكدة.</p>
			</header>

			<form method="get" className="surface grid gap-3 p-4 sm:grid-cols-[1fr_auto]">
				<Input name="q" defaultValue={params.q ?? ""} placeholder="ابحث بالاسم أو الإيميل أو الموبايل" aria-label="بحث" />
				<button type="submit" className="field-input bg-ink text-ivory transition-opacity hover:opacity-90">
					بحث
				</button>
			</form>

			<AdminTable columns={columns} rows={customers} empty="مفيش عملاء مطابقين." />

			<nav className="flex items-center justify-between gap-3" aria-label="تنقل بين الصفحات">
				{page > 1 ? (
					<Link href={prevHref} className="chip">
						السابق
					</Link>
				) : (
					<span />
				)}
				<span className="nums text-sm text-ink-muted">صفحة {page}</span>
				{customers.length === perPage ? (
					<Link href={nextHref} className="chip">
						التالي
					</Link>
				) : (
					<span />
				)}
			</nav>
		</div>
	)
}
