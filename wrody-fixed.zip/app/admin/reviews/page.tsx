import type { Metadata } from "next"
import Link from "next/link"
import { ReviewModerationActions } from "@/components/admin/managers"
import { Badge, EmptyState, Rating } from "@/components/ui/display"
import { listAdminReviews } from "@/lib/services/admin"
import { formatDate } from "@/lib/utils/format"

export const metadata: Metadata = { title: "التقييمات" }

const TABS = [
	{ value: "pending", label: "في انتظار المراجعة" },
	{ value: "approved", label: "منشورة" },
	{ value: "all", label: "الكل" },
] as const

export default async function AdminReviewsPage({
	searchParams,
}: {
	searchParams: Promise<{ status?: string }>
}) {
	const params = await searchParams
	const status =
		params.status === "approved" || params.status === "all" ? params.status : ("pending" as const)
	const reviews = await listAdminReviews(status)

	return (
		<div className="space-y-5">
			<header>
				<h1 className="font-display text-2xl font-bold">التقييمات</h1>
				<p className="mt-1 text-sm text-ink-soft">
					التقييمات من العملاء اللي اشتروا المنتج فعلًا، ومابتظهرش في المتجر إلا بعد موافقتك.
				</p>
			</header>

			<nav className="flex flex-wrap gap-2" aria-label="تصفية التقييمات">
				{TABS.map((tab) => (
					<Link
						key={tab.value}
						href={`/admin/reviews?status=${tab.value}`}
						className={status === tab.value ? "chip chip-active" : "chip"}
					>
						{tab.label}
					</Link>
				))}
			</nav>

			{reviews.length ? (
				<ul className="space-y-3">
					{reviews.map((review) => (
						<li key={review.id} className="surface space-y-3 p-5">
							<div className="flex flex-wrap items-start justify-between gap-3">
								<div>
									<p className="text-sm font-semibold">
										{review.product?.slug ? (
											<Link
												href={`/product/${review.product.slug}`}
												className="transition-colors hover:text-rose-700"
											>
												{review.product?.name}
											</Link>
										) : (
											"منتج محذوف"
										)}
									</p>
									<p className="text-xs text-ink-muted">
										{review.author?.full_name ?? "عميل ورودي"} · {formatDate(review.created_at)}
									</p>
								</div>
								<div className="flex items-center gap-2">
									<Rating value={review.rating} size="sm" />
									<Badge tone={review.is_approved ? "sage" : "gold"}>
										{review.is_approved ? "منشور" : "في الانتظار"}
									</Badge>
								</div>
							</div>
							{review.comment ? <p className="text-sm leading-relaxed text-ink-soft">{review.comment}</p> : null}
							<ReviewModerationActions reviewId={review.id} isApproved={review.is_approved} />
						</li>
					))}
				</ul>
			) : (
				<EmptyState title="مفيش تقييمات هنا" description="لما يوصل تقييم جديد هتلاقيه في التبويب ده." />
			)}
		</div>
	)
}
