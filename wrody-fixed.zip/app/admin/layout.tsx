import type { Metadata } from "next"
import type { ReactNode } from "react"
import { AdminShell } from "@/components/admin/shell"
import { requireAdmin } from "@/lib/auth/session"

export const metadata: Metadata = {
	title: { default: "لوحة التحكم", template: "%s — لوحة ورودي" },
	robots: { index: false, follow: false },
}

/**
 * Second authorisation gate. `middleware.ts` blocks anonymous users early, but
 * the role itself is always re-checked here against the database.
 */
export default async function AdminLayout({ children }: { children: ReactNode }) {
	const admin = await requireAdmin()
	return <AdminShell adminName={admin.full_name ?? "المشرف"}>{children}</AdminShell>
}
