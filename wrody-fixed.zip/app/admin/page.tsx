import { AlertTriangle, BadgeDollarSign, Package, ShoppingBag, Sparkles, Star, Truck, Users } from "lucide-react"
import type { Metadata } from "next"
import Link from "next/link"
import { BarList, TrendChart, type ChartPoint } from "@/components/admin/charts"
import { StatsCard } from "@/components/admin/stats-card"
import { AdminTable, type AdminColumn } from "@/components/admin/table"
import { OrderStatusBadge } from "@/components/orders/order-status"
import { getDashboardStats } from "@/lib/services/admin"
import { formatDate, formatPrice } from "@/lib/utils/format"
import type { OrderStatus } from "@/types"

export const metadata: Metadata = { title: "نظرة عامة" }

type RecentOrder = {
	id: string
	order_number: string
	customer_name: string
	total: number
	status: OrderStatus
	created_at: string
}

export default async function AdminDashboardPage() {
	const stats = await getDashboardStats(30)

	if (!stats) {
		return (
			<div className="surface p-10 text-center">
				<h1 className="font-display text-xl font-bold">مقدرناش نجيب الإحصائيات</h1>
				<p className="mt-2 text-sm text-ink-soft">
					اتأكد إن ملفات المايجريشن اتطبقت على Supabase وإن حسابك دوره admin.
				</p>
			</div>
		)
	}

	const revenuePoints: ChartPoint[] = stats.series.map((point) => ({
		label: point.date.slice(5),
		value: point.revenue,
	}))
	const orderPoints: ChartPoint[] = stats.series.map((point) => ({
		label: point.date.slice(5),
		value: point.orders,
	}))
	const topProducts: ChartPoint[] = stats.top_products.map((product) => ({
		label: product.name,
		value: product.revenue,
	}))
	const categoryPoints: ChartPoint[] = stats.category_performance.map((category) => ({
		label: category.name,
		value: category.revenue,
	}))

	const columns: AdminColumn<RecentOrder>[] = [
		{
			key: "order",
			header: "الطلب",
			render: (row) => (
				<Link href={`/admin/orders/${row.id}`} className="font-medium transition-colors hover:text-rose-700">
					<span className="nums" dir="ltr">
						{row.order_number}
					</span>
				</Link>
			),
		},
		{ key: "customer", header: "العميل", render: (row) => row.customer_name },
		{
			key: "date",
			header: "التاريخ",
			hideOnMobile: true,
			render: (row) => <span className="text-xs text-ink-muted">{formatDate(row.created_at)}</span>,
		},
		{
			key: "status",
			header: "الحالة",
			align: "center",
			render: (row) => <OrderStatusBadge status={row.status} />,
		},
		{
			key: "total",
			header: "الإجمالي",
			align: "end",
			render: (row) => <span className="nums font-semibold">{formatPrice(row.total)}</span>,
		},
	]

	return (
		<div className="space-y-6">
			<header>
				<h1 className="font-display text-2xl font-bold">نظرة عامة</h1>
				<p className="mt-1 text-sm text-ink-soft">ملخص أداء ورودي في آخر ٣٠ يوم.</p>
			</header>

			<div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
				<StatsCard
					label="إجمالي الإيرادات"
					value={formatPrice(stats.revenue_total)}
					hint={`آخر ٣٠ يوم: ${formatPrice(stats.revenue_period)}`}
					icon={<BadgeDollarSign className="h-5 w-5" />}
					tone="rose"
				/>
				<StatsCard
					label="الطلبات"
					value={stats.orders_total}
					hint={`آخر ٣٠ يوم: ${stats.orders_period}`}
					icon={<ShoppingBag className="h-5 w-5" />}
				/>
				<StatsCard
					label="العملاء"
					value={stats.customers_total}
					icon={<Users className="h-5 w-5" />}
					tone="sage"
				/>
				<StatsCard
					label="المنتجات"
					value={stats.products_total}
					hint={`متوسط قيمة الطلب: ${formatPrice(stats.avg_order_value)}`}
					icon={<Package className="h-5 w-5" />}
				/>
				<StatsCard
					label="طلبات منتطرة"
					value={stats.orders_pending}
					hint="محتاجة تأكيد"
					icon={<Truck className="h-5 w-5" />}
					tone="gold"
				/>
				<StatsCard
					label="طلبات متسلمة"
					value={stats.orders_delivered}
					icon={<ShoppingBag className="h-5 w-5" />}
					tone="sage"
				/>
				<StatsCard
					label="بوكيهات مخصصة جديدة"
					value={stats.bouquets_pending}
					icon={<Sparkles className="h-5 w-5" />}
					tone="rose"
				/>
				<StatsCard
					label="تقييمات للمراجعة"
					value={stats.reviews_pending}
					icon={<Star className="h-5 w-5" />}
					tone="gold"
				/>
			</div>

			<div className="grid gap-4 lg:grid-cols-2">
				<section className="surface p-5">
					<h2 className="mb-3 text-sm font-semibold text-ink-soft">الإيرادات على الوقت</h2>
					<TrendChart points={revenuePoints} formatValue={(value) => formatPrice(value)} />
				</section>
				<section className="surface p-5">
					<h2 className="mb-3 text-sm font-semibold text-ink-soft">عدد الطلبات على الوقت</h2>
					<TrendChart points={orderPoints} tone="sage" formatValue={(value) => String(value)} />
				</section>
				<section className="surface p-5">
					<h2 className="mb-3 text-sm font-semibold text-ink-soft">الأكثر مبيعًا</h2>
					<BarList items={topProducts} formatValue={(value) => formatPrice(value)} />
				</section>
				<section className="surface p-5">
					<h2 className="mb-3 text-sm font-semibold text-ink-soft">أداء الأقسام</h2>
					<BarList items={categoryPoints} tone="sage" formatValue={(value) => formatPrice(value)} />
				</section>
			</div>

			<section className="space-y-3">
				<div className="flex items-center justify-between gap-3">
					<h2 className="text-sm font-semibold text-ink-soft">أحدث الطلبات</h2>
					<Link href="/admin/orders" className="text-sm text-rose-700 transition-colors hover:text-rose-500">
						كل الطلبات
					</Link>
				</div>
				<AdminTable columns={columns} rows={stats.recent_orders} empty="مفيش طلبات لسة." />
			</section>

			<section className="surface p-5">
				<h2 className="mb-3 flex items-center gap-2 text-sm font-semibold text-ink-soft">
					<AlertTriangle className="h-4 w-4 text-gold-500" aria-hidden="true" />
					منتجات قربت تخلص
				</h2>
				{stats.low_stock.length ? (
					<ul className="divide-y divide-sand">
						{stats.low_stock.map((product) => (
							<li key={product.id} className="flex items-center justify-between gap-3 py-2.5">
								<Link
									href={`/admin/products/${product.id}`}
									className="text-sm transition-colors hover:text-rose-700"
								>
									{product.name}
								</Link>
								<span className="nums text-sm font-semibold text-gold-500">{product.stock}</span>
							</li>
						))}
					</ul>
				) : (
					<p className="text-sm text-ink-muted">كل حاجة متوفرة بكميات مريحة.</p>
				)}
			</section>
		</div>
	)
}
