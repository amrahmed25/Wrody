import type { Metadata } from "next"
import { CouponManager, type AdminCouponRow } from "@/components/admin/managers"
import { listAdminCoupons } from "@/lib/services/admin"

export const metadata: Metadata = { title: "الكوبونات" }

export default async function AdminCouponsPage() {
	const coupons = (await listAdminCoupons()) as unknown as AdminCouponRow[]

	return (
		<div className="space-y-5">
			<header>
				<h1 className="font-display text-2xl font-bold">الكوبونات</h1>
				<p className="mt-1 text-sm text-ink-soft">
					كل كوبون بيتحقق منه على السيرفر وقت إنشاء الطلب (الصلاحية، الحد الأدنى، عدد مرات الاستخدام).
				</p>
			</header>
			<CouponManager coupons={coupons} />
		</div>
	)
}
