import { ArrowRight } from "lucide-react"
import type { Metadata } from "next"
import Link from "next/link"
import { notFound } from "next/navigation"
import { ProductForm, type ProductFormValues } from "@/components/admin/product-form"
import { ProductImagesManager, ProductVariantsManager } from "@/components/admin/product-media"
import { getAdminProduct, listAdminCategories } from "@/lib/services/admin"

export const metadata: Metadata = { title: "تعديل منتج" }

export default async function AdminProductDetailPage({ params }: { params: Promise<{ id: string }> }) {
	const { id } = await params
	const isNew = id === "new"

	const [product, categories] = await Promise.all([
		isNew ? Promise.resolve(null) : getAdminProduct(id),
		listAdminCategories(),
	])

	if (!isNew && !product) notFound()

	const values: ProductFormValues | null = product
		? {
				id: product.id,
				name: product.name,
				slug: product.slug,
				category_id: product.category_id ?? null,
				short_description: product.short_description ?? null,
				description: product.description ?? null,
				price: product.price,
				compare_at_price: product.compare_at_price ?? null,
				stock: product.stock,
				sku: product.sku ?? null,
				is_active: product.is_active,
				is_featured: product.is_featured,
				is_best_seller: product.is_best_seller,
			}
		: null

	return (
		<div className="space-y-5">
			<header className="space-y-2">
				<Link
					href="/admin/products"
					className="inline-flex items-center gap-1 text-sm text-ink-soft transition-colors hover:text-rose-700"
				>
					<ArrowRight className="h-4 w-4" aria-hidden="true" />
					رجوع للمنتجات
				</Link>
				<h1 className="font-display text-2xl font-bold">{product ? product.name : "منتج جديد"}</h1>
				{product ? (
					<Link
						href={`/product/${product.slug}`}
						className="text-sm text-rose-700 transition-colors hover:text-rose-500"
						target="_blank"
						rel="noopener noreferrer"
					>
						معاينة الصفحة في المتجر
					</Link>
				) : null}
			</header>

			<div className="grid gap-5 xl:grid-cols-[1.4fr_1fr] xl:items-start">
				<ProductForm product={values} categories={categories} />

				<div className="space-y-5">
					{product ? (
						<>
							<ProductImagesManager productId={product.id} images={product.images ?? []} />
							<ProductVariantsManager productId={product.id} variants={product.variants ?? []} />
						</>
					) : (
						<div className="surface p-5 text-sm text-ink-soft">
							احفظ المنتج الأول، وبعدين هتقدر ترفع الصور وتضيف التنويعات.
						</div>
					)}
				</div>
			</div>
		</div>
	)
}
