import { Plus } from "lucide-react"
import type { Metadata } from "next"
import Link from "next/link"
import { ProductRowActions } from "@/components/admin/managers"
import { AdminTable, type AdminColumn } from "@/components/admin/table"
import { ButtonLink } from "@/components/ui/button"
import { Badge } from "@/components/ui/display"
import { Input, Select } from "@/components/ui/field"
import { listAdminCategories, listAdminProducts } from "@/lib/services/admin"
import { formatPrice } from "@/lib/utils/format"
import type { Product } from "@/types"

export const metadata: Metadata = { title: "المنتجات" }

type ProductRow = Product & { category: { name: string } | null }

function buildHref(base: Record<string, string | undefined>, page: number) {
	const search = new URLSearchParams()
	for (const [key, value] of Object.entries(base)) {
		if (value) search.set(key, value)
	}
	if (page > 1) search.set("page", String(page))
	const query = search.toString()
	return query ? `/admin/products?${query}` : "/admin/products"
}

export default async function AdminProductsPage({
	searchParams,
}: {
	searchParams: Promise<{ q?: string; category?: string; status?: string; page?: string }>
}) {
	const params = await searchParams
	const page = Math.max(1, Number(params.page ?? "1") || 1)
	const status =
		params.status === "active" || params.status === "inactive" || params.status === "low_stock"
			? params.status
			: undefined

	const [{ products, total, totalPages }, categories] = await Promise.all([
		listAdminProducts({ q: params.q, categoryId: params.category, status, page }),
		listAdminCategories(),
	])

	const columns: AdminColumn<ProductRow>[] = [
		{
			key: "name",
			header: "المنتج",
			render: (row) => (
				<div>
					<Link href={`/admin/products/${row.id}`} className="font-medium transition-colors hover:text-rose-700">
						{row.name}
					</Link>
					<p className="text-xs text-ink-muted">{row.category?.name ?? "بدون قسم"}</p>
				</div>
			),
		},
		{
			key: "price",
			header: "السعر",
			render: (row) => <span className="nums">{formatPrice(row.price)}</span>,
		},
		{
			key: "stock",
			header: "المخزون",
			align: "center",
			render: (row) => (
				<span className={row.stock <= 5 ? "nums font-semibold text-gold-500" : "nums"}>{row.stock}</span>
			),
		},
		{
			key: "flags",
			header: "الحالة",
			align: "center",
			hideOnMobile: true,
			render: (row) => (
				<div className="flex flex-wrap justify-center gap-1">
					<Badge tone={row.is_active ? "sage" : "muted"}>{row.is_active ? "منشور" : "مخفي"}</Badge>
					{row.is_featured ? <Badge tone="gold">مميز</Badge> : null}
					{row.is_best_seller ? <Badge tone="rose">الأكثر مبيعًا</Badge> : null}
				</div>
			),
		},
		{
			key: "actions",
			header: "إجراءات",
			align: "end",
			render: (row) => (
				<ProductRowActions
					productId={row.id}
					isActive={row.is_active}
					isFeatured={row.is_featured}
					isBestSeller={row.is_best_seller}
				/>
			),
		},
	]

	return (
		<div className="space-y-5">
			<header className="flex flex-wrap items-center justify-between gap-3">
				<div>
					<h1 className="font-display text-2xl font-bold">المنتجات</h1>
					<p className="nums mt-1 text-sm text-ink-soft">{total} منتج</p>
				</div>
				<ButtonLink href="/admin/products/new">
					<Plus className="h-4 w-4" />
					منتج جديد
				</ButtonLink>
			</header>

			<form method="get" className="surface grid gap-3 p-4 sm:grid-cols-4">
				<Input name="q" defaultValue={params.q ?? ""} placeholder="ابحث بالاسم أو الـ SKU" aria-label="بحث" />
				<Select name="category" defaultValue={params.category ?? ""} aria-label="القسم">
					<option value="">كل الأقسام</option>
					{categories.map((category) => (
						<option key={category.id} value={category.id}>
							{category.name}
						</option>
					))}
				</Select>
				<Select name="status" defaultValue={params.status ?? ""} aria-label="الحالة">
					<option value="">كل الحالات</option>
					<option value="active">منشور</option>
					<option value="inactive">مخفي</option>
					<option value="low_stock">مخزون منخفض</option>
				</Select>
				<button type="submit" className="field-input bg-ink text-ivory transition-opacity hover:opacity-90">
					تطبيق الفلاتر
				</button>
			</form>

			<AdminTable columns={columns} rows={products} empty="مفيش منتجات مطابقة." />

			{totalPages > 1 ? (
				<nav className="flex items-center justify-between gap-3" aria-label="تنقل بين الصفحات">
					{page > 1 ? (
						<Link
							href={buildHref({ q: params.q, category: params.category, status: params.status }, page - 1)}
							className="chip"
						>
							السابق
						</Link>
					) : (
						<span />
					)}
					<span className="nums text-sm text-ink-muted">
						صفحة {page} من {totalPages}
					</span>
					{page < totalPages ? (
						<Link
							href={buildHref({ q: params.q, category: params.category, status: params.status }, page + 1)}
							className="chip"
						>
							التالي
						</Link>
					) : (
						<span />
					)}
				</nav>
			) : null}
		</div>
	)
}
