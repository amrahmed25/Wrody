import type { Metadata } from "next"
import Link from "next/link"
import { AdminTable, type AdminColumn } from "@/components/admin/table"
import { OrderStatusBadge } from "@/components/orders/order-status"
import { Badge } from "@/components/ui/display"
import { Input, Select } from "@/components/ui/field"
import { listAdminOrders } from "@/lib/services/admin"
import { ORDER_STATUS_LABELS, PAYMENT_STATUS_LABELS, formatDate, formatPrice } from "@/lib/utils/format"
import type { Order, OrderStatus, PaymentStatus } from "@/types"

export const metadata: Metadata = { title: "الطلبات" }

const ORDER_STATUSES: OrderStatus[] = [
	"pending",
	"confirmed",
	"preparing",
	"out_for_delivery",
	"delivered",
	"cancelled",
]
const PAYMENT_STATUSES: PaymentStatus[] = ["pending", "paid", "failed", "refunded"]

function isOrderStatus(value?: string): value is OrderStatus {
	return Boolean(value) && ORDER_STATUSES.includes(value as OrderStatus)
}

function isPaymentStatus(value?: string): value is PaymentStatus {
	return Boolean(value) && PAYMENT_STATUSES.includes(value as PaymentStatus)
}

function pageHref(base: Record<string, string | undefined>, page: number) {
	const search = new URLSearchParams()
	for (const [key, value] of Object.entries(base)) {
		if (value) search.set(key, value)
	}
	if (page > 1) search.set("page", String(page))
	const query = search.toString()
	return query ? `/admin/orders?${query}` : "/admin/orders"
}

export default async function AdminOrdersPage({
	searchParams,
}: {
	searchParams: Promise<{ q?: string; status?: string; payment?: string; page?: string }>
}) {
	const params = await searchParams
	const page = Math.max(1, Number(params.page ?? "1") || 1)

	const { orders, total, totalPages } = await listAdminOrders({
		q: params.q,
		status: isOrderStatus(params.status) ? params.status : undefined,
		paymentStatus: isPaymentStatus(params.payment) ? params.payment : undefined,
		page,
	})

	const columns: AdminColumn<Order>[] = [
		{
			key: "order",
			header: "رقم الطلب",
			render: (row) => (
				<Link href={`/admin/orders/${row.id}`} className="font-medium transition-colors hover:text-rose-700">
					<span className="nums" dir="ltr">
						{row.order_number}
					</span>
				</Link>
			),
		},
		{
			key: "customer",
			header: "العميل",
			render: (row) => (
				<div>
					<p className="text-sm">{row.customer_name}</p>
					<p className="nums text-xs text-ink-muted" dir="ltr">
						{row.customer_phone}
					</p>
				</div>
			),
		},
		{
			key: "date",
			header: "التاريخ",
			hideOnMobile: true,
			render: (row) => <span className="text-xs text-ink-muted">{formatDate(row.created_at)}</span>,
		},
		{
			key: "payment",
			header: "الدفع",
			align: "center",
			hideOnMobile: true,
			render: (row) => (
				<Badge tone={row.payment_status === "paid" ? "sage" : "muted"}>
					{PAYMENT_STATUS_LABELS[row.payment_status]}
				</Badge>
			),
		},
		{
			key: "status",
			header: "الحالة",
			align: "center",
			render: (row) => <OrderStatusBadge status={row.status} />,
		},
		{
			key: "total",
			header: "الإجمالي",
			align: "end",
			render: (row) => <span className="nums font-semibold">{formatPrice(row.total)}</span>,
		},
	]

	return (
		<div className="space-y-5">
			<header>
				<h1 className="font-display text-2xl font-bold">الطلبات</h1>
				<p className="nums mt-1 text-sm text-ink-soft">{total} طلب</p>
			</header>

			<form method="get" className="surface grid gap-3 p-4 sm:grid-cols-4">
				<Input
					name="q"
					defaultValue={params.q ?? ""}
					placeholder="رقم الطلب أو الاسم أو الموبايل"
					aria-label="بحث في الطلبات"
				/>
				<Select name="status" defaultValue={params.status ?? ""} aria-label="حالة الطلب">
					<option value="">كل الحالات</option>
					{ORDER_STATUSES.map((status) => (
						<option key={status} value={status}>
							{ORDER_STATUS_LABELS[status]}
						</option>
					))}
				</Select>
				<Select name="payment" defaultValue={params.payment ?? ""} aria-label="حالة الدفع">
					<option value="">كل حالات الدفع</option>
					{PAYMENT_STATUSES.map((status) => (
						<option key={status} value={status}>
							{PAYMENT_STATUS_LABELS[status]}
						</option>
					))}
				</Select>
				<button type="submit" className="field-input bg-ink text-ivory transition-opacity hover:opacity-90">
					تطبيق الفلاتر
				</button>
			</form>

			<AdminTable columns={columns} rows={orders} empty="مفيش طلبات مطابقة." />

			{totalPages > 1 ? (
				<nav className="flex items-center justify-between gap-3" aria-label="تنقل بين الصفحات">
					{page > 1 ? (
						<Link
							href={pageHref({ q: params.q, status: params.status, payment: params.payment }, page - 1)}
							className="chip"
						>
							السابق
						</Link>
					) : (
						<span />
					)}
					<span className="nums text-sm text-ink-muted">
						صفحة {page} من {totalPages}
					</span>
					{page < totalPages ? (
						<Link
							href={pageHref({ q: params.q, status: params.status, payment: params.payment }, page + 1)}
							className="chip"
						>
							التالي
						</Link>
					) : (
						<span />
					)}
				</nav>
			) : null}
		</div>
	)
}
