import { ArrowRight } from "lucide-react"
import type { Metadata } from "next"
import Link from "next/link"
import { notFound } from "next/navigation"
import { OrderStatusControls } from "@/components/admin/order-detail"
import { OrderStatusBadge, OrderTimeline } from "@/components/orders/order-status"
import { Badge } from "@/components/ui/display"
import { getAdminOrder } from "@/lib/services/admin"
import {
	PAYMENT_METHOD_LABELS,
	PAYMENT_STATUS_LABELS,
	formatDateTime,
	formatPrice,
} from "@/lib/utils/format"

export const metadata: Metadata = { title: "تفاصيل الطلب" }

type AddressSnapshot = {
	full_name?: string
	phone?: string
	city?: string
	area?: string
	street?: string
	building?: string
	floor?: string
	apartment?: string
	additional_info?: string
}

export default async function AdminOrderDetailPage({ params }: { params: Promise<{ id: string }> }) {
	const { id } = await params
	const order = await getAdminOrder(id)
	if (!order) notFound()

	const address = (order.shipping_address_snapshot ?? {}) as unknown as AddressSnapshot
	const addressLines = [
		address.street,
		address.building ? `عمارة ${address.building}` : null,
		address.floor ? `دور ${address.floor}` : null,
		address.apartment ? `شقة ${address.apartment}` : null,
	]
		.filter(Boolean)
		.join(" · ")

	return (
		<div className="space-y-5">
			<header className="space-y-2">
				<Link
					href="/admin/orders"
					className="inline-flex items-center gap-1 text-sm text-ink-soft transition-colors hover:text-rose-700"
				>
					<ArrowRight className="h-4 w-4" aria-hidden="true" />
					رجوع للطلبات
				</Link>
				<div className="flex flex-wrap items-center gap-3">
					<h1 className="nums font-display text-2xl font-bold" dir="ltr">
						{order.order_number}
					</h1>
					<OrderStatusBadge status={order.status} />
					<Badge tone={order.payment_status === "paid" ? "sage" : "muted"}>
						{PAYMENT_STATUS_LABELS[order.payment_status]}
					</Badge>
					<span className="text-xs text-ink-muted">{formatDateTime(order.created_at)}</span>
				</div>
			</header>

			<OrderStatusControls orderId={order.id} status={order.status} paymentStatus={order.payment_status} />

			<div className="grid gap-5 lg:grid-cols-[1.5fr_1fr] lg:items-start">
				<section className="surface overflow-hidden">
					<h2 className="border-b border-sand px-5 py-4 text-sm font-semibold text-ink-soft">منتجات الطلب</h2>
					<ul className="divide-y divide-sand">
						{order.items.map((item) => (
							<li key={item.id} className="flex items-start justify-between gap-4 px-5 py-4">
								<div>
									<p className="text-sm font-medium">{item.product_name}</p>
									{item.variant_name ? <p className="text-xs text-ink-muted">{item.variant_name}</p> : null}
									<p className="nums mt-1 text-xs text-ink-muted">
										{item.quantity} × {formatPrice(item.unit_price)}
									</p>
								</div>
								<span className="nums text-sm font-semibold">{formatPrice(item.total_price)}</span>
							</li>
						))}
					</ul>
					<dl className="space-y-2 border-t border-sand bg-cream px-5 py-4 text-sm">
						<div className="flex justify-between">
							<dt className="text-ink-soft">المجموع</dt>
							<dd className="nums">{formatPrice(order.subtotal)}</dd>
						</div>
						{order.discount > 0 ? (
							<div className="flex justify-between text-sage-600">
								<dt>الخصم {order.coupon_code ? `(${order.coupon_code})` : ""}</dt>
								<dd className="nums">−{formatPrice(order.discount)}</dd>
							</div>
						) : null}
						<div className="flex justify-between">
							<dt className="text-ink-soft">التوصيل</dt>
							<dd className="nums">{formatPrice(order.delivery_fee)}</dd>
						</div>
						<div className="flex justify-between border-t border-sand pt-2 text-base font-bold">
							<dt>الإجمالي</dt>
							<dd className="nums">{formatPrice(order.total)}</dd>
						</div>
						<p className="pt-1 text-xs text-ink-muted">
							طريقة الدفع: {PAYMENT_METHOD_LABELS[order.payment_method]}
						</p>
					</dl>
				</section>

				<div className="space-y-5">
					<section className="surface space-y-2 p-5 text-sm">
						<h2 className="text-sm font-semibold text-ink-soft">بيانات العميل</h2>
						<p>{order.customer_name}</p>
						<p className="nums" dir="ltr">
							{order.customer_phone}
						</p>
						{order.customer_email ? (
							<p dir="ltr" className="text-ink-soft">
								{order.customer_email}
							</p>
						) : null}
						{order.user_id ? null : <Badge tone="muted">طلب بدون حساب</Badge>}
					</section>

					<section className="surface space-y-1 p-5 text-sm">
						<h2 className="mb-2 text-sm font-semibold text-ink-soft">عنوان التوصيل</h2>
						<p>
							{address.city}
							{address.area ? ` · ${address.area}` : ""}
						</p>
						{addressLines ? <p className="text-ink-soft">{addressLines}</p> : null}
						{address.additional_info ? <p className="text-ink-muted">{address.additional_info}</p> : null}
						{order.notes ? (
							<p className="mt-3 rounded-2xl bg-cream p-3 text-xs text-ink-soft">ملاحظات العميل: {order.notes}</p>
						) : null}
					</section>

					<section className="surface p-5">
						<h2 className="mb-3 text-sm font-semibold text-ink-soft">مراحل الطلب</h2>
						<OrderTimeline status={order.status} events={order.events} />
					</section>
				</div>
			</div>
		</div>
	)
}
