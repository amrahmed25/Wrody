import type { Metadata } from "next"
import { CategoryManager } from "@/components/admin/managers"
import { listAdminCategories } from "@/lib/services/admin"

export const metadata: Metadata = { title: "الأقسام" }

export default async function AdminCategoriesPage() {
	const categories = await listAdminCategories()

	return (
		<div className="space-y-5">
			<header>
				<h1 className="font-display text-2xl font-bold">الأقسام</h1>
				<p className="mt-1 text-sm text-ink-soft">ترتيب الأقسام بيظهر في الصفحة الرئيسية وفي فلاتر المتجر.</p>
			</header>
			<CategoryManager categories={categories} />
		</div>
	)
}
