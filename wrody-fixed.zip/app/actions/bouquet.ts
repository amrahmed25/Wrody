"use server"

import { revalidatePath } from "next/cache"
import { addBouquetToCart } from "@/lib/services/cart"
import { createCustomBouquet, priceBouquet } from "@/lib/services/bouquet"
import { actionError } from "@/lib/utils/errors"
import { bouquetSchema } from "@/lib/validations/bouquet"
import { firstError } from "@/lib/validations/common"
import type { ActionResult, BouquetPriceBreakdown } from "@/types"

/**
 * Authoritative price for the builder. The client keeps a local estimate for
 * instant feedback, but this is the number that gets stored and charged.
 */
export async function priceBouquetAction(input: unknown): Promise<ActionResult<BouquetPriceBreakdown>> {
	const parsed = bouquetSchema.safeParse(input)
	if (!parsed.success) return { ok: false, error: firstError(parsed.error) }

	try {
		const breakdown = await priceBouquet({
			sizeSlug: parsed.data.sizeSlug,
			wrappingSlug: parsed.data.wrappingSlug,
			cardSlug: parsed.data.cardSlug ?? null,
			items: parsed.data.items,
		})
		return { ok: true, data: breakdown }
	} catch (error) {
		return actionError(error, "مقدرناش نحسب سعر البوكيه.")
	}
}

export async function addBouquetToCartAction(
	input: unknown,
): Promise<ActionResult<{ total: number }>> {
	const parsed = bouquetSchema.safeParse(input)
	if (!parsed.success) return { ok: false, error: firstError(parsed.error) }

	try {
		// createCustomBouquet re-prices server-side and persists the breakdown.
		const { id, breakdown } = await createCustomBouquet({
			sizeSlug: parsed.data.sizeSlug,
			wrappingSlug: parsed.data.wrappingSlug,
			cardSlug: parsed.data.cardSlug ?? null,
			message: parsed.data.message ?? null,
			items: parsed.data.items,
		})
		await addBouquetToCart(id)
		revalidatePath("/cart")
		revalidatePath("/checkout")
		return { ok: true, data: { total: breakdown.total }, message: "بوكيهك المخصص اتضاف للسلة 🤍" }
	} catch (error) {
		return actionError(error, "مقدرناش نضيف البوكيه للسلة.")
	}
}
