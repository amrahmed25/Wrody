"use server"

import { revalidatePath } from "next/cache"
import { getUser } from "@/lib/auth/session"
import { createClient } from "@/lib/supabase/server"
import { actionError } from "@/lib/utils/errors"
import { firstError } from "@/lib/validations/common"
import { reviewSchema } from "@/lib/validations/review"
import type { ActionResult } from "@/types"

/**
 * Reviews are gated twice:
 *  - the RLS insert policy requires a delivered order containing the product
 *  - force_review_moderation() always stores is_approved = false
 * so a customer can neither review an unpurchased product nor self-publish.
 */
export async function submitReviewAction(
	_prev: ActionResult | null,
	formData: FormData,
): Promise<ActionResult> {
	const user = await getUser()
	if (!user) return { ok: false, error: "لازم تسجل دخول عشان تقيم المنتج." }

	const parsed = reviewSchema.safeParse({
		productId: formData.get("productId"),
		orderId: formData.get("orderId") || undefined,
		rating: formData.get("rating"),
		comment: formData.get("comment"),
	})
	if (!parsed.success) return { ok: false, error: firstError(parsed.error) }

	const supabase = await createClient()

	// Friendly pre-check; the database policy is the real gate.
	const { data: canReview } = await supabase.rpc("can_review", {
		p_product_id: parsed.data.productId,
	})
	if (canReview === false) {
		return { ok: false, error: "التقييم متاح للعملاء اللي استلموا المنتج فعليًا." }
	}

	const { error } = await supabase.from("reviews").upsert(
		{
			user_id: user.id,
			product_id: parsed.data.productId,
			order_id: parsed.data.orderId ?? null,
			rating: parsed.data.rating,
			comment: parsed.data.comment,
		},
		{ onConflict: "user_id,product_id" },
	)

	if (error) return actionError(error, "مقدرناش نحفظ التقييم.")

	revalidatePath("/account")
	return {
		ok: true,
		message: "شكرًا لتقييمك 🤍 هيظهر بعد مراجعة الفريق.",
	}
}
