"use server"

import { revalidatePath } from "next/cache"
import { currentAdmin } from "@/lib/auth/session"
import { sendTransactionalEmail } from "@/lib/notifications/email"
import { createClient } from "@/lib/supabase/server"
import { actionError } from "@/lib/utils/errors"
import { ORDER_STATUS_LABELS, formatPrice } from "@/lib/utils/format"
import {
	bouquetStatusSchema,
	couponFormSchema,
	deliveryZoneSchema,
	orderStatusSchema,
	paymentStatusSchema,
	reviewModerationSchema,
	settingsSchema,
} from "@/lib/validations/admin"
import { fieldErrors, firstError, uuidSchema } from "@/lib/validations/common"
import type { ActionResult, OrderStatus } from "@/types"

const DENIED: ActionResult = { ok: false, error: "مفيش صلاحية للقيام بهذا الإجراء." }

/**
 * Status changes go through set_order_status(), which validates the transition,
 * writes the timeline event, and restores stock exactly once on cancellation.
 */
export async function updateOrderStatusAction(input: {
	orderId: string
	status: OrderStatus
	note?: string | null
}): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED

	const parsed = orderStatusSchema.safeParse(input)
	if (!parsed.success) return { ok: false, error: firstError(parsed.error) }

	const supabase = await createClient()
	const { error } = await supabase.rpc("set_order_status", {
		p_order_id: parsed.data.orderId,
		p_status: parsed.data.status,
		p_note: parsed.data.note ?? null,
	})
	if (error) return actionError(error, "مقدرناش نحدّث حالة الطلب.")

	const { data: order } = await supabase
		.from("orders")
		.select("order_number, customer_email, customer_name, total")
		.eq("id", parsed.data.orderId)
		.maybeSingle<{
			order_number: string
			customer_email: string | null
			customer_name: string
			total: number
		}>()

	if (order?.customer_email) {
		await sendTransactionalEmail({
			to: order.customer_email,
			template: parsed.data.status === "delivered" ? "order_delivered" : "order_status_update",
			subject: `تحديث على طلبك #${order.order_number}`,
			heading: `أهلاً ${order.customer_name} 🤍`,
			lines: [
				`حالة طلبك <b>#${order.order_number}</b> بقت: <b>${ORDER_STATUS_LABELS[parsed.data.status]}</b>.`,
				`إجمالي الطلب: ${formatPrice(order.total)}`,
			],
			ctaLabel: "تتبع الطلب",
			ctaUrl: `/track?order=${order.order_number}`,
		})
	}

	revalidatePath("/admin/orders")
	revalidatePath(`/admin/orders/${parsed.data.orderId}`)
	revalidatePath("/orders")
	return { ok: true, message: "تم تحديث حالة الطلب." }
}

export async function updatePaymentStatusAction(input: {
	orderId: string
	paymentStatus: "pending" | "paid" | "failed" | "refunded"
	reference?: string | null
}): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED

	const parsed = paymentStatusSchema.safeParse(input)
	if (!parsed.success) return { ok: false, error: firstError(parsed.error) }

	const supabase = await createClient()
	const { error } = await supabase.rpc("set_payment_status", {
		p_order_id: parsed.data.orderId,
		p_status: parsed.data.paymentStatus,
		p_reference: parsed.data.reference ?? null,
	})
	if (error) return actionError(error, "مقدرناش نحدّث حالة الدفع.")

	revalidatePath(`/admin/orders/${parsed.data.orderId}`)
	revalidatePath("/admin/orders")
	return { ok: true, message: "تم تحديث حالة الدفع." }
}

export async function saveCouponAction(
	_prev: ActionResult | null,
	formData: FormData,
): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED

	const parsed = couponFormSchema.safeParse({
		id: formData.get("id") || undefined,
		code: formData.get("code"),
		description: formData.get("description"),
		discountType: formData.get("discountType"),
		discountValue: formData.get("discountValue"),
		minimumOrder: formData.get("minimumOrder") ?? "",
		maximumDiscount: formData.get("maximumDiscount") ?? "",
		usageLimit: formData.get("usageLimit") ?? "",
		usageLimitPerUser: formData.get("usageLimitPerUser") ?? "",
		startsAt: formData.get("startsAt") ?? "",
		expiresAt: formData.get("expiresAt") ?? "",
		isActive: formData.get("isActive") ?? false,
	})
	if (!parsed.success) {
		return { ok: false, error: firstError(parsed.error), fieldErrors: fieldErrors(parsed.error) }
	}

	const supabase = await createClient()
	const payload = {
		code: parsed.data.code,
		description: parsed.data.description,
		discount_type: parsed.data.discountType,
		discount_value: parsed.data.discountValue,
		minimum_order: parsed.data.minimumOrder ?? 0,
		maximum_discount: parsed.data.maximumDiscount,
		usage_limit: parsed.data.usageLimit,
		usage_limit_per_user: parsed.data.usageLimitPerUser,
		starts_at: parsed.data.startsAt,
		expires_at: parsed.data.expiresAt,
		is_active: parsed.data.isActive,
	}

	const { error } = parsed.data.id
		? await supabase.from("coupons").update(payload).eq("id", parsed.data.id)
		: await supabase.from("coupons").insert(payload)
	if (error) return actionError(error, "مقدرناش نحفظ الكوبون.")

	revalidatePath("/admin/coupons")
	return { ok: true, message: "تم حفظ الكوبون." }
}

export async function toggleCouponAction(input: {
	couponId: string
	isActive: boolean
}): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED
	if (!uuidSchema.safeParse(input.couponId).success) return { ok: false, error: "كوبون غير صالح." }

	const supabase = await createClient()
	const { error } = await supabase
		.from("coupons")
		.update({ is_active: Boolean(input.isActive) })
		.eq("id", input.couponId)
	if (error) return actionError(error)

	revalidatePath("/admin/coupons")
	return { ok: true }
}

export async function deleteCouponAction(couponId: string): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED
	if (!uuidSchema.safeParse(couponId).success) return { ok: false, error: "كوبون غير صالح." }

	const supabase = await createClient()
	const { error } = await supabase.from("coupons").delete().eq("id", couponId)
	if (error) return actionError(error, "مقدرناش نحذف الكوبون. جرب تعطيله بدل الحذف.")

	revalidatePath("/admin/coupons")
	return { ok: true, message: "تم حذف الكوبون." }
}

/** Reviews are published only by an admin — customers cannot self-approve. */
export async function moderateReviewAction(input: {
	reviewId: string
	approve: boolean
}): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED

	const parsed = reviewModerationSchema.safeParse(input)
	if (!parsed.success) return { ok: false, error: firstError(parsed.error) }

	const supabase = await createClient()
	const { data, error } = await supabase
		.from("reviews")
		.update({ is_approved: parsed.data.approve })
		.eq("id", parsed.data.reviewId)
		.select("product:products(slug)")
		.maybeSingle<{ product: { slug: string } | null }>()
	if (error) return actionError(error)

	revalidatePath("/admin/reviews")
	if (data?.product?.slug) revalidatePath(`/product/${data.product.slug}`)
	return { ok: true, message: parsed.data.approve ? "تم نشر التقييم." : "تم إخفاء التقييم." }
}

export async function deleteReviewAction(reviewId: string): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED
	if (!uuidSchema.safeParse(reviewId).success) return { ok: false, error: "تقييم غير صالح." }

	const supabase = await createClient()
	const { error } = await supabase.from("reviews").delete().eq("id", reviewId)
	if (error) return actionError(error)

	revalidatePath("/admin/reviews")
	return { ok: true, message: "تم حذف التقييم." }
}

export async function updateBouquetStatusAction(input: {
	bouquetId: string
	status: "ordered" | "in_production" | "completed" | "cancelled"
}): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED

	const parsed = bouquetStatusSchema.safeParse(input)
	if (!parsed.success) return { ok: false, error: firstError(parsed.error) }

	const supabase = await createClient()
	const { error } = await supabase
		.from("custom_bouquets")
		.update({ status: parsed.data.status })
		.eq("id", parsed.data.bouquetId)
	if (error) return actionError(error)

	revalidatePath("/admin/bouquets")
	return { ok: true, message: "تم تحديث حالة البوكيه." }
}

export async function saveDeliveryZoneAction(
	_prev: ActionResult | null,
	formData: FormData,
): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED

	const parsed = deliveryZoneSchema.safeParse({
		id: formData.get("id") || undefined,
		city: formData.get("city"),
		fee: formData.get("fee"),
		estimatedDays: formData.get("estimatedDays"),
		isActive: formData.get("isActive") ?? false,
	})
	if (!parsed.success) {
		return { ok: false, error: firstError(parsed.error), fieldErrors: fieldErrors(parsed.error) }
	}

	const supabase = await createClient()
	const payload = {
		city: parsed.data.city,
		fee: parsed.data.fee,
		estimated_days: parsed.data.estimatedDays,
		is_active: parsed.data.isActive,
	}

	const { error } = parsed.data.id
		? await supabase.from("delivery_zones").update(payload).eq("id", parsed.data.id)
		: await supabase.from("delivery_zones").insert(payload)
	if (error) return actionError(error, "مقدرناش نحفظ منطقة التوصيل.")

	revalidatePath("/admin/settings")
	revalidatePath("/checkout")
	return { ok: true, message: "تم حفظ منطقة التوصيل." }
}

export async function deleteDeliveryZoneAction(zoneId: string): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED
	if (!uuidSchema.safeParse(zoneId).success) return { ok: false, error: "منطقة غير صالحة." }

	const supabase = await createClient()
	const { error } = await supabase.from("delivery_zones").delete().eq("id", zoneId)
	if (error) return actionError(error)

	revalidatePath("/admin/settings")
	return { ok: true, message: "تم حذف المنطقة." }
}

/**
 * Homepage copy + delivery pricing live in site_settings as jsonb documents.
 * Keys we do not expose in the form (hero CTA labels, gallery items) are merged
 * forward so nothing is silently dropped.
 */
export async function updateSettingsAction(
	_prev: ActionResult | null,
	formData: FormData,
): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED

	const parsed = settingsSchema.safeParse({
		deliveryFee: formData.get("deliveryFee"),
		freeDeliveryThreshold: formData.get("freeDeliveryThreshold") ?? "",
		heroHeadline: formData.get("heroHeadline"),
		heroSubheadline: formData.get("heroSubheadline"),
		heroBadge: formData.get("heroBadge"),
		ctaHeadline: formData.get("ctaHeadline"),
		ctaBody: formData.get("ctaBody"),
		contactPhone: formData.get("contactPhone"),
		contactEmail: formData.get("contactEmail"),
		instagram: formData.get("instagram"),
	})
	if (!parsed.success) {
		return { ok: false, error: firstError(parsed.error), fieldErrors: fieldErrors(parsed.error) }
	}

	const supabase = await createClient()
	const { data: current } = await supabase.from("site_settings").select("key, value")
	const existing = new Map(
		(current ?? []).map((row) => [
			(row as { key: string }).key,
			((row as { value: unknown }).value ?? {}) as Record<string, unknown>,
		]),
	)

	const rows = [
		{
			key: "store.delivery",
			value: {
				...(existing.get("store.delivery") ?? {}),
				default_fee: parsed.data.deliveryFee,
				free_threshold: parsed.data.freeDeliveryThreshold,
			},
		},
		{
			key: "homepage.hero",
			value: {
				...(existing.get("homepage.hero") ?? {}),
				headline: parsed.data.heroHeadline,
				subheadline: parsed.data.heroSubheadline,
				badge: parsed.data.heroBadge,
			},
		},
		{
			key: "homepage.cta",
			value: {
				...(existing.get("homepage.cta") ?? {}),
				headline: parsed.data.ctaHeadline,
				body: parsed.data.ctaBody,
			},
		},
		{
			key: "store.contact",
			value: {
				...(existing.get("store.contact") ?? {}),
				phone: parsed.data.contactPhone,
				email: parsed.data.contactEmail,
				instagram: parsed.data.instagram,
			},
		},
	]

	const { error } = await supabase.from("site_settings").upsert(rows, { onConflict: "key" })
	if (error) return actionError(error, "مقدرناش نحفظ الإعدادات.")

	revalidatePath("/admin/settings")
	revalidatePath("/")
	revalidatePath("/checkout")
	return { ok: true, message: "تم حفظ الإعدادات." }
}
