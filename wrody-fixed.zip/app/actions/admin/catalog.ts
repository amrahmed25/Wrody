"use server"

import { revalidatePath } from "next/cache"
import { currentAdmin } from "@/lib/auth/session"
import { publicEnv } from "@/lib/config/env"
import { createClient } from "@/lib/supabase/server"
import { actionError } from "@/lib/utils/errors"
import { slugify } from "@/lib/utils/slug"
import {
	categoryFormSchema,
	productFormSchema,
	productImageSchema,
	reorderImagesSchema,
	variantFormSchema,
} from "@/lib/validations/admin"
import { fieldErrors, firstError, uuidSchema } from "@/lib/validations/common"
import type { ActionResult } from "@/types"

const DENIED: ActionResult = { ok: false, error: "مفيش صلاحية للقيام بهذا الإجراء." }
const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp", "image/avif", "image/svg+xml"]
const MAX_IMAGE_BYTES = 5 * 1024 * 1024

function revalidateCatalog(slug?: string | null) {
	revalidatePath("/admin/products")
	revalidatePath("/shop")
	revalidatePath("/")
	if (slug) revalidatePath(`/product/${slug}`)
}

/** Create or update a product. Admin authorisation is checked here AND by RLS. */
export async function saveProductAction(
	_prev: ActionResult | null,
	formData: FormData,
): Promise<ActionResult<{ id: string }>> {
	if (!(await currentAdmin())) return DENIED

	const rawName = String(formData.get("name") ?? "")
	const rawSlug = String(formData.get("slug") ?? "").trim()
	const parsed = productFormSchema.safeParse({
		id: formData.get("id") || undefined,
		name: rawName,
		slug: rawSlug || slugify(rawName),
		categoryId: formData.get("categoryId") || undefined,
		shortDescription: formData.get("shortDescription"),
		description: formData.get("description"),
		price: formData.get("price"),
		compareAtPrice: formData.get("compareAtPrice") ?? "",
		stock: formData.get("stock"),
		sku: formData.get("sku"),
		isActive: formData.get("isActive") ?? false,
		isFeatured: formData.get("isFeatured") ?? false,
		isBestSeller: formData.get("isBestSeller") ?? false,
	})

	if (!parsed.success) {
		return { ok: false, error: firstError(parsed.error), fieldErrors: fieldErrors(parsed.error) }
	}

	const supabase = await createClient()
	const payload = {
		name: parsed.data.name,
		slug: parsed.data.slug,
		category_id: parsed.data.categoryId || null,
		short_description: parsed.data.shortDescription,
		description: parsed.data.description,
		price: parsed.data.price,
		compare_at_price: parsed.data.compareAtPrice,
		stock: parsed.data.stock,
		sku: parsed.data.sku,
		is_active: parsed.data.isActive,
		is_featured: parsed.data.isFeatured,
		is_best_seller: parsed.data.isBestSeller,
	}

	const { data, error } = parsed.data.id
		? await supabase.from("products").update(payload).eq("id", parsed.data.id).select("id").single()
		: await supabase.from("products").insert(payload).select("id").single()

	if (error) return actionError(error, "مقدرناش نحفظ المنتج.")

	revalidateCatalog(parsed.data.slug)
	return { ok: true, data: { id: (data as { id: string }).id }, message: "تم حفظ المنتج." }
}

export async function setProductActiveAction(input: {
	productId: string
	isActive: boolean
}): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED
	if (!uuidSchema.safeParse(input.productId).success) return { ok: false, error: "منتج غير صالح." }

	const supabase = await createClient()
	const { error } = await supabase
		.from("products")
		.update({ is_active: Boolean(input.isActive) })
		.eq("id", input.productId)

	if (error) return actionError(error)
	revalidateCatalog()
	return { ok: true, message: input.isActive ? "تم تنشيط المنتج." : "تم إخفاء المنتج من المتجر." }
}

export async function toggleProductFlagAction(input: {
	productId: string
	flag: "is_featured" | "is_best_seller"
	value: boolean
}): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED
	if (input.flag !== "is_featured" && input.flag !== "is_best_seller") {
		return { ok: false, error: "إجراء غير معروف." }
	}

	const supabase = await createClient()
	const { error } = await supabase
		.from("products")
		.update({ [input.flag]: Boolean(input.value) })
		.eq("id", input.productId)

	if (error) return actionError(error)
	revalidateCatalog()
	return { ok: true }
}

/**
 * Permanent delete. Order items keep their historical snapshot (product_id is
 * nulled by the FK), so past orders are never rewritten.
 */
export async function deleteProductAction(productId: string): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED
	if (!uuidSchema.safeParse(productId).success) return { ok: false, error: "منتج غير صالح." }

	const supabase = await createClient()
	const { error } = await supabase.from("products").delete().eq("id", productId)
	if (error) return actionError(error, "مقدرناش نحذف المنتج. جرب تعطيله بدل الحذف.")

	revalidateCatalog()
	return { ok: true, message: "تم حذف المنتج." }
}

/** Uploads to Supabase Storage. Mime type and size are validated server-side. */
export async function uploadProductImageAction(
	_prev: ActionResult | null,
	formData: FormData,
): Promise<ActionResult<{ imageUrl: string }>> {
	if (!(await currentAdmin())) return DENIED

	const productId = String(formData.get("productId") ?? "")
	if (!uuidSchema.safeParse(productId).success) return { ok: false, error: "منتج غير صالح." }

	const file = formData.get("file")
	if (!(file instanceof File) || file.size === 0) return { ok: false, error: "اختر صورة الأول." }
	if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
		return { ok: false, error: "نوع الملف غير مدعوم. استخدم JPG أو PNG أو WebP." }
	}
	if (file.size > MAX_IMAGE_BYTES) return { ok: false, error: "أقصى حجم للصورة 5 ميجا." }

	const supabase = await createClient()
	const extension = (file.name.split(".").pop() ?? "jpg").toLowerCase().replace(/[^a-z0-9]/g, "")
	const path = `${productId}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${extension}`

	const { error: uploadError } = await supabase.storage
		.from(publicEnv.buckets.products)
		.upload(path, file, { cacheControl: "31536000", contentType: file.type, upsert: false })

	if (uploadError) return actionError(uploadError, "فشل رفع الصورة.")

	const {
		data: { publicUrl },
	} = supabase.storage.from(publicEnv.buckets.products).getPublicUrl(path)

	const { data: last } = await supabase
		.from("product_images")
		.select("sort_order")
		.eq("product_id", productId)
		.order("sort_order", { ascending: false })
		.limit(1)
		.maybeSingle<{ sort_order: number }>()

	const { error } = await supabase.from("product_images").insert({
		product_id: productId,
		image_url: publicUrl,
		alt_text: String(formData.get("altText") ?? "") || null,
		sort_order: (last?.sort_order ?? -1) + 1,
	})

	if (error) return actionError(error)

	revalidatePath(`/admin/products/${productId}`)
	revalidateCatalog()
	return { ok: true, data: { imageUrl: publicUrl }, message: "تم رفع الصورة." }
}

/** Links an already-hosted image (e.g. the seeded SVG art) to a product. */
export async function addProductImageAction(input: {
	productId: string
	imageUrl: string
	altText?: string | null
}): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED

	const parsed = productImageSchema.safeParse(input)
	if (!parsed.success) return { ok: false, error: firstError(parsed.error) }

	const supabase = await createClient()
	const { data: last } = await supabase
		.from("product_images")
		.select("sort_order")
		.eq("product_id", parsed.data.productId)
		.order("sort_order", { ascending: false })
		.limit(1)
		.maybeSingle<{ sort_order: number }>()

	const { error } = await supabase.from("product_images").insert({
		product_id: parsed.data.productId,
		image_url: parsed.data.imageUrl,
		alt_text: parsed.data.altText,
		sort_order: (last?.sort_order ?? -1) + 1,
	})

	if (error) return actionError(error)
	revalidatePath(`/admin/products/${parsed.data.productId}`)
	revalidateCatalog()
	return { ok: true, message: "تمت إضافة الصورة." }
}

export async function deleteProductImageAction(input: {
	imageId: string
	productId: string
}): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED
	if (!uuidSchema.safeParse(input.imageId).success) return { ok: false, error: "صورة غير صالحة." }

	const supabase = await createClient()
	const { error } = await supabase.from("product_images").delete().eq("id", input.imageId)
	if (error) return actionError(error)

	revalidatePath(`/admin/products/${input.productId}`)
	revalidateCatalog()
	return { ok: true, message: "تم حذف الصورة." }
}

export async function reorderProductImagesAction(input: {
	productId: string
	orderedIds: string[]
}): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED

	const parsed = reorderImagesSchema.safeParse(input)
	if (!parsed.success) return { ok: false, error: firstError(parsed.error) }

	const supabase = await createClient()
	for (const [index, id] of parsed.data.orderedIds.entries()) {
		const { error } = await supabase
			.from("product_images")
			.update({ sort_order: index })
			.eq("id", id)
			.eq("product_id", parsed.data.productId)
		if (error) return actionError(error)
	}

	revalidatePath(`/admin/products/${parsed.data.productId}`)
	revalidateCatalog()
	return { ok: true, message: "تم ترتيب الصور." }
}

export async function saveVariantAction(
	_prev: ActionResult | null,
	formData: FormData,
): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED

	const optionKeys = formData.getAll("optionKey").map(String)
	const optionValues = formData.getAll("optionValue").map(String)
	const options: Record<string, string> = {}
	optionKeys.forEach((key, index) => {
		const value = optionValues[index]
		if (key?.trim() && value?.trim()) options[key.trim()] = value.trim()
	})

	const parsed = variantFormSchema.safeParse({
		id: formData.get("id") || undefined,
		productId: formData.get("productId"),
		name: formData.get("name"),
		options,
		sku: formData.get("sku"),
		price: formData.get("price") ?? "",
		stock: formData.get("stock"),
		isActive: formData.get("isActive") ?? false,
	})
	if (!parsed.success) {
		return { ok: false, error: firstError(parsed.error), fieldErrors: fieldErrors(parsed.error) }
	}

	const supabase = await createClient()
	const payload = {
		product_id: parsed.data.productId,
		name: parsed.data.name,
		options: parsed.data.options,
		sku: parsed.data.sku,
		price: parsed.data.price,
		stock: parsed.data.stock,
		is_active: parsed.data.isActive,
	}

	const { error } = parsed.data.id
		? await supabase.from("product_variants").update(payload).eq("id", parsed.data.id)
		: await supabase.from("product_variants").insert(payload)

	if (error) return actionError(error, "مقدرناش نحفظ التنوع.")

	revalidatePath(`/admin/products/${parsed.data.productId}`)
	revalidateCatalog()
	return { ok: true, message: "تم حفظ التنوع." }
}

export async function deleteVariantAction(input: {
	variantId: string
	productId: string
}): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED
	if (!uuidSchema.safeParse(input.variantId).success) return { ok: false, error: "تنوع غير صالح." }

	const supabase = await createClient()
	const { error } = await supabase.from("product_variants").delete().eq("id", input.variantId)
	if (error) return actionError(error)

	revalidatePath(`/admin/products/${input.productId}`)
	revalidateCatalog()
	return { ok: true, message: "تم حذف التنوع." }
}

export async function saveCategoryAction(
	_prev: ActionResult | null,
	formData: FormData,
): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED

	const rawName = String(formData.get("name") ?? "")
	const rawSlug = String(formData.get("slug") ?? "").trim()
	const parsed = categoryFormSchema.safeParse({
		id: formData.get("id") || undefined,
		name: rawName,
		slug: rawSlug || slugify(rawName),
		description: formData.get("description"),
		imageUrl: formData.get("imageUrl"),
		sortOrder: formData.get("sortOrder") ?? 0,
		isActive: formData.get("isActive") ?? false,
	})
	if (!parsed.success) {
		return { ok: false, error: firstError(parsed.error), fieldErrors: fieldErrors(parsed.error) }
	}

	const supabase = await createClient()
	const payload = {
		name: parsed.data.name,
		slug: parsed.data.slug,
		description: parsed.data.description,
		image_url: parsed.data.imageUrl,
		sort_order: parsed.data.sortOrder,
		is_active: parsed.data.isActive,
	}

	const { error } = parsed.data.id
		? await supabase.from("categories").update(payload).eq("id", parsed.data.id)
		: await supabase.from("categories").insert(payload)

	if (error) return actionError(error, "مقدرناش نحفظ القسم.")

	revalidatePath("/admin/categories")
	revalidateCatalog()
	return { ok: true, message: "تم حفظ القسم." }
}

export async function deleteCategoryAction(categoryId: string): Promise<ActionResult> {
	if (!(await currentAdmin())) return DENIED
	if (!uuidSchema.safeParse(categoryId).success) return { ok: false, error: "قسم غير صالح." }

	const supabase = await createClient()
	// Products keep existing: the FK sets category_id to null.
	const { error } = await supabase.from("categories").delete().eq("id", categoryId)
	if (error) return actionError(error, "مقدرناش نحذف القسم.")

	revalidatePath("/admin/categories")
	revalidateCatalog()
	return { ok: true, message: "تم حذف القسم." }
}
