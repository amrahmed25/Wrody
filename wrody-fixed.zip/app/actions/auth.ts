"use server"

import { revalidatePath } from "next/cache"
import { redirect } from "next/navigation"
import { publicEnv } from "@/lib/config/env"
import { mergeGuestCart } from "@/lib/services/cart"
import { createClient } from "@/lib/supabase/server"
import {
	loginSchema,
	registerSchema,
	resetRequestSchema,
	updatePasswordSchema,
} from "@/lib/validations/auth"
import { fieldErrors, firstError } from "@/lib/validations/common"
import type { ActionResult } from "@/types"

/** Open-redirect guard for the ?next= parameter. */
function safeNext(value: unknown): string {
	if (typeof value !== "string") return "/"
	if (!value.startsWith("/") || value.startsWith("//")) return "/"
	return value
}

function authErrorMessage(message: string): string {
	const lower = message.toLowerCase()
	if (lower.includes("invalid login credentials")) return "البريد أو كلمة المرور غلط."
	if (lower.includes("already registered") || lower.includes("already exists")) {
		return "البريد ده مسجل بالفعل. جرب تسجل الدخول."
	}
	if (lower.includes("email not confirmed")) return "لازم تفعل البريد الإلكتروني الأول."
	if (lower.includes("rate limit") || lower.includes("too many")) {
		return "محاولات كتيرة. استنى شوية وحاول تاني."
	}
	if (lower.includes("password")) return "كلمة المرور ضعيفة أو غير مقبولة."
	return "حصل خطأ في الدخول. حاول تاني."
}

export async function registerAction(
	_prev: ActionResult | null,
	formData: FormData,
): Promise<ActionResult> {
	const parsed = registerSchema.safeParse({
		fullName: formData.get("fullName"),
		email: formData.get("email"),
		phone: formData.get("phone"),
		password: formData.get("password"),
		confirmPassword: formData.get("confirmPassword"),
		next: formData.get("next") ?? undefined,
	})

	if (!parsed.success) {
		return { ok: false, error: firstError(parsed.error), fieldErrors: fieldErrors(parsed.error) }
	}

	const supabase = await createClient()
	// role is intentionally NOT accepted from the client: handle_new_user() always
	// creates the profile as 'customer' and protect_profile_role() blocks changes.
	const { data, error } = await supabase.auth.signUp({
		email: parsed.data.email,
		password: parsed.data.password,
		options: {
			data: { full_name: parsed.data.fullName, phone: parsed.data.phone },
			emailRedirectTo: `${publicEnv.siteUrl}/auth/callback`,
		},
	})

	if (error) return { ok: false, error: authErrorMessage(error.message) }

	if (!data.session) {
		return {
			ok: true,
			message: "بعتنالك رسالة تفعيل على البريد الإلكتروني. فعل حسابك وبعدين سجل دخول.",
		}
	}

	if (data.user) await mergeGuestCart(data.user.id)
	revalidatePath("/", "layout")
	redirect(safeNext(parsed.data.next))
}

export async function loginAction(
	_prev: ActionResult | null,
	formData: FormData,
): Promise<ActionResult> {
	const parsed = loginSchema.safeParse({
		email: formData.get("email"),
		password: formData.get("password"),
		next: formData.get("next") ?? undefined,
	})

	if (!parsed.success) {
		return { ok: false, error: firstError(parsed.error), fieldErrors: fieldErrors(parsed.error) }
	}

	const supabase = await createClient()
	const { data, error } = await supabase.auth.signInWithPassword({
		email: parsed.data.email,
		password: parsed.data.password,
	})

	if (error) return { ok: false, error: authErrorMessage(error.message) }

	if (data.user) await mergeGuestCart(data.user.id)
	revalidatePath("/", "layout")
	redirect(safeNext(parsed.data.next))
}

export async function signOutAction(): Promise<void> {
	const supabase = await createClient()
	await supabase.auth.signOut()
	revalidatePath("/", "layout")
	redirect("/")
}

/**
 * Password reset mail is delivered by Supabase Auth using the SMTP provider
 * configured in the Supabase dashboard — nothing is faked here.
 */
export async function requestPasswordResetAction(
	_prev: ActionResult | null,
	formData: FormData,
): Promise<ActionResult> {
	const parsed = resetRequestSchema.safeParse({ email: formData.get("email") })
	if (!parsed.success) return { ok: false, error: firstError(parsed.error) }

	const supabase = await createClient()
	const { error } = await supabase.auth.resetPasswordForEmail(parsed.data.email, {
		redirectTo: `${publicEnv.siteUrl}/auth/callback?next=/reset-password%3Fstage%3Dupdate`,
	})

	if (error) return { ok: false, error: authErrorMessage(error.message) }
	return {
		ok: true,
		message: "لو البريد مسجل عندنا، هتوصلك رسالة فيها رابط تغيير كلمة المرور.",
	}
}

export async function updatePasswordAction(
	_prev: ActionResult | null,
	formData: FormData,
): Promise<ActionResult> {
	const parsed = updatePasswordSchema.safeParse({
		password: formData.get("password"),
		confirmPassword: formData.get("confirmPassword"),
	})
	if (!parsed.success) {
		return { ok: false, error: firstError(parsed.error), fieldErrors: fieldErrors(parsed.error) }
	}

	const supabase = await createClient()
	const {
		data: { user },
	} = await supabase.auth.getUser()
	if (!user) return { ok: false, error: "الرابط منتهي. اطلب رابط جديد من صفحة استعادة كلمة المرور." }

	const { error } = await supabase.auth.updateUser({ password: parsed.data.password })
	if (error) return { ok: false, error: authErrorMessage(error.message) }

	revalidatePath("/", "layout")
	return { ok: true, message: "تم تغيير كلمة المرور بنجاح." }
}
