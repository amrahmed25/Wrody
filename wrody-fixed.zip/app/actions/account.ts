"use server"

import { revalidatePath } from "next/cache"
import { getUser } from "@/lib/auth/session"
import { createClient } from "@/lib/supabase/server"
import { addressSchema } from "@/lib/validations/checkout"
import { profileSchema } from "@/lib/validations/auth"
import { fieldErrors, firstError, uuidSchema } from "@/lib/validations/common"
import { actionError } from "@/lib/utils/errors"
import type { ActionResult } from "@/types"

export async function updateProfileAction(
	_prev: ActionResult | null,
	formData: FormData,
): Promise<ActionResult> {
	const user = await getUser()
	if (!user) return { ok: false, error: "لازم تسجل دخول الأول." }

	const parsed = profileSchema.safeParse({
		fullName: formData.get("fullName"),
		phone: formData.get("phone"),
	})
	if (!parsed.success) {
		return { ok: false, error: firstError(parsed.error), fieldErrors: fieldErrors(parsed.error) }
	}

	const supabase = await createClient()
	// Only these two columns are ever written — role/email cannot be changed here.
	const { error } = await supabase
		.from("profiles")
		.update({ full_name: parsed.data.fullName, phone: parsed.data.phone })
		.eq("id", user.id)

	if (error) return actionError(error)

	revalidatePath("/account")
	return { ok: true, message: "تم تحديث بياناتك." }
}

export async function saveAddressAction(
	_prev: ActionResult | null,
	formData: FormData,
): Promise<ActionResult> {
	const user = await getUser()
	if (!user) return { ok: false, error: "لازم تسجل دخول الأول." }

	const raw = Object.fromEntries(formData.entries())
	const parsed = addressSchema.safeParse({
		id: raw.id ? String(raw.id) : undefined,
		fullName: raw.fullName,
		phone: raw.phone,
		city: raw.city,
		area: raw.area,
		street: raw.street,
		building: raw.building,
		floor: raw.floor,
		apartment: raw.apartment,
		additionalInfo: raw.additionalInfo,
		isDefault: raw.isDefault === "on" || raw.isDefault === "true",
	})
	if (!parsed.success) {
		return { ok: false, error: firstError(parsed.error), fieldErrors: fieldErrors(parsed.error) }
	}

	const supabase = await createClient()
	const payload = {
		user_id: user.id,
		full_name: parsed.data.fullName,
		phone: parsed.data.phone,
		city: parsed.data.city,
		area: parsed.data.area,
		street: parsed.data.street,
		building: parsed.data.building,
		floor: parsed.data.floor,
		apartment: parsed.data.apartment,
		additional_info: parsed.data.additionalInfo,
		is_default: parsed.data.isDefault,
	}

	// A single default per customer is enforced by a partial unique index.
	if (payload.is_default) {
		await supabase.from("addresses").update({ is_default: false }).eq("user_id", user.id)
	}

	const { error } = parsed.data.id
		? await supabase.from("addresses").update(payload).eq("id", parsed.data.id).eq("user_id", user.id)
		: await supabase.from("addresses").insert(payload)

	if (error) return actionError(error)

	revalidatePath("/account")
	revalidatePath("/checkout")
	return { ok: true, message: "تم حفظ العنوان." }
}

export async function deleteAddressAction(addressId: string): Promise<ActionResult> {
	const user = await getUser()
	if (!user) return { ok: false, error: "لازم تسجل دخول الأول." }

	const parsed = uuidSchema.safeParse(addressId)
	if (!parsed.success) return { ok: false, error: "عنوان غير صالح." }

	const supabase = await createClient()
	// RLS also restricts this to the owner; the explicit filter is defence in depth.
	const { error } = await supabase
		.from("addresses")
		.delete()
		.eq("id", parsed.data)
		.eq("user_id", user.id)

	if (error) return actionError(error)

	revalidatePath("/account")
	return { ok: true, message: "تم حذف العنوان." }
}

export async function setDefaultAddressAction(addressId: string): Promise<ActionResult> {
	const user = await getUser()
	if (!user) return { ok: false, error: "لازم تسجل دخول الأول." }

	const parsed = uuidSchema.safeParse(addressId)
	if (!parsed.success) return { ok: false, error: "عنوان غير صالح." }

	const supabase = await createClient()
	await supabase.from("addresses").update({ is_default: false }).eq("user_id", user.id)
	const { error } = await supabase
		.from("addresses")
		.update({ is_default: true })
		.eq("id", parsed.data)
		.eq("user_id", user.id)

	if (error) return actionError(error)

	revalidatePath("/account")
	return { ok: true, message: "تم تحديد العنوان الافتراضي." }
}
