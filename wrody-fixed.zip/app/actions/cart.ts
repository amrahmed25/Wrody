"use server"

import { revalidatePath } from "next/cache"
import { redirect } from "next/navigation"
import { getUser } from "@/lib/auth/session"
import {
	addProductToCart,
	getCart,
	removeCartItem,
	updateCartItemQuantity,
	writeCouponCode,
} from "@/lib/services/cart"
import { createClient } from "@/lib/supabase/server"
import { actionError } from "@/lib/utils/errors"
import {
	addToCartSchema,
	couponSchema,
	removeCartItemSchema,
	updateCartItemSchema,
	wishlistSchema,
} from "@/lib/validations/cart"
import { firstError } from "@/lib/validations/common"
import type { ActionResult } from "@/types"

function revalidateCartRoutes() {
	revalidatePath("/cart")
	revalidatePath("/checkout")
}

/**
 * The client sends only ids and a quantity. Price, stock and availability are
 * all resolved from the database inside the service.
 */
export async function addToCartAction(input: {
	productId: string
	variantId?: string | null
	quantity?: number
}): Promise<ActionResult> {
	const parsed = addToCartSchema.safeParse(input)
	if (!parsed.success) return { ok: false, error: firstError(parsed.error) }

	try {
		await addProductToCart({
			productId: parsed.data.productId,
			variantId: parsed.data.variantId ?? null,
			quantity: parsed.data.quantity,
		})
	} catch (error) {
		return actionError(error, "مقدرناش نضيف المنتج للسلة.")
	}

	revalidateCartRoutes()
	return { ok: true, message: "تمت الإضافة للسلة 🤍" }
}

export async function buyNowAction(input: {
	productId: string
	variantId?: string | null
	quantity?: number
}): Promise<ActionResult> {
	const result = await addToCartAction(input)
	if (!result.ok) return result
	redirect("/checkout")
}

export async function updateCartItemAction(input: {
	itemId: string
	quantity: number
}): Promise<ActionResult> {
	const parsed = updateCartItemSchema.safeParse(input)
	if (!parsed.success) return { ok: false, error: firstError(parsed.error) }

	try {
		await updateCartItemQuantity(parsed.data.itemId, parsed.data.quantity)
	} catch (error) {
		return actionError(error, "مقدرناش نحدّث الكمية.")
	}

	revalidateCartRoutes()
	return { ok: true }
}

export async function removeCartItemAction(input: { itemId: string }): Promise<ActionResult> {
	const parsed = removeCartItemSchema.safeParse(input)
	if (!parsed.success) return { ok: false, error: firstError(parsed.error) }

	try {
		await removeCartItem(parsed.data.itemId)
	} catch (error) {
		return actionError(error, "مقدرناش نحذف المنتج.")
	}

	revalidateCartRoutes()
	return { ok: true, message: "تم الحذف من السلة." }
}

/**
 * The coupon code is stored in an httpOnly cookie and re-evaluated by the
 * database on every cart render and again inside place_order().
 */
export async function applyCouponAction(
	_prev: ActionResult | null,
	formData: FormData,
): Promise<ActionResult> {
	const parsed = couponSchema.safeParse({ code: formData.get("code") })
	if (!parsed.success) return { ok: false, error: firstError(parsed.error) }

	await writeCouponCode(parsed.data.code)
	const cart = await getCart()

	if (!cart.totals.couponCode) {
		await writeCouponCode(null)
		return { ok: false, error: cart.totals.couponMessage ?? "كود الخصم غير صالح." }
	}

	revalidateCartRoutes()
	return { ok: true, message: cart.totals.couponMessage ?? "تم تطبيق الخصم 🎉" }
}

export async function removeCouponAction(): Promise<ActionResult> {
	await writeCouponCode(null)
	revalidateCartRoutes()
	return { ok: true, message: "تم إلغاء الكوبون." }
}

export async function toggleWishlistAction(
	input: { productId: string },
): Promise<ActionResult<{ inWishlist: boolean }>> {
	const parsed = wishlistSchema.safeParse(input)
	if (!parsed.success) return { ok: false, error: firstError(parsed.error) }

	const user = await getUser()
	if (!user) return { ok: false, error: "سجل دخولك عشان تحفظ مفضلاتك." }

	const supabase = await createClient()
	const { data: existing } = await supabase
		.from("wishlist")
		.select("id")
		.eq("product_id", parsed.data.productId)
		.maybeSingle<{ id: string }>()

	if (existing) {
		const { error } = await supabase.from("wishlist").delete().eq("id", existing.id)
		if (error) return actionError(error)
		revalidatePath("/wishlist")
		return { ok: true, data: { inWishlist: false }, message: "تم الحذف من المفضلة." }
	}

	const { error } = await supabase
		.from("wishlist")
		.insert({ user_id: user.id, product_id: parsed.data.productId })
	if (error) return actionError(error)

	revalidatePath("/wishlist")
	return { ok: true, data: { inWishlist: true }, message: "اتضاف لمفضلتك 🤍" }
}
