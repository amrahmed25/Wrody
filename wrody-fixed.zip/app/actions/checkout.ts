"use server"

import { revalidatePath } from "next/cache"
import { redirect } from "next/navigation"
import { getUser } from "@/lib/auth/session"
import { sendTransactionalEmail } from "@/lib/notifications/email"
import { sendWhatsAppOrderNotification } from "@/lib/notifications/whatsapp"
import { getPaymentProvider } from "@/lib/payments"
import { readCouponCode, resolveCartId, writeCouponCode } from "@/lib/services/cart"
import { rememberGuestOrder, trackOrder } from "@/lib/services/orders"
import { createAdminClient } from "@/lib/supabase/admin"
import { createClient } from "@/lib/supabase/server"
import { actionError } from "@/lib/utils/errors"
import { formatPrice } from "@/lib/utils/format"
import { checkoutSchema, trackOrderSchema } from "@/lib/validations/checkout"
import { fieldErrors, firstError, uuidSchema } from "@/lib/validations/common"
import type { ActionResult } from "@/types"

type PlaceOrderResult = {
	order_id: string
	order_number: string
	subtotal?: number
	discount?: number
	delivery_fee?: number
	total: number
	duplicate: boolean
}

/**
 * The only way an order is ever created.
 *
 * Nothing money-related comes from the browser: the RPC re-reads every cart
 * line from the database, re-prices it, re-validates the coupon, recomputes the
 * delivery fee, locks and decrements stock, and stores address/price snapshots
 * — all inside one transaction. The client only supplies contact details, the
 * payment method and an idempotency key.
 */
export async function placeOrderAction(
	_prev: ActionResult | null,
	formData: FormData,
): Promise<ActionResult> {
	const parsed = checkoutSchema.safeParse({
		fullName: formData.get("fullName"),
		phone: formData.get("phone"),
		email: formData.get("email") ?? "",
		city: formData.get("city"),
		area: formData.get("area"),
		street: formData.get("street"),
		building: formData.get("building"),
		floor: formData.get("floor"),
		apartment: formData.get("apartment"),
		additionalInfo: formData.get("additionalInfo"),
		notes: formData.get("notes"),
		paymentMethod: formData.get("paymentMethod") ?? "cod",
		saveAddress: formData.get("saveAddress") === "on" || formData.get("saveAddress") === "true",
		idempotencyKey: formData.get("idempotencyKey"),
	})

	if (!parsed.success) {
		return { ok: false, error: firstError(parsed.error), fieldErrors: fieldErrors(parsed.error) }
	}

	const provider = getPaymentProvider(parsed.data.paymentMethod)
	if (!provider || !provider.enabled) {
		return { ok: false, error: "طريقة الدفع مش متاحة حاليًا. اختار الدفع عند الاستلام." }
	}

	const cartId = await resolveCartId({ create: false })
	if (!cartId) return { ok: false, error: "السلة فارضة. اختار وردك الأول 🤍" }

	const user = await getUser()
	const couponCode = await readCouponCode()

	const address = {
		full_name: parsed.data.fullName,
		phone: parsed.data.phone,
		city: parsed.data.city,
		area: parsed.data.area,
		street: parsed.data.street,
		building: parsed.data.building,
		floor: parsed.data.floor,
		apartment: parsed.data.apartment,
		additional_info: parsed.data.additionalInfo,
	}

	// Service role: guests have no JWT, and carts are service-role-only by RLS.
	// Ownership is proven by the httpOnly cart cookie (or auth.uid) and re-checked
	// inside place_order().
	const admin = createAdminClient()
	const { data, error } = await admin.rpc("place_order", {
		p_cart_id: cartId,
		p_user_id: user?.id ?? null,
		p_customer: {
			name: parsed.data.fullName,
			phone: parsed.data.phone,
			email: parsed.data.email || user?.email || "",
		},
		p_address: address,
		p_payment_method: parsed.data.paymentMethod,
		p_coupon_code: couponCode,
		p_notes: parsed.data.notes,
		p_idempotency_key: parsed.data.idempotencyKey,
	})

	if (error) return actionError(error, "مقدرناش نكمل الطلب. حاول تاني.")

	const order = data as PlaceOrderResult
	if (!order?.order_number) return { ok: false, error: "مقدرناش نكمل الطلب. حاول تاني." }

	if (!order.duplicate) {
		await writeCouponCode(null)

		if (user && parsed.data.saveAddress) {
			const supabase = await createClient()
			await supabase.from("addresses").insert({
				user_id: user.id,
				full_name: parsed.data.fullName,
				phone: parsed.data.phone,
				city: parsed.data.city,
				area: parsed.data.area,
				street: parsed.data.street,
				building: parsed.data.building,
				floor: parsed.data.floor,
				apartment: parsed.data.apartment,
				additional_info: parsed.data.additionalInfo,
			})
		}

		if (!user) await rememberGuestOrder(order.order_number)

		// Payment hand-off. Cash on delivery needs no action and the order stays
		// payment_status = 'pending' until an admin confirms the cash.
		const initiation = await provider.initiate({
			orderId: order.order_id,
			orderNumber: order.order_number,
			amount: order.total,
			customerName: parsed.data.fullName,
			customerPhone: parsed.data.phone,
			customerEmail: parsed.data.email || null,
		})

		const recipient = parsed.data.email || user?.email
		if (recipient) {
			await sendTransactionalEmail({
				to: recipient,
				template: "order_confirmation",
				subject: `تم استلام طلبك #${order.order_number}`,
				heading: `شكرًا ${parsed.data.fullName} 🤍`,
				lines: [
					`استلمنا طلبك <b>#${order.order_number}</b> وبنجهزه بإيدينا.`,
					`الإجمالي: ${formatPrice(order.total)} — الدفع: ${provider.label}`,
				],
				ctaLabel: "تتبع الطلب",
				ctaUrl: `/track?order=${order.order_number}`,
			})
		}

		await sendWhatsAppOrderNotification({
			orderNumber: order.order_number,
			total: order.total,
			customerName: parsed.data.fullName,
			customerPhone: parsed.data.phone,
			items: [],
		})

		revalidatePath("/cart")
		revalidatePath("/orders")
		revalidatePath("/admin/orders")

		if (initiation.kind === "redirect") redirect(initiation.url)
	}

	redirect(`/order/${order.order_number}`)
}

/** Public tracking form: order number + the phone on the order. */
export async function trackOrderAction(
	_prev: ActionResult | null,
	formData: FormData,
): Promise<ActionResult<Awaited<ReturnType<typeof trackOrder>>>> {
	const parsed = trackOrderSchema.safeParse({
		orderNumber: formData.get("orderNumber"),
		phone: formData.get("phone"),
	})
	if (!parsed.success) return { ok: false, error: firstError(parsed.error) }

	try {
		const result = await trackOrder(parsed.data.orderNumber, parsed.data.phone)
		if (!result?.found) {
			return { ok: false, error: "ملقيناش طلب بالبيانات دي. راجع رقم الطلب والموبايل." }
		}
		return { ok: true, data: result }
	} catch (error) {
		return actionError(error, "مقدرناش نجيب حالة الطلب.")
	}
}

/** Customers may cancel only their own order, and only while it is early. */
export async function cancelOrderAction(orderId: string): Promise<ActionResult> {
	if (!uuidSchema.safeParse(orderId).success) return { ok: false, error: "طلب غير صالح." }

	const user = await getUser()
	if (!user) return { ok: false, error: "لازم تسجل دخول الأول." }

	const supabase = await createClient()
	const { error } = await supabase.rpc("cancel_own_order", { p_order_id: orderId })
	if (error) return actionError(error, "مقدرناش نلغي الطلب.")

	revalidatePath("/orders")
	revalidatePath("/admin/orders")
	return { ok: true, message: "تم إلغاء الطلب ورجعنا الكميات للمخزون." }
}
