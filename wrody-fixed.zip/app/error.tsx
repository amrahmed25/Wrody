"use client"

import { RotateCcw } from "lucide-react"
import { useEffect } from "react"
import { Button, ButtonLink } from "@/components/ui/button"

export default function GlobalError({
	error,
	reset,
}: {
	error: Error & { digest?: string }
	reset: () => void
}) {
	useEffect(() => {
		// TODO: forward to an error tracker (Sentry/Vercel) when credentials exist.
		console.error(error)
	}, [error])

	return (
		<div className="flex min-h-[60vh] flex-col items-center justify-center gap-5 px-6 text-center">
			<h1 className="text-display-sm">حصل خطأ مش متوقع</h1>
			<p className="max-w-sm text-sm text-ink-soft">
				جرب تحدّث الصفحة تاني. لو المشكلة فضلت، كلمنا على واتساب وإحنا نساعدك.
			</p>
			{error.digest ? (
				<p className="nums text-xs text-ink-muted">كود الخطأ: {error.digest}</p>
			) : null}
			<div className="flex flex-wrap justify-center gap-3">
				<Button onClick={reset}>
					<RotateCcw className="h-4 w-4" />
					حاول تاني
				</Button>
				<ButtonLink href="/" variant="outline">
					الرئيسية
				</ButtonLink>
			</div>
		</div>
	)
}
