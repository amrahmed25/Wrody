import Link from "next/link"
import { Logo } from "@/components/shared/logo"
import { ButtonLink } from "@/components/ui/button"

export default function NotFound() {
	return (
		<div className="flex min-h-dvh flex-col items-center justify-center gap-6 bg-cream px-6 text-center">
			<Link href="/" aria-label="ورودي">
				<Logo size={44} />
			</Link>
			<p className="nums font-display text-6xl font-bold text-rose-200">404</p>
			<div>
				<h1 className="text-display-sm">الصفحة دي مش موجودة</h1>
				<p className="mt-3 max-w-sm text-sm text-ink-soft">
					يمكن اللينك اتغير أو المنتج اتشال. تعرف ترجع للمتجر وتكمل تفرج.
				</p>
			</div>
			<div className="flex flex-wrap justify-center gap-3">
				<ButtonLink href="/shop">روح للمتجر</ButtonLink>
				<ButtonLink href="/" variant="outline">
					الصفحة الرئيسية
				</ButtonLink>
			</div>
		</div>
	)
}
