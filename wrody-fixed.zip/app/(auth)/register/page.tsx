import type { Metadata } from "next"
import Link from "next/link"
import { redirect } from "next/navigation"
import { RegisterForm } from "@/components/auth/auth-forms"
import { getUser } from "@/lib/auth/session"

export const metadata: Metadata = {
	title: "حساب جديد",
	robots: { index: false, follow: false },
}

export default async function RegisterPage({
	searchParams,
}: {
	searchParams: Promise<Record<string, string | string[] | undefined>>
}) {
	const params = await searchParams
	const raw = Array.isArray(params.next) ? params.next[0] : params.next
	const next = raw && raw.startsWith("/") && !raw.startsWith("//") ? raw : undefined

	if (await getUser()) redirect(next ?? "/account")

	return (
		<div className="w-full">
			<h1 className="font-display text-2xl font-bold">اعمل حساب في ورودي</h1>
			<p className="mt-2 text-sm text-ink-soft">
				الحساب بيخليك تتابع طلباتك، تحفظ عناوينك، وتقيم المنتجات اللي اشتريتها.
			</p>

			<div className="mt-6">
				<RegisterForm next={next} />
			</div>

			<p className="mt-5 text-sm text-ink-soft">
				عندك حساب بالفعل؟{" "}
				<Link
					href={next ? `/login?next=${encodeURIComponent(next)}` : "/login"}
					className="font-medium text-rose-700 transition-colors hover:text-rose-500"
				>
					سجل دخولك
				</Link>
			</p>
		</div>
	)
}
