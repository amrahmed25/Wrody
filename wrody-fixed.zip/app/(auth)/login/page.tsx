import type { Metadata } from "next"
import Link from "next/link"
import { redirect } from "next/navigation"
import { LoginForm } from "@/components/auth/auth-forms"
import { getUser } from "@/lib/auth/session"

export const metadata: Metadata = {
	title: "تسجيل الدخول",
	robots: { index: false, follow: false },
}

export default async function LoginPage({
	searchParams,
}: {
	searchParams: Promise<Record<string, string | string[] | undefined>>
}) {
	const params = await searchParams
	const raw = Array.isArray(params.next) ? params.next[0] : params.next
	// Only relative paths are allowed, so the redirect cannot leave the site.
	const next = raw && raw.startsWith("/") && !raw.startsWith("//") ? raw : undefined

	if (await getUser()) redirect(next ?? "/account")

	return (
		<div className="w-full">
			<h1 className="font-display text-2xl font-bold">أهلًا بيك تاني 🤍</h1>
			<p className="mt-2 text-sm text-ink-soft">سجل دخولك عشان تتابع طلباتك وتحفظ مفضلاتك.</p>

			<div className="mt-6">
				<LoginForm next={next} />
			</div>

			<div className="mt-5 space-y-2 text-sm">
				<p className="text-ink-soft">
					لسة معملتش حساب؟{" "}
					<Link
						href={next ? `/register?next=${encodeURIComponent(next)}` : "/register"}
						className="font-medium text-rose-700 transition-colors hover:text-rose-500"
					>
						اعمل حساب جديد
					</Link>
				</p>
				<p>
					<Link href="/reset-password" className="text-ink-muted transition-colors hover:text-rose-700">
						نسيت كلمة السر؟
					</Link>
				</p>
			</div>
		</div>
	)
}
