import Link from "next/link"
import type { ReactNode } from "react"
import { Logo } from "@/components/shared/logo"

export default function AuthLayout({ children }: { children: ReactNode }) {
	return (
		<div className="flex min-h-dvh flex-col bg-rose-fade">
			<header className="container-page flex items-center justify-between py-6">
				<Link href="/" aria-label="ورودي — الصفحة الرئيسية">
					<Logo />
				</Link>
				<Link href="/shop" className="text-sm text-ink-soft transition-colors hover:text-rose-700">
					المتجر
				</Link>
			</header>
			<main className="container-page flex flex-1 items-center justify-center py-10">
				<div className="w-full max-w-md">{children}</div>
			</main>
			<footer className="container-page py-6 text-center text-xs text-ink-muted">
				ورد معمول بحب 🤍
			</footer>
		</div>
	)
}
