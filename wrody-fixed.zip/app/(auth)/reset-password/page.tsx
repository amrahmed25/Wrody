import type { Metadata } from "next"
import Link from "next/link"
import { ResetRequestForm, UpdatePasswordForm } from "@/components/auth/auth-forms"

export const metadata: Metadata = {
	title: "استعادة كلمة السر",
	robots: { index: false, follow: false },
}

export default async function ResetPasswordPage({
	searchParams,
}: {
	searchParams: Promise<Record<string, string | string[] | undefined>>
}) {
	const params = await searchParams
	const stage = Array.isArray(params.stage) ? params.stage[0] : params.stage
	const isUpdate = stage === "update"

	return (
		<div className="w-full">
			<h1 className="font-display text-2xl font-bold">
				{isUpdate ? "اختار كلمة سر جديدة" : "نسيت كلمة السر؟"}
			</h1>
			<p className="mt-2 text-sm text-ink-soft">
				{isUpdate
					? "اكتب كلمة السر الجديدة مرتين عشان نتأكد إنها مظبوطة."
					: "اكتب بريدك وهنبعتلك رابط لإعادة تعيين كلمة السر."}
			</p>

			<div className="mt-6">{isUpdate ? <UpdatePasswordForm /> : <ResetRequestForm />}</div>

			<p className="mt-5 text-sm">
				<Link href="/login" className="text-ink-muted transition-colors hover:text-rose-700">
					رجوع لتسجيل الدخول
				</Link>
			</p>
		</div>
	)
}
