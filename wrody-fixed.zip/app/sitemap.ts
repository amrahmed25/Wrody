import type { MetadataRoute } from "next"
import { siteConfig } from "@/lib/config/site"
import { getCategories, getSitemapProducts } from "@/lib/services/catalog"

export const revalidate = 3600

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
	const staticRoutes: MetadataRoute.Sitemap = [
		{ url: siteConfig.url, changeFrequency: "weekly", priority: 1 },
		{ url: `${siteConfig.url}/shop`, changeFrequency: "daily", priority: 0.9 },
		{ url: `${siteConfig.url}/custom-bouquet`, changeFrequency: "monthly", priority: 0.8 },
		{ url: `${siteConfig.url}/about`, changeFrequency: "yearly", priority: 0.4 },
		{ url: `${siteConfig.url}/track`, changeFrequency: "yearly", priority: 0.3 },
	]

	try {
		const [products, categories] = await Promise.all([getSitemapProducts(), getCategories()])
		return [
			...staticRoutes,
			...categories.map((category) => ({
				url: `${siteConfig.url}/shop?category=${category.slug}`,
				changeFrequency: "weekly" as const,
				priority: 0.6,
			})),
			...products.map((product) => ({
				url: `${siteConfig.url}/product/${product.slug}`,
				lastModified: product.updated_at ?? undefined,
				changeFrequency: "weekly" as const,
				priority: 0.8,
			})),
		]
	} catch {
		return staticRoutes
	}
}
