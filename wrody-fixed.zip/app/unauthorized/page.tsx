import { ShieldAlert } from "lucide-react"
import type { Metadata } from "next"
import { ButtonLink } from "@/components/ui/button"

export const metadata: Metadata = { title: "مفيش صلاحية", robots: { index: false, follow: false } }

export default function UnauthorizedPage() {
	return (
		<div className="flex min-h-dvh flex-col items-center justify-center gap-5 bg-cream px-6 text-center">
			<span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-rose-50 text-rose-500">
				<ShieldAlert className="h-6 w-6" />
			</span>
			<h1 className="text-display-sm">مفيش صلاحية للوصول</h1>
			<p className="max-w-sm text-sm text-ink-soft">
				الصفحة دي مخصصة لفريق ورودي فقط. لو محتاج وصول إداري، اطلب من مالك المتجر يرقي حسابك.
			</p>
			<div className="flex flex-wrap justify-center gap-3">
				<ButtonLink href="/">الرئيسية</ButtonLink>
				<ButtonLink href="/shop" variant="outline">
					المتجر
				</ButtonLink>
			</div>
		</div>
	)
}
