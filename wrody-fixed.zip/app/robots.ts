import type { MetadataRoute } from "next"
import { siteConfig } from "@/lib/config/site"

export default function robots(): MetadataRoute.Robots {
	return {
		rules: [
			{
				userAgent: "*",
				allow: "/",
				disallow: ["/admin", "/api/", "/account", "/cart", "/checkout", "/orders", "/unauthorized"],
			},
		],
		sitemap: `${siteConfig.url}/sitemap.xml`,
		host: siteConfig.url,
	}
}
