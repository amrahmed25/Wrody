import { NextResponse } from "next/server"
import { mergeGuestCart } from "@/lib/services/cart"
import { createClient } from "@/lib/supabase/server"

/**
 * Supabase Auth redirect target: exchanges the PKCE code for a session cookie,
 * merges any guest cart into the user cart, then continues to `next`.
 * `next` is validated to be a relative path so it cannot be used as an open redirect.
 */
export async function GET(request: Request) {
	const url = new URL(request.url)
	const code = url.searchParams.get("code")
	const rawNext = url.searchParams.get("next") ?? "/account"
	const next = rawNext.startsWith("/") && !rawNext.startsWith("//") ? rawNext : "/account"

	if (!code) {
		return NextResponse.redirect(new URL("/login?error=auth", url.origin))
	}

	const supabase = await createClient()
	const { data, error } = await supabase.auth.exchangeCodeForSession(code)

	if (error || !data.user) {
		return NextResponse.redirect(new URL("/login?error=auth", url.origin))
	}

	try {
		await mergeGuestCart(data.user.id)
	} catch {
		// A failed merge must never block sign-in; the guest cart stays intact.
	}

	return NextResponse.redirect(new URL(next, url.origin))
}
