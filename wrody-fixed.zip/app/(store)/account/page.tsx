import { LogOut, PackageSearch, Sparkles } from "lucide-react"
import type { Metadata } from "next"
import Link from "next/link"
import { signOutAction } from "@/app/actions/auth"
import { AddressManager } from "@/components/account/address-manager"
import { ProfileForm } from "@/components/account/profile-form"
import { OrderStatusBadge } from "@/components/orders/order-status"
import { Button, ButtonLink } from "@/components/ui/button"
import { Badge, EmptyState, Rating } from "@/components/ui/display"
import { getProfile, requireUser } from "@/lib/auth/session"
import { getMyAddresses, getMyBouquets, getMyReviews } from "@/lib/services/account"
import { getMyOrders } from "@/lib/services/orders"
import { getDeliveryZones } from "@/lib/services/settings"
import { formatDate, formatPrice } from "@/lib/utils/format"

export const metadata: Metadata = {
	title: "حسابي",
	robots: { index: false, follow: false },
}

type BouquetRow = {
	id: string
	size_slug: string
	total_price: number
	status: string
	created_at: string
	message: string | null
}

export default async function AccountPage() {
	const user = await requireUser()
	const [profile, addresses, orders, reviews, bouquets, zones] = await Promise.all([
		getProfile(),
		getMyAddresses(),
		getMyOrders(),
		getMyReviews(),
		getMyBouquets(),
		getDeliveryZones(),
	])

	const recentOrders = orders.slice(0, 3)
	const myBouquets = (bouquets ?? []) as unknown as BouquetRow[]

	return (
		<div className="container-page py-8 sm:py-12">
			<header className="mb-8 flex flex-wrap items-start justify-between gap-4">
				<div>
					<h1 className="font-display text-display-sm">أهلًا {profile?.full_name ?? "بيك"} 🤍</h1>
					<p className="mt-2 text-sm text-ink-soft">من هنا تقدر تدير بياناتك وعناوينك وتتابع طلباتك.</p>
				</div>
				<form action={signOutAction}>
					<Button type="submit" variant="outline" size="sm">
						<LogOut className="h-4 w-4" />
						تسجيل خروج
					</Button>
				</form>
			</header>

			<div className="grid gap-6 lg:grid-cols-2 lg:items-start">
				<section className="surface p-6">
					<h2 className="mb-4 text-base font-semibold">بياناتي</h2>
					<ProfileForm
						fullName={profile?.full_name ?? ""}
						phone={profile?.phone ?? ""}
						email={profile?.email ?? user.email ?? ""}
					/>
				</section>

				<section className="surface p-6">
					<h2 className="mb-4 text-base font-semibold">عناوين التوصيل</h2>
					<AddressManager addresses={addresses} cities={zones.map((zone) => zone.city)} />
				</section>

				<section className="surface p-6">
					<div className="mb-4 flex items-center justify-between gap-3">
						<h2 className="text-base font-semibold">آخر الطلبات</h2>
						<Link href="/orders" className="text-sm text-rose-700 transition-colors hover:text-rose-500">
							كل الطلبات
						</Link>
					</div>
					{recentOrders.length ? (
						<ul className="divide-y divide-sand">
							{recentOrders.map((order) => (
								<li key={order.id} className="py-3">
									<Link
										href={`/order/${order.order_number}`}
										className="flex items-center justify-between gap-3"
									>
										<span>
											<span className="nums block text-sm font-medium" dir="ltr">
												{order.order_number}
											</span>
											<span className="block text-xs text-ink-muted">{formatDate(order.created_at)}</span>
										</span>
										<span className="flex items-center gap-2">
											<OrderStatusBadge status={order.status} />
											<span className="nums text-sm font-semibold">{formatPrice(order.total)}</span>
										</span>
									</Link>
								</li>
							))}
						</ul>
					) : (
						<EmptyState
							icon={<PackageSearch className="h-6 w-6" />}
							title="مفيش طلبات لسة"
							description="ابدأ من المتجر وهتلاقي طلباتك هنا."
							action={<ButtonLink href="/shop">المتجر</ButtonLink>}
						/>
					)}
				</section>

				<section className="surface p-6">
					<h2 className="mb-4 text-base font-semibold">بوكيهاتي المخصصة</h2>
					{myBouquets.length ? (
						<ul className="divide-y divide-sand">
							{myBouquets.slice(0, 5).map((bouquet) => (
								<li key={bouquet.id} className="flex items-center justify-between gap-3 py-3">
									<span>
										<span className="block text-sm">بوكيه مخصص — {bouquet.size_slug}</span>
										<span className="block text-xs text-ink-muted">{formatDate(bouquet.created_at)}</span>
									</span>
									<span className="nums text-sm font-semibold">{formatPrice(bouquet.total_price)}</span>
								</li>
							))}
						</ul>
					) : (
						<EmptyState
							icon={<Sparkles className="h-6 w-6" />}
							title="مصممتش بوكيه لسة"
							description="جرب تعمل بوكيه بألوانك انت ورسالة من عندك."
							action={<ButtonLink href="/custom-bouquet">اصنع بوكيهك</ButtonLink>}
						/>
					)}
				</section>

				<section className="surface p-6 lg:col-span-2">
					<h2 className="mb-4 text-base font-semibold">تقييماتي</h2>
					{reviews.length ? (
						<ul className="divide-y divide-sand">
							{reviews.map((review) => (
								<li key={review.id} className="py-3">
									<div className="flex flex-wrap items-center justify-between gap-2">
										<Link
											href={review.product?.slug ? `/product/${review.product.slug}` : "/shop"}
											className="text-sm font-medium transition-colors hover:text-rose-700"
										>
											{review.product?.name ?? "منتج"}
										</Link>
										<div className="flex items-center gap-2">
											<Rating value={review.rating} />
											<Badge tone={review.is_approved ? "sage" : "muted"}>
												{review.is_approved ? "منشور" : "تحت المراجعة"}
											</Badge>
										</div>
									</div>
									{review.comment ? (
										<p className="mt-1.5 text-sm leading-relaxed text-ink-soft">{review.comment}</p>
									) : null}
								</li>
							))}
						</ul>
					) : (
						<p className="text-sm text-ink-soft">
							لما تستلم طلب، هتقدر تقيم المنتجات اللي اشتريتها من صفحة المنتج.
						</p>
					)}
				</section>
			</div>
		</div>
	)
}
