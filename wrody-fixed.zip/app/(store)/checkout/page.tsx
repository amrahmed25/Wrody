import { ShoppingBag } from "lucide-react"
import type { Metadata } from "next"
import { CheckoutForm } from "@/components/checkout/checkout-form"
import { ButtonLink } from "@/components/ui/button"
import { EmptyState } from "@/components/ui/display"
import { getProfile, getUser } from "@/lib/auth/session"
import { listEnabledPaymentMethods } from "@/lib/payments"
import { getDefaultAddress } from "@/lib/services/account"
import { getCart } from "@/lib/services/cart"
import { getDeliverySettings, getDeliveryZones } from "@/lib/services/settings"

export const metadata: Metadata = {
	title: "إتمام الطلب",
	robots: { index: false, follow: false },
}

export default async function CheckoutPage() {
	const [cart, zones, delivery, user, profile, address] = await Promise.all([
		getCart(),
		getDeliveryZones(),
		getDeliverySettings(),
		getUser(),
		getProfile(),
		getDefaultAddress(),
	])

	if (!cart.lines.length) {
		return (
			<div className="container-page py-8 sm:py-12">
				<EmptyState
					icon={<ShoppingBag className="h-6 w-6" />}
					title="السلة فارغة"
					description="ضيف بوكيه للسلة الأول، وبعدين نكمّل الطلب."
					action={<ButtonLink href="/shop">روح للمتجر</ButtonLink>}
				/>
			</div>
		)
	}

	return (
		<div className="container-page py-8 sm:py-12">
			<header className="mb-8">
				<p className="text-xs font-semibold uppercase tracking-[0.18em] text-rose-500">الدفع عند الاستلام</p>
				<h1 className="mt-2 font-display text-display-sm">إتمام الطلب</h1>
				<p className="mt-2 max-w-xl text-sm text-ink-soft">
					الأسعار والخصم ومصاريف التوصيل بيتأكدوا على السيرفر لحظة التأكيد. مفيش أي مبلغ بيتخصم أونلاين.
				</p>
			</header>

			<CheckoutForm
				cart={cart}
				zones={zones}
				defaultFee={delivery.default_fee}
				freeThreshold={delivery.free_threshold ?? 0}
				paymentMethods={listEnabledPaymentMethods()}
				isSignedIn={Boolean(user)}
				defaults={{
					fullName: address?.full_name ?? profile?.full_name,
					phone: address?.phone ?? profile?.phone,
					email: profile?.email ?? user?.email,
					city: address?.city,
					area: address?.area,
					street: address?.street,
					building: address?.building,
					floor: address?.floor,
					apartment: address?.apartment,
					additionalInfo: address?.additional_info,
				}}
			/>
		</div>
	)
}
