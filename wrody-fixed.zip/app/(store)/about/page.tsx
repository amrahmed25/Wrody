import type { Metadata } from "next"
import Image from "next/image"
import { WhyWrody } from "@/components/home/sections"
import { ButtonLink } from "@/components/ui/button"
import { SectionHeading } from "@/components/ui/display"
import { siteConfig } from "@/lib/config/site"

export const metadata: Metadata = {
	title: "عن ورودي",
	description:
		"ورودي براند مصري لورد الهاند ميد من خامة الـPipe Cleaners — بوكيهات تفضل معاك، ومعمولة بإيدينا قطعة قطعة.",
	alternates: { canonical: "/about" },
}

export default function AboutPage() {
	return (
		<div className="pb-16 sm:pb-24">
			<section className="container-page grid items-center gap-10 py-12 lg:grid-cols-2 lg:gap-16 lg:py-20">
				<div>
					<p className="text-xs font-semibold uppercase tracking-[0.18em] text-rose-500">عن ورودي</p>
					<h1 className="mt-3 font-display text-display-sm sm:text-display-md">{siteConfig.tagline}</h1>
					<p className="mt-5 max-w-xl text-base leading-relaxed text-ink-soft">
						ورودي مش محل ورد بيتقطع الصبح ويذبل بالليل. إحنا بنلف كل بتلة بإيدينا من خامة الـPipe
						Cleaners، عشان الهدية تفضل شكلها وحكايتها بعد ما المناسبة تعدي.
					</p>
					<p className="mt-4 max-w-xl text-base leading-relaxed text-ink-soft">
						من البوكيه الجاهز لحد البوكيه اللي بتصممه بنفسك: الورد، العدد، الحجم، التغليف، والكارت.
						والتوصيل داخل مصر مع الدفع عند الاستلام.
					</p>
					<div className="mt-8 flex flex-wrap gap-3">
						<ButtonLink href="/shop" size="lg">
							تسوق الآن
						</ButtonLink>
						<ButtonLink href="/custom-bouquet" size="lg" variant="outline">
							اصنع بوكيهك
						</ButtonLink>
					</div>
				</div>
				<div className="relative mx-auto aspect-[4/5] w-full max-w-md overflow-hidden rounded-[2.5rem] border border-sand bg-ivory shadow-lift">
					<Image
						src="/hero-bouquet.svg"
						alt="بوكيه ورودي الهاند ميد"
						fill
						priority
						sizes="(max-width: 1024px) 90vw, 420px"
						className="object-cover"
					/>
				</div>
			</section>

			<section className="container-page">
				<SectionHeading eyebrow="قيمنا" title="إزاي بنشتغل" center />
				<WhyWrody />
			</section>
		</div>
	)
}
