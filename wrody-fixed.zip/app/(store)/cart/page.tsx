import type { Metadata } from "next"
import { CartView } from "@/components/cart/cart-view"
import { getCart } from "@/lib/services/cart"

export const metadata: Metadata = {
	title: "السلة",
	robots: { index: false, follow: false },
}

export default async function CartPage() {
	const cart = await getCart()

	return (
		<div className="container-page py-8 sm:py-12">
			<header className="mb-8">
				<h1 className="font-display text-display-sm">السلة</h1>
				<p className="nums mt-2 text-sm text-ink-soft">
					{cart.count ? `${cart.count} منتج في سلتك` : "السلة فارغة دلوقتي"}
				</p>
			</header>
			<CartView cart={cart} />
		</div>
	)
}
