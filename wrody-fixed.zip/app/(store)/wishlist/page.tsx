import { Heart } from "lucide-react"
import type { Metadata } from "next"
import { ProductGrid } from "@/components/product/product-grid"
import { ButtonLink } from "@/components/ui/button"
import { requireUser } from "@/lib/auth/session"
import { getWishlist } from "@/lib/services/account"

export const metadata: Metadata = {
	title: "المفضلة",
	robots: { index: false, follow: false },
}

export default async function WishlistPage() {
	await requireUser()
	const products = await getWishlist()
	const wishlistIds = new Set(products.map((product) => product.id))

	return (
		<div className="container-page py-8 sm:py-12">
			<header className="mb-6">
				<h1 className="font-display text-display-sm">المفضلة</h1>
				<p className="nums mt-2 text-sm text-ink-soft">
					{products.length ? `${products.length} منتج حافطت عليه` : "لسة مفيش منتجات محفوظة"}
				</p>
			</header>

			<ProductGrid
				products={products}
				wishlistIds={wishlistIds}
				columns={4}
				emptyTitle="قائمة المفضلة فارغة"
				emptyDescription="دوس على القلب في أي منتج عشان ترجعله بعدين."
				emptyAction={
					<ButtonLink href="/shop">
						<Heart className="h-4 w-4" />
						اتفرج على المنتجات
					</ButtonLink>
				}
			/>
		</div>
	)
}
