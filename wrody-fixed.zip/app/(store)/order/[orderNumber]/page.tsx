import { MessageCircle, Truck } from "lucide-react"
import type { Metadata } from "next"
import Image from "next/image"
import { notFound } from "next/navigation"
import { CancelOrderButton } from "@/components/orders/cancel-order-button"
import { OrderStatusBadge, OrderTimeline } from "@/components/orders/order-status"
import { ButtonLink } from "@/components/ui/button"
import { buildWhatsAppOrderLink } from "@/lib/notifications/whatsapp"
import { getOrderForViewer } from "@/lib/services/orders"
import {
	formatDateTime,
	formatPrice,
	PAYMENT_METHOD_LABELS,
	PAYMENT_STATUS_LABELS,
} from "@/lib/utils/format"

type AddressSnapshot = {
	fullName?: string
	phone?: string
	city?: string
	area?: string
	street?: string
	building?: string
	floor?: string
	apartment?: string
	additionalInfo?: string
}

export async function generateMetadata({
	params,
}: {
	params: Promise<{ orderNumber: string }>
}): Promise<Metadata> {
	const { orderNumber } = await params
	return {
		title: `الطلب ${orderNumber}`,
		robots: { index: false, follow: false },
	}
}

export default async function OrderPage({ params }: { params: Promise<{ orderNumber: string }> }) {
	const { orderNumber } = await params
	const order = await getOrderForViewer(orderNumber)
	if (!order) notFound()

	const address = (order.shipping_address_snapshot ?? {}) as unknown as AddressSnapshot
	const whatsappLink = buildWhatsAppOrderLink({
		orderNumber: order.order_number,
		total: order.total,
		customerName: order.customer_name,
		customerPhone: order.customer_phone,
		items: order.items.map((item) => ({ name: item.product_name, quantity: item.quantity })),
	})
	const cancellable = order.status === "pending" || order.status === "confirmed"
	const addressLines = [
		address.street,
		address.building ? `عمارة ${address.building}` : null,
		address.floor ? `الدور ${address.floor}` : null,
		address.apartment ? `شقة ${address.apartment}` : null,
	]
		.filter(Boolean)
		.join(" — ")

	return (
		<div className="container-page py-8 sm:py-12">
			<div className="mx-auto max-w-3xl space-y-6">
				<section className="surface p-6">
					<div className="flex flex-wrap items-start justify-between gap-4">
						<div>
							<p className="text-xs font-semibold uppercase tracking-[0.18em] text-rose-500">
								تم استلام طلبك 🤍
							</p>
							<h1 className="nums mt-2 font-display text-display-sm" dir="ltr">
								{order.order_number}
							</h1>
							<p className="mt-1 text-xs text-ink-muted">{formatDateTime(order.created_at)}</p>
						</div>
						<div className="flex flex-col items-start gap-2 sm:items-end">
							<OrderStatusBadge status={order.status} />
							<span className="text-xs text-ink-soft">
								{PAYMENT_METHOD_LABELS[order.payment_method]} — {PAYMENT_STATUS_LABELS[order.payment_status]}
							</span>
						</div>
					</div>

					<div className="mt-6 flex flex-wrap gap-3">
						{whatsappLink ? (
							<ButtonLink href={whatsappLink} variant="sage" target="_blank" rel="noopener noreferrer">
								<MessageCircle className="h-4 w-4" />
								تأكيد الطلب عبر WhatsApp
							</ButtonLink>
						) : null}
						<ButtonLink href={`/track?order=${order.order_number}`} variant="outline">
							<Truck className="h-4 w-4" />
							تتبع الطلب
						</ButtonLink>
						{cancellable ? <CancelOrderButton orderId={order.id} /> : null}
					</div>
				</section>

				<section className="surface p-6">
					<h2 className="mb-4 text-base font-semibold">حالة الطلب</h2>
					<OrderTimeline status={order.status} events={order.events ?? []} />
				</section>

				<section className="surface p-6">
					<h2 className="mb-4 text-base font-semibold">المنتجات</h2>
					<ul className="divide-y divide-sand">
						{order.items.map((item) => (
							<li key={item.id} className="flex items-start gap-3 py-3">
								<div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-2xl bg-cream">
									<Image
										src={item.image_url ?? "/flowers/tulip.svg"}
										alt={item.product_name}
										fill
										sizes="64px"
										className="object-cover"
									/>
								</div>
								<div className="min-w-0 flex-1">
									<p className="text-sm font-medium">{item.product_name}</p>
									{item.variant_name ? (
										<p className="text-xs text-ink-muted">{item.variant_name}</p>
									) : null}
									<p className="nums mt-1 text-xs text-ink-muted">
										{item.quantity} × {formatPrice(item.unit_price)}
									</p>
								</div>
								<span className="nums shrink-0 text-sm font-semibold">{formatPrice(item.total_price)}</span>
							</li>
						))}
					</ul>

					<dl className="mt-5 space-y-2 border-t border-sand pt-4 text-sm">
						<div className="flex items-center justify-between">
							<dt className="text-ink-soft">المجموع</dt>
							<dd className="nums">{formatPrice(order.subtotal)}</dd>
						</div>
						{order.discount > 0 ? (
							<div className="flex items-center justify-between text-sage-700">
								<dt>الخصم{order.coupon_code ? ` (${order.coupon_code})` : ""}</dt>
								<dd className="nums">− {formatPrice(order.discount)}</dd>
							</div>
						) : null}
						<div className="flex items-center justify-between">
							<dt className="text-ink-soft">التوصيل</dt>
							<dd className="nums">
								{order.delivery_fee > 0 ? formatPrice(order.delivery_fee) : "مجانًا"}
							</dd>
						</div>
						<div className="flex items-center justify-between border-t border-sand pt-3 text-base font-semibold">
							<dt>الإجمالي</dt>
							<dd className="nums">{formatPrice(order.total)}</dd>
						</div>
					</dl>
				</section>

				<section className="surface p-6">
					<h2 className="mb-3 text-base font-semibold">بيانات التوصيل</h2>
					<p className="text-sm">{order.customer_name}</p>
					<p className="nums text-sm text-ink-soft" dir="ltr">
						{order.customer_phone}
					</p>
					<p className="mt-2 text-sm leading-relaxed text-ink-soft">
						{[address.city, address.area].filter(Boolean).join(" — ")}
						{addressLines ? <br /> : null}
						{addressLines}
						{address.additionalInfo ? (
							<>
								<br />
								{address.additionalInfo}
							</>
						) : null}
					</p>
					{order.notes ? (
						<p className="mt-3 rounded-2xl bg-cream px-4 py-3 text-xs leading-relaxed text-ink-soft">
							ملاحظات: {order.notes}
						</p>
					) : null}
					<p className="mt-3 text-xs text-ink-muted">
						العنوان والأسعار محفوطين كنسخة داخل الطلب، فما بيتأثروش لو غيرت بياناتك بعدين.
					</p>
				</section>
			</div>
		</div>
	)
}
