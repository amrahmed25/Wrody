import type { ReactNode } from "react"
import { SiteFooter } from "@/components/layout/footer"
import { SiteHeader } from "@/components/layout/header"

export default function StoreLayout({ children }: { children: ReactNode }) {
	return (
		<div className="flex min-h-dvh flex-col">
			<a
				href="#main"
				className="sr-only focus:not-sr-only focus:absolute focus:start-4 focus:top-4 focus:z-[95] focus:rounded-full focus:bg-ink focus:px-5 focus:py-3 focus:text-cream"
			>
				تخطى إلى المحتوى
			</a>
			<SiteHeader />
			<main id="main" className="flex-1">
				{children}
			</main>
			<SiteFooter />
		</div>
	)
}
