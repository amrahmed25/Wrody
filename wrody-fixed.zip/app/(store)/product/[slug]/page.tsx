import type { Metadata } from "next"
import Link from "next/link"
import { notFound } from "next/navigation"
import { ProductActions } from "@/components/product/product-actions"
import { ProductGallery } from "@/components/product/product-gallery"
import { ProductGrid } from "@/components/product/product-grid"
import { ProductReviews } from "@/components/product/product-reviews"
import { JsonLd } from "@/components/shared/json-ld"
import { Badge, Price, Rating, SectionHeading } from "@/components/ui/display"
import { getUser } from "@/lib/auth/session"
import { siteConfig } from "@/lib/config/site"
import { getWishlistProductIds } from "@/lib/services/account"
import {
	buildVariantOptionGroups,
	getProductBySlug,
	getProductReviews,
	getRelatedProducts,
} from "@/lib/services/catalog"
import { createClient } from "@/lib/supabase/server"
import { truncate } from "@/lib/utils/format"

type Params = { slug: string }

export async function generateMetadata({
	params,
}: {
	params: Promise<Params>
}): Promise<Metadata> {
	const { slug } = await params
	const product = await getProductBySlug(slug)
	if (!product) return { title: "المنتج غير موجود" }

	const description = product.short_description || truncate(product.description ?? siteConfig.description, 160)
	const image = product.images[0]?.image_url

	return {
		title: product.name,
		description,
		alternates: { canonical: `/product/${product.slug}` },
		openGraph: {
			title: product.name,
			description,
			url: `/product/${product.slug}`,
			images: image ? [{ url: image, alt: product.name }] : undefined,
		},
	}
}

export default async function ProductPage({ params }: { params: Promise<Params> }) {
	const { slug } = await params
	const product = await getProductBySlug(slug)
	if (!product) notFound()

	const [reviews, related, wishlistIds, user] = await Promise.all([
		getProductReviews(product.id),
		getRelatedProducts(product.id, product.category_id),
		getWishlistProductIds(),
		getUser(),
	])

	let canReview = false
	if (user) {
		const supabase = await createClient()
		const { data } = await supabase.rpc("can_review", { p_product_id: product.id })
		canReview = data === true
	}

	const optionGroups = buildVariantOptionGroups(product.variants)
	const inWishlist = wishlistIds.has(product.id)
	const image = product.images[0]?.image_url ?? `/products/${product.slug}-1.svg`
	const soldOut = product.stock <= 0 && product.variants.every((variant) => variant.stock <= 0)

	return (
		<div className="container-page py-8 sm:py-12">
			<JsonLd
				data={[
					{
						"@context": "https://schema.org",
						"@type": "BreadcrumbList",
						itemListElement: [
							{ "@type": "ListItem", position: 1, name: "الرئيسية", item: siteConfig.url },
							{ "@type": "ListItem", position: 2, name: "المتجر", item: `${siteConfig.url}/shop` },
							{
								"@type": "ListItem",
								position: 3,
								name: product.name,
								item: `${siteConfig.url}/product/${product.slug}`,
							},
						],
					},
					{
						"@context": "https://schema.org",
						"@type": "Product",
						name: product.name,
						description: product.short_description || product.description,
						image,
						sku: product.sku ?? product.slug,
						brand: { "@type": "Brand", name: siteConfig.name },
						offers: {
							"@type": "Offer",
							url: `${siteConfig.url}/product/${product.slug}`,
							priceCurrency: siteConfig.currency,
							price: product.price,
							availability: soldOut ? "https://schema.org/OutOfStock" : "https://schema.org/InStock",
						},
						...(product.rating_count > 0
							? {
									aggregateRating: {
										"@type": "AggregateRating",
										ratingValue: product.rating_avg,
										reviewCount: product.rating_count,
									},
							  }
							: {}),
					},
				]}
			/>

			<nav aria-label="مسار الصفحة" className="mb-6 text-sm text-ink-muted">
				<ol className="flex flex-wrap items-center gap-2">
					<li>
						<Link href="/" className="transition-colors hover:text-rose-700">
							الرئيسية
						</Link>
					</li>
					<li aria-hidden="true">/</li>
					<li>
						<Link href="/shop" className="transition-colors hover:text-rose-700">
							المتجر
						</Link>
					</li>
					{product.category ? (
						<>
							<li aria-hidden="true">/</li>
							<li>
								<Link
									href={`/shop?category=${product.category.slug}`}
									className="transition-colors hover:text-rose-700"
								>
									{product.category.name}
								</Link>
							</li>
						</>
					) : null}
					<li aria-hidden="true">/</li>
					<li className="text-ink">{product.name}</li>
				</ol>
			</nav>

			<div className="grid gap-10 lg:grid-cols-[1.05fr_1fr] lg:items-start">
				<ProductGallery images={product.images} productName={product.name} fallbackSlug={product.slug} />

				<div>
					{product.category ? (
						<p className="text-xs font-semibold uppercase tracking-[0.18em] text-rose-500">
							{product.category.name}
						</p>
					) : null}
					<h1 className="mt-2 font-display text-display-sm sm:text-display-md">{product.name}</h1>

					<div className="mt-4 flex flex-wrap items-center gap-3">
						<Price value={product.price} compareAt={product.compare_at_price} size="lg" />
						{soldOut ? <Badge tone="muted">خلص من المخزن</Badge> : null}
						{product.is_best_seller ? <Badge tone="gold">الأكثر مبيعًا</Badge> : null}
					</div>

					{product.rating_count > 0 ? (
						<a href="#reviews" className="mt-3 inline-flex">
							<Rating value={product.rating_avg} count={product.rating_count} size={16} />
						</a>
					) : null}

					{product.short_description ? (
						<p className="mt-5 text-base leading-relaxed text-ink-soft">{product.short_description}</p>
					) : null}

					<div className="mt-8">
						<ProductActions product={product} optionGroups={optionGroups} inWishlist={inWishlist} />
					</div>

					{product.description ? (
						<div className="mt-8 whitespace-pre-line border-t border-sand pt-6 text-sm leading-relaxed text-ink-soft">
							{product.description}
						</div>
					) : null}
				</div>
			</div>

			<div className="mt-16">
				<ProductReviews
					productId={product.id}
					reviews={reviews}
					ratingAvg={product.rating_avg}
					ratingCount={product.rating_count}
					canReview={canReview}
					isSignedIn={Boolean(user)}
				/>
			</div>

			{related.length ? (
				<section className="mt-16">
					<SectionHeading eyebrow="قد يعجبك" title="منتجات مشابهة" />
					<ProductGrid products={related} wishlistIds={wishlistIds} columns={4} />
				</section>
			) : null}
		</div>
	)
}
