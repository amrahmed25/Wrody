import type { Metadata } from "next"
import { Suspense } from "react"
import { ProductGrid } from "@/components/product/product-grid"
import { ShopFilters } from "@/components/shop/filters"
import { Pagination } from "@/components/shop/pagination"
import { ButtonLink } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/display"
import { getWishlistProductIds } from "@/lib/services/account"
import { getCategories, getProducts, type SortKey } from "@/lib/services/catalog"

export const metadata: Metadata = {
	title: "المتجر",
	description: "تصفح بوكيهات وورود ورودي الهاند ميد، فلتر حسب القسم والسعر، ورتّب بالطريقة اللي تناسبك.",
	alternates: { canonical: "/shop" },
}

const SORTS: SortKey[] = ["newest", "price_asc", "price_desc", "best_selling", "featured"]

type Search = Record<string, string | string[] | undefined>

function first(value: string | string[] | undefined): string | undefined {
	if (Array.isArray(value)) return value[0]
	return value || undefined
}

function toNumber(value: string | undefined): number | undefined {
	if (!value) return undefined
	const parsed = Number(value)
	return Number.isFinite(parsed) ? parsed : undefined
}

function buildHref(page: number, source: URLSearchParams): string {
	const params = new URLSearchParams(source)
	if (page <= 1) params.delete("page")
	else params.set("page", String(page))
	const query = params.toString()
	return query ? `/shop?${query}` : "/shop"
}

export default async function ShopPage({ searchParams }: { searchParams: Promise<Search> }) {
	const raw = await searchParams
	const params = new URLSearchParams()
	for (const [key, value] of Object.entries(raw)) {
		const text = first(value)
		if (text) params.set(key, text)
	}

	const sortParam = first(raw.sort)
	const sort: SortKey = SORTS.includes(sortParam as SortKey) ? (sortParam as SortKey) : "newest"
	const category = first(raw.category)
	const q = first(raw.q)

	const [categories, listing, wishlistIds] = await Promise.all([
		getCategories(),
		getProducts({
			q,
			category,
			minPrice: toNumber(first(raw.minPrice)),
			maxPrice: toNumber(first(raw.maxPrice)),
			sort,
			inStock: first(raw.inStock) === "1",
			featured: first(raw.featured) === "1",
			bestSeller: first(raw.bestSeller) === "1",
			page: toNumber(first(raw.page)) ?? 1,
		}),
		getWishlistProductIds(),
	])

	const activeCategory = categories.find((item) => item.slug === category)
	const heading = q ? `نتائج “${q}”` : activeCategory ? activeCategory.name : "المتجر"

	return (
		<div className="container-page py-8 sm:py-12">
			<header className="mb-8">
				<p className="text-xs font-semibold uppercase tracking-[0.18em] text-rose-500">المتجر</p>
				<h1 className="mt-2 font-display text-display-sm sm:text-display-md">{heading}</h1>
				<p className="nums mt-2 text-sm text-ink-soft">
					{listing.total ? `${listing.total} منتج` : "مفيش منتجات مطابقة للفلاتر دي"}
				</p>
			</header>

			<div className="grid gap-8 lg:grid-cols-[240px_minmax(0,1fr)] lg:items-start">
				<aside className="lg:sticky lg:top-[calc(var(--header-height)+1.5rem)]">
					<Suspense fallback={<Skeleton className="h-11 w-full rounded-full lg:h-[28rem]" />}>
						<ShopFilters categories={categories} />
					</Suspense>
				</aside>

				<div>
					<ProductGrid
						products={listing.products}
						wishlistIds={wishlistIds}
						priorityCount={4}
						emptyAction={
							<ButtonLink href="/shop" variant="outline">
								مسح الفلاتر
							</ButtonLink>
						}
					/>
					<Pagination
						page={listing.page}
						totalPages={listing.totalPages}
						buildHref={(page) => buildHref(page, params)}
					/>
				</div>
			</div>
		</div>
	)
}
