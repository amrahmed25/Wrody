import type { Metadata } from "next"
import { TrackForm } from "@/components/orders/track-form"

export const metadata: Metadata = {
	title: "تتبع طلبك",
	description: "اعرف حالة طلبك في ورودي برقم الطلب ورقم الموبايل.",
	alternates: { canonical: "/track" },
}

export default async function TrackPage({
	searchParams,
}: {
	searchParams: Promise<Record<string, string | string[] | undefined>>
}) {
	const params = await searchParams
	const orderParam = Array.isArray(params.order) ? params.order[0] : params.order

	return (
		<div className="container-page py-8 sm:py-12">
			<div className="mx-auto max-w-xl">
				<header className="mb-6 text-center">
					<p className="text-xs font-semibold uppercase tracking-[0.18em] text-rose-500">تتبع الطلب</p>
					<h1 className="mt-2 font-display text-display-sm">فين طلبك دلوقتي؟</h1>
					<p className="mt-2 text-sm text-ink-soft">
						اكتب رقم الطلب ورقم الموبايل اللي طلبت بيه، من غير تسجيل دخول.
					</p>
				</header>
				<TrackForm defaultOrderNumber={orderParam} />
			</div>
		</div>
	)
}
