import { Heart, Palette, Ruler, Sparkles } from "lucide-react"
import type { Metadata } from "next"
import { BouquetBuilder } from "@/components/bouquet/bouquet-builder"
import { EmptyState } from "@/components/ui/display"
import { getBouquetCatalog } from "@/lib/services/bouquet"

export const metadata: Metadata = {
	title: "اصنع بوكيهك",
	description:
		"صمم بوكيه هاند ميد بنفسك — اختار الورد والعدد والحجم والتغليف والكارت، والسعر بيتحدث فورًا.",
	alternates: { canonical: "/custom-bouquet" },
}

const STEPS_SUMMARY = [
	{ icon: Sparkles, label: "اختار أنواع الورد وعدد كل نوع" },
	{ icon: Ruler, label: "حدد حجم البوكيه" },
	{ icon: Palette, label: "اختار التغليف والكارت" },
	{ icon: Heart, label: "اكتب رسالتك وضيفه للسلة" },
]

export default async function CustomBouquetPage() {
	const catalog = await getBouquetCatalog()
	const ready = catalog.flowers.length > 0 && catalog.sizes.length > 0 && catalog.wrappings.length > 0

	return (
		<div className="container-page py-8 sm:py-12">
			<header className="mb-8 max-w-2xl">
				<p className="text-xs font-semibold uppercase tracking-[0.18em] text-rose-500">اصنع بوكيهك</p>
				<h1 className="mt-2 font-display text-display-sm sm:text-display-md">بوكيه من تصميمك بالكامل</h1>
				<p className="mt-3 text-sm leading-relaxed text-ink-soft">
					اختار الورد اللي تحبه، والعدد، والحجم، والتغليف، وهنلفه لك بإيدينا. السعر بيتحسب على
					السيرفر في كل خطوة، فاللي بتشوفه هو اللي هتدفعه بالزبط.
				</p>
				<ul className="mt-5 grid gap-2 sm:grid-cols-2">
					{STEPS_SUMMARY.map((step) => (
						<li key={step.label} className="flex items-center gap-2 text-sm text-ink-soft">
							<span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-rose-50 text-rose-500">
								<step.icon className="h-4 w-4" aria-hidden="true" />
							</span>
							{step.label}
						</li>
					))}
				</ul>
			</header>

			{ready ? (
				<BouquetBuilder catalog={catalog} />
			) : (
				<EmptyState
					title="مكونات البوكيه لسة مش متاحة"
					description="شكله مفيش أنواع ورد أو أحجام مفعّلة دلوقتي. شغل ملف seed.sql أو أضف المكونات من لوحة التحكم."
				/>
			)}
		</div>
	)
}
