import { ProductCardSkeleton, Skeleton } from "@/components/ui/display"

export default function StoreLoading() {
	return (
		<div className="container-page py-12">
			<Skeleton className="h-8 w-48" />
			<Skeleton className="mt-3 h-4 w-72" />
			<div className="mt-10 grid grid-cols-2 gap-4 lg:grid-cols-4">
				{Array.from({ length: 8 }).map((_, index) => (
					<ProductCardSkeleton key={index} />
				))}
			</div>
		</div>
	)
}
