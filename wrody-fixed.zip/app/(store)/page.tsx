import type { Metadata } from "next"
import {
	CategoryCard,
	CustomBouquetBanner,
	FinalCta,
	GalleryStrip,
	Hero,
	Testimonials,
	WhyWrody,
} from "@/components/home/sections"
import { ProductGrid } from "@/components/product/product-grid"
import { JsonLd } from "@/components/shared/json-ld"
import { ButtonLink } from "@/components/ui/button"
import { SectionHeading } from "@/components/ui/display"
import { siteConfig } from "@/lib/config/site"
import { getWishlistProductIds } from "@/lib/services/account"
import { getBestSellers, getCategories, getFeaturedProducts, getTestimonials } from "@/lib/services/catalog"
import { getSetting } from "@/lib/services/settings"

export const metadata: Metadata = {
	title: { absolute: `${siteConfig.name} | ${siteConfig.tagline}` },
	description: siteConfig.description,
	alternates: { canonical: "/" },
}

const FALLBACK_GALLERY = [
	{ image: "/gallery/g1.svg", caption: "بوكيه توليب وردي" },
	{ image: "/gallery/g2.svg", caption: "علبة هدية فاخرة" },
	{ image: "/gallery/g3.svg", caption: "بوكيه لافندر" },
	{ image: "/gallery/g4.svg", caption: "وردة مفردة" },
	{ image: "/gallery/g5.svg", caption: "بوكيه باستيل" },
	{ image: "/gallery/g6.svg", caption: "بوكيه تخرج" },
]

export default async function HomePage() {
	const [hero, cta, gallery, categories, featured, bestSellers, testimonials, wishlistIds] =
		await Promise.all([
			getSetting("homepage.hero"),
			getSetting("homepage.cta"),
			getSetting("homepage.gallery"),
			getCategories(),
			getFeaturedProducts(4),
			getBestSellers(8),
			getTestimonials(3),
			getWishlistProductIds(),
		])

	const galleryItems = gallery.items.length ? gallery.items : FALLBACK_GALLERY

	return (
		<div className="flex flex-col gap-16 pb-16 sm:gap-20 sm:pb-24">
			<JsonLd
				data={{
					"@context": "https://schema.org",
					"@type": "Florist",
					name: siteConfig.name,
					alternateName: siteConfig.nameEn,
					url: siteConfig.url,
					description: siteConfig.description,
					inLanguage: "ar",
					currenciesAccepted: siteConfig.currency,
					image: `${siteConfig.url}/og.png`,
				}}
			/>

			<Hero
				headline={hero.headline}
				subheadline={hero.subheadline}
				badge={hero.badge}
				cta={hero.cta}
				secondaryCta={hero.secondary_cta}
			/>

			{categories.length ? (
				<section className="container-page">
					<SectionHeading
						eyebrow="الأقسام"
						title="اختار مناسبتك"
						description="بوكيهات جاهزة، ورد مفرد، علب هدايا، وتفصيل على مزاجك."
					/>
					<div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
						{categories.map((category, index) => (
							<CategoryCard key={category.id} category={category} index={index} />
						))}
					</div>
				</section>
			) : null}

			<section className="container-page">
				<SectionHeading
					eyebrow="مختارات ورودي"
					title="بوكيهات مميزة"
					description="قطع اخترناها لأنها بتحكي، وبتفضل حلوة بعد ما الهدية تتقدم."
					action={
						<ButtonLink href="/shop?featured=1" variant="outline" size="sm">
							شوف الكل
						</ButtonLink>
					}
				/>
				<ProductGrid
					products={featured}
					wishlistIds={wishlistIds}
					priorityCount={4}
					emptyTitle="لسة بنجهّز المختارات"
					emptyDescription="أول ما المنتجات تظهر، هتلاقيها هنا. تقدر تتفرج على المتجر كامل دلوقتي."
					emptyAction={<ButtonLink href="/shop">المتجر</ButtonLink>}
				/>
			</section>

			<section className="container-page">
				<SectionHeading
					eyebrow="ليش ورودي"
					title="ورد معمول بإيدينا، عشان يفضل معاك"
					center
				/>
				<WhyWrody />
			</section>

			<section className="container-page">
				<SectionHeading
					eyebrow="الأكثر مبيعًا"
					title="اللي الناس بتحبه"
					action={
						<ButtonLink href="/shop?bestSeller=1" variant="outline" size="sm">
							الأكثر مبيعًا
						</ButtonLink>
					}
				/>
				<ProductGrid
					products={bestSellers}
					wishlistIds={wishlistIds}
					emptyTitle="لسة مفيش الأكثر مبيعًا"
					emptyDescription="بعد أول الطلبات، القسم ده هيتحدد لوحده من المبيعات الحقيقية."
					emptyAction={<ButtonLink href="/shop">تصفح المتجر</ButtonLink>}
				/>
			</section>

			<CustomBouquetBanner />

			{testimonials.length ? (
				<section className="container-page">
					<SectionHeading eyebrow="آراء العملاء" title="ناس استلمت، وكتبت" center />
					<Testimonials reviews={testimonials} />
				</section>
			) : null}

			<section className="container-page">
				<SectionHeading eyebrow="من الشغل" title="لمحات من الورشة" center />
				<GalleryStrip items={galleryItems} />
			</section>

			<FinalCta headline={cta.headline} body={cta.body} />
		</div>
	)
}
