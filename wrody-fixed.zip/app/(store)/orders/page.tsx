import { PackageSearch } from "lucide-react"
import type { Metadata } from "next"
import Link from "next/link"
import { OrderStatusBadge } from "@/components/orders/order-status"
import { ButtonLink } from "@/components/ui/button"
import { EmptyState } from "@/components/ui/display"
import { requireUser } from "@/lib/auth/session"
import { getMyOrders } from "@/lib/services/orders"
import { formatDateTime, formatPrice, PAYMENT_STATUS_LABELS } from "@/lib/utils/format"

export const metadata: Metadata = {
	title: "طلباتي",
	robots: { index: false, follow: false },
}

export default async function OrdersPage() {
	await requireUser()
	const orders = await getMyOrders()

	return (
		<div className="container-page py-8 sm:py-12">
			<header className="mb-6">
				<h1 className="font-display text-display-sm">طلباتي</h1>
				<p className="mt-2 text-sm text-ink-soft">كل طلباتك مرتبة من الأحدث للأقدم.</p>
			</header>

			{orders.length ? (
				<ul className="space-y-3">
					{orders.map((order) => (
						<li key={order.id}>
							<Link
								href={`/order/${order.order_number}`}
								className="surface flex flex-col gap-3 p-5 transition-all duration-200 ease-soft hover:-translate-y-0.5 hover:shadow-lift sm:flex-row sm:items-center sm:justify-between"
							>
								<div>
									<p className="nums font-display text-lg font-bold" dir="ltr">
										{order.order_number}
									</p>
									<p className="mt-1 text-xs text-ink-muted">{formatDateTime(order.created_at)}</p>
								</div>
								<div className="flex flex-wrap items-center gap-3">
									<span className="text-xs text-ink-soft">
										{PAYMENT_STATUS_LABELS[order.payment_status]}
									</span>
									<OrderStatusBadge status={order.status} />
									<span className="nums font-semibold">{formatPrice(order.total)}</span>
								</div>
							</Link>
						</li>
					))}
				</ul>
			) : (
				<EmptyState
					icon={<PackageSearch className="h-6 w-6" />}
					title="مفيش طلبات لسة"
					description="أول ما تطلب بوكيه، هتلاقيه هنا مع حالة التجهيز والتوصيل."
					action={<ButtonLink href="/shop">ابدأ التسوق</ButtonLink>}
				/>
			)}
		</div>
	)
}
