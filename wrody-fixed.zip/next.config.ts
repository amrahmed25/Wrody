import type { NextConfig } from "next"

function supabaseHostname(): string {
	try {
		if (process.env.NEXT_PUBLIC_SUPABASE_URL) {
			return new URL(process.env.NEXT_PUBLIC_SUPABASE_URL).hostname
		}
	} catch {
		/* fall through */
	}
	return "**.supabase.co"
}

const nextConfig: NextConfig = {
	reactStrictMode: true,
	poweredByHeader: false,
	images: {
		formats: ["image/avif", "image/webp"],
		deviceSizes: [360, 390, 640, 768, 1024, 1280, 1536],
		imageSizes: [64, 96, 128, 256, 384],
		remotePatterns: [
			{ protocol: "https", hostname: supabaseHostname(), pathname: "/storage/v1/object/public/**" },
		],
		dangerouslyAllowSVG: true,
		contentDispositionType: "attachment",
		contentSecurityPolicy: "default-src 'self'; script-src 'none'; sandbox;",
	},
	experimental: { optimizePackageImports: ["lucide-react"] },
	async headers() {
		return [
			{
				source: "/:path*",
				headers: [
					{ key: "X-Content-Type-Options", value: "nosniff" },
					{ key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
					{ key: "X-Frame-Options", value: "SAMEORIGIN" },
					{ key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
				],
			},
		]
	},
}

export default nextConfig
