# ورودي · Wrody

متجر إلكتروني كامل لبراند **ورودي (Wrody)** — بوكيهات ورد هاند ميد مصنوعة من الـ Pipe Cleaners.
المشروع production-ready: واجهة عربية RTL، لوحة تحكم كاملة، قاعدة بيانات PostgreSQL على Supabase مع RLS،
ومنطق تجارة إلكترونية حقيقي (مخزون، كوبونات، طلبات، تتبع، تقييمات، بوكيه مخصص).

---

## 1. Project overview

| | |
| --- | --- |
| Brand | ورودي / Wrody — handmade pipe-cleaner flowers |
| Primary language | Arabic (RTL first) |
| Currency | EGP (ج.م) |
| Storefront | `/` `/shop` `/product/[slug]` `/custom-bouquet` `/cart` `/checkout` `/order/[orderNumber]` `/track` `/orders` `/wishlist` `/account` `/about` |
| Admin | `/admin` (dashboard, products, categories, orders, customers, coupons, reviews, custom bouquets, settings) |
| Auth | Supabase Auth (email + password) with `profiles.role` = `customer` \| `admin` |
| Payments | Cash on Delivery live; online gateway behind a provider interface (not faked) |

---

## 2. Features

**Customers**
- تصفح وبحث وفلترة (قسم، سعر، متاح، مميز، الأكثر مبيعًا) وترتيب (أحدث، السعر، الأكثر مبيعًا، المميز) — كل الفلاتر في الـ URL.
- صفحة منتج: جاليري صور، سعر قبل الخصم، شارة خصم، تنويعات، اختيار كمية، إضافة للعربة، اشترِ الآن، مفضلة، تقييمات، منتجات مشابهة، Structured Data.
- عربة للزائر وللمستخدم المسجل + دمج عربة الزائر عند تسجيل الدخول، كوبون، مصاريف توصيل حسب المدينة.
- تشيك أوت ٣ خطوات + منع الطلبات المكرّرة (idempotency key) + طلب بالدفع عند الاستلام.
- تتبع الطلب برقم الطلب + الموبايل (بدون تسجيل دخول) وTimeline: pending → confirmed → preparing → out_for_delivery → delivered.
- تقييم المنتجات المشتراة فقط (تحقق على مستوى الداتابيز عن طريق `can_review()`).
- بوكيه مخصص: نوع الورد، الكمية، الحجم، التغليف، الكارت، الرسالة، سعر لحظي — **السعر النهائي يُحسب على السيرفر**.
- حساب المستخدم: بياناته، عناوينه، طلباته، تقييماته، بوكيهاته.

**Admins**
- Dashboard: إيرادات، طلبات، عملاء، منتجات، طلبات منتظرة/متسلمة، تقييمات للمراجعة، بوكيهات جديدة، مخزون منخفض.
- Charts (SVG/CSS بدون أي مكتبة رسم): الإيرادات على الوقت، الطلبات على الوقت، الأكثر مبيعًا، أداء الأقسام.
- منتجات: إنشاء/تعديل/إخفاء/حذف، رفع صور متعددة لـ Supabase Storage، ترتيب الصور، تنويعات، مخزون، أسعار، مميز/الأكثر مبيعًا.
- طلبات: بحث وفلترة، تفاصيل، تغيير الحالة (بـ validation في Postgres)، تغيير حالة الدفع، بيانات العميل والعنوان.
- أقسام، كوبونات، تقييمات (موافقة/إخفاء/حذف)، بوكيهات مخصصة، إعدادات الهوم بيدج ومصاريف التوصيل ومناطق التوصيل.

---

## 3. Tech stack

- **Next.js 15** (App Router, React Server Components, Server Actions) + **React 19** + **TypeScript**
- **Tailwind CSS 3** + design tokens مخصصة للبراند (cream / rose / sage / gold / ink)
- **Supabase**: PostgreSQL + Auth + Storage + RLS (`@supabase/ssr`, `@supabase/supabase-js`)
- **Zod** للتحقق من كل input على السيرفر
- **Lucide React** للأيقونات
- بدون أي مكتبة animation أو charts — كل الأنيميشن CSS والرسوم SVG

---

## 4. Folder structure

```
app/
  (store)/            صفحات المتجر + layout بالهيدر والفوتر
  (auth)/             login · register · reset-password
  admin/              لوحة التحكم (محمية بـ requireAdmin)
  actions/            Server Actions (auth, cart, checkout, reviews, bouquet, account)
  actions/admin/      Server Actions للأدمن (catalog, operations)
  auth/callback/      تبادل كود Supabase بجلسة
  robots.ts · sitemap.ts · error.tsx · not-found.tsx · icon.svg
components/
  ui/                 primitives (button, field, display, modal, toast, reveal, quantity-selector)
  layout/             header, footer, mobile-menu, splash (شاشة التحميل)
  home/ product/ shop/ cart/ checkout/ bouquet/ orders/ account/ admin/ auth/
lib/
  config/             env + site metadata
  supabase/           client · server · admin (service role) · middleware
  auth/session        getUser · getProfile · requireUser · requireAdmin · currentAdmin
  validations/        Zod schemas (common, auth, cart, checkout, bouquet, review, admin)
  services/           كل قراءات الداتابيز (catalog, cart, orders, account, bouquet, settings, admin)
  payments/           provider interface + COD
  notifications/      email + WhatsApp abstractions
  utils/              cn · format · slug · errors
supabase/
  migrations/0001_schema.sql · 0002_functions.sql · 0003_rls.sql · 0004_storage.sql
  seed.sql
scripts/
  generate-placeholder-art.mjs · promote-admin.ts
types/index.ts
middleware.ts
```

---

## 5. Environment variables

انسخ `.env.example` إلى `.env.local` واملأ القيم:

| Variable | مطلوب | الوصف |
| --- | --- | --- |
| `NEXT_PUBLIC_SITE_URL` | ✅ | `http://localhost:3000` محليًا، ودومين الإنتاج على Vercel |
| `NEXT_PUBLIC_SUPABASE_URL` | ✅ | Supabase → Settings → API |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | ✅ | المفتاح العام (آمن في البراوزر) |
| `SUPABASE_SERVICE_ROLE_KEY` | ✅ | **سيرفر فقط** — يستخدم لعربة الزائر، تسعير البوكيه، إنشاء الطلب، تتبع الطلب |
| `SUPABASE_PROJECT_REF` | ➖ | لأوامر `supabase db push` |
| `NEXT_PUBLIC_SUPABASE_PRODUCT_BUCKET` | ✅ | `product-images` |
| `NEXT_PUBLIC_SUPABASE_CATEGORY_BUCKET` | ✅ | `category-images` |
| `NEXT_PUBLIC_SUPABASE_AVATAR_BUCKET` | ✅ | `avatars` |
| `NEXT_PUBLIC_WHATSAPP_NUMBER` | ➖ | رقم واتساب للزر "تأكيد الطلب عبر WhatsApp" (بدون + أو مسافات) |
| `WHATSAPP_API_TOKEN` · `WHATSAPP_PHONE_NUMBER_ID` | ➖ | لإرسال إشعارات واتساب فعليًا (Cloud API) |
| `EMAIL_PROVIDER` | ➖ | `console` (افتراضي) أو `resend` |
| `RESEND_API_KEY` · `EMAIL_FROM` | ➖ | لتشغيل الإيميلات فعليًا |
| `NEXT_PUBLIC_ENABLE_ONLINE_PAYMENT` | ➖ | `false` افتراضيًا |
| `PAYMENT_GATEWAY` | ➖ | `none` أو `paymob` |
| `PAYMOB_API_KEY` · `PAYMOB_INTEGRATION_ID` · `PAYMOB_HMAC_SECRET` | ➖ | مطلوبة فقط عند تفعيل الدفع الأونلاين |

> ⚠️ `SUPABASE_SERVICE_ROLE_KEY` لا يُستخدم أبدًا في أي ملف `"use client"`، ولا يظهر في أي bundle للبراوزر.

---

## 6. Supabase setup

1. أنشئ مشروع جديد على [supabase.com](https://supabase.com) واختر أقرب Region.
2. من **Settings → API** انسخ الـ URL و anon key و service role key إلى `.env.local`.
3. **طبّق الـ migrations** بالترتيب — إما من SQL Editor (انسخ محتوى كل ملف) أو بالـ CLI:
   ```bash
   npx supabase link --project-ref "$SUPABASE_PROJECT_REF"
   npx supabase db push          # يطبق supabase/migrations بالترتيب
   ```
   | الملف | المحتوى |
   | --- | --- |
   | `0001_schema.sql` | الجداول، الـ enums، المفاتيح الأجنبية، القيود، الفهارس |
   | `0002_functions.sql` | كل منطق الأعمال (place_order, evaluate_coupon, price_custom_bouquet, track_order, admin_dashboard_stats …) |
   | `0003_rls.sql` | تشغيل RLS + كل الـ policies |
   | `0004_storage.sql` | buckets الصور + policies الرفع (أدمن فقط) والقراءة (عامة) |
4. **Storage**: ملف `0004_storage.sql` بينشئ `product-images` و `category-images` و `avatars`. لو أنشأتها يدويًا خليها Public read.
5. **Auth**: Authentication → URL Configuration → Site URL = دومينك، و Redirect URLs أضف `<domain>/auth/callback`.
   لتشغيل استعادة كلمة السر فعليًا، اضبط SMTP من Authentication → Emails.

### RLS باختصار
- `products` / `categories` / `product_images` / `product_variants`: قراءة عامة للصفوف المفعّلة فقط، والكتابة لـ `is_admin()` فقط.
- `profiles` / `addresses` / `wishlist` / `reviews`: كل مستخدم يقرأ ويكتب صفوفه فقط (`auth.uid() = user_id`).
- `orders` / `order_items` / `order_events`: العميل يقرأ طلباته فقط، وتغيير الحالة عبر دوال `security definer` مخصصة.
- `reviews`: `is_approved` يتحكم فيها الأدمن فقط (trigger `force_review_moderation`).
- `profiles.role`: محمي بـ trigger `protect_profile_role()` — لا يمكن ترقية النفس لأدمن.

---

## 7. Local development

```bash
npm install
cp .env.example .env.local     # واملأ القيم
npm run art                    # يولّد رسومات SVG مؤقتة في public/ (اختياري — موجودة بالفعل)
npm run dev                    # http://localhost:3000
```

أوامر مفيدة:

```bash
npm run typecheck   # tsc --noEmit
npm run lint        # eslint
npm run build       # next build
npm run db:push     # supabase db push
npm run db:reset    # supabase db reset (يعيد الـ schema + seed محليًا)
```

### Seeding

بعد الـ migrations، شغّل `supabase/seed.sql` من SQL Editor (أو `npm run db:reset` محليًا). البيانات تشمل:
- ٦ أقسام، ١٥ منتج بأسماء عربية، صور متعددة لكل منتج، تنويعات (مقاس/لون/تغليف)
- خيارات البوكيه المخصص (٧ أنواع ورد، ٣ مقاسات، ٤ أنواع تغليف، ٣ كروت)
- ٣ كوبونات (`WELCOME10`, `WRODY50`, `GIFT15`)، مناطق توصيل، إعدادات الهوم بيدج
- تقييمات وطلبات نموذجية

> الصور في `public/` رسومات SVG خفيفة مولّدة بـ `scripts/generate-placeholder-art.mjs` — استبدلها بصور المنتجات الحقيقية (نفس المسارات أو ارفعها على Storage من لوحة التحكم).

---

## 8. Creating the first admin

1. سجّل حساب عادي من `/register`.
2. شغّل:
   ```bash
   npm run admin:promote -- you@example.com
   ```
   (يستخدم service-role key من `.env.local`)
   أو من SQL Editor:
   ```sql
   update public.profiles set role = 'admin' where email = 'you@example.com';
   ```
3. اعمل logout/login وافتح `/admin`.

---

## 9. Deploying to Vercel

1. ارفع المشروع على GitHub ثم **New Project** على Vercel (Framework: Next.js — بدون أي إعدادات إضافية).
2. أضف كل متغيرات البيئة في **Settings → Environment Variables** (خلي `NEXT_PUBLIC_SITE_URL` = دومين الإنتاج).
3. في Supabase → Authentication → URL Configuration: Site URL = دومين Vercel، و Redirect URLs = `https://your-domain/auth/callback`.
4. Deploy. بعد أول deploy راجع `/sitemap.xml` و `/robots.txt`.
5. لو استخدمت صور على دومين خارجي، أضفه في `next.config.ts` → `images.remotePatterns`.

---

## 10. Future payment gateway

الدفع مبني على interface في `lib/payments/index.ts`:

```ts
PaymentProviderMeta { id: PaymentMethod; label: string; description: string; enabled: boolean; note?: string }
listEnabledPaymentMethods()
```

للإضافة الحقيقية:
1. اضبط `PAYMENT_GATEWAY=paymob` و `NEXT_PUBLIC_ENABLE_ONLINE_PAYMENT=true` مع مفاتيح البوابة.
2. أضف provider جديد في `lib/payments/` يرجّع رابط الدفع (intention/checkout URL).
3. أنشئ `app/api/payments/paymob/webhook/route.ts` يتحقق من HMAC ثم يستدعي `set_payment_status()`.
4. الـ TODO مكتوب في الملف نفسه. **لا يوجد أي دفع وهمي**: بدون مفاتيح، `cod` هي الطريقة المتاحة الوحيدة.

نفس الأسلوب مع الإشعارات:
- `lib/notifications/email.ts` — بدون provider يسجّل `[email:not-sent]` ولا يدّعي الإرسال.
- `lib/notifications/whatsapp.ts` — `buildWhatsAppOrderLink()` بيشتغل بمجرد وضع `NEXT_PUBLIC_WHATSAPP_NUMBER`؛ الإرسال التلقائي محتاج `WHATSAPP_API_TOKEN`.

---

## 11. Security model (باختصار)

- **لا يوجد أي سعر أو إجمالي قادم من العميل.** `place_order()` في Postgres يعيد بناء كل سطر من الداتابيز، يطبّق الكوبون، ويحسب التوصيل.
- كل Server Action يبدأ بـ Zod validation + تحقق صلاحية (`requireUser` / `currentAdmin`).
- `/admin` محمي في `middleware.ts` وفي `app/admin/layout.tsx` وفي كل action وفي RLS.
- المخزون يُقفل بـ `for update` وقت إنشاء الطلب، ولا ينزل تحت صفر، ويُرجَّع عند الإلغاء.
- `idempotencyKey` يمنع تكرار الطلب من الضغط المزدوج.
- رقم الطلب `WRD-2026-000124` منفصل عن الـ UUID.
- رفع الصور: نوع الملف والحجم يتحققون على السيرفر، والرفع مسموح للأدمن فقط بسياسات Storage.

---

## 12. Testing checklist

**Customer:** register · login · logout · browse · search · filter · sort · product details · variants · add to cart · update qty · remove · wishlist · coupon · checkout (COD) · order page · WhatsApp button · track order · review purchased product · custom bouquet · account + addresses

**Admin:** login · dashboard + charts · add/edit/hide/delete product · upload & reorder images · variants & stock · categories · orders search/filter · change order status · change payment status · coupons · reviews moderation · custom bouquets · settings & delivery zones

**Security:** عميل يفتح `/admin` → `/unauthorized` · عميل يفتح طلب غيره → 404 · تعديل السعر من الـ DevTools → السيرفر يتجاهله · كمية أكبر من المخزون → رفض · ترقية الدور من الـ API → مرفوضة بالـ trigger

**Responsive:** 360 · 390 · 768 · 1024 · 1440px

---

## 13. Notes

- شاشة التحميل (`components/layout/splash.tsx`) تظهر مرة واحدة لكل session، مدتها ≤ 1.2s، CSS/SVG فقط، وتختفي فورًا لو الصفحة جاهزة، وتحترم `prefers-reduced-motion`.
- كل الصفحات Server Components إلا اللي محتاجة تفاعل فعلي (عربة، فلاتر، فورمات، لوحة التحكم).
- الأرقام تُعرض بأرقام لاتينية داخل نص عربي عبر `Intl.NumberFormat('ar-EG-u-nu-latn')`، والتواريخ بتوقيت `Africa/Cairo`.
