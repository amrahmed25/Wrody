"use client"

import Image from "next/image"
import { useState } from "react"
import { cn } from "@/lib/utils/cn"
import type { ProductImage } from "@/types"

/**
 * Client component only because of thumbnail selection. The first image is
 * rendered eagerly (LCP candidate); the rest lazy-load.
 */
export function ProductGallery({
	images,
	productName,
	fallbackSlug,
}: {
	images: ProductImage[]
	productName: string
	fallbackSlug: string
}) {
	const gallery = images.length
		? images
		: [{ id: "fallback", image_url: `/products/${fallbackSlug}-1.svg`, alt_text: productName, sort_order: 0 }]
	const [activeIndex, setActiveIndex] = useState(0)
	const active = gallery[Math.min(activeIndex, gallery.length - 1)]

	return (
		<div className="flex flex-col gap-3">
			<div className="group relative aspect-square overflow-hidden rounded-[2rem] border border-sand bg-ivory">
				<Image
					key={active.id}
					src={active.image_url}
					alt={active.alt_text ?? productName}
					fill
					priority
					sizes="(max-width: 1024px) 100vw, 560px"
					className="animate-fade-in object-cover transition-transform duration-700 ease-soft group-hover:scale-[1.04]"
				/>
			</div>

			{gallery.length > 1 ? (
				<ul className="hide-scrollbar flex gap-2.5 overflow-x-auto pb-1" role="list">
					{gallery.map((image, index) => (
						<li key={image.id}>
							<button
								type="button"
								onClick={() => setActiveIndex(index)}
								aria-label={`صورة ${index + 1} من ${gallery.length}`}
								aria-current={index === activeIndex}
								className={cn(
									"relative h-20 w-20 shrink-0 overflow-hidden rounded-2xl border transition-colors",
									index === activeIndex
										? "border-rose-400 ring-2 ring-rose-200"
										: "border-sand hover:border-rose-300",
								)}
							>
								<Image
									src={image.image_url}
									alt=""
									fill
									loading="lazy"
									sizes="80px"
									className="object-cover"
								/>
							</button>
						</li>
					))}
				</ul>
			) : null}
		</div>
	)
}
