"use client"

import { Loader2, ShoppingBag, Zap } from "lucide-react"
import { useMemo, useState, useTransition } from "react"
import { addToCartAction, buyNowAction } from "@/app/actions/cart"
import { WishlistButton } from "@/components/product/wishlist-button"
import { Button } from "@/components/ui/button"
import { Price } from "@/components/ui/display"
import { QuantitySelector } from "@/components/ui/quantity-selector"
import { useToast } from "@/components/ui/toast"
import { cn } from "@/lib/utils/cn"
import type { ProductVariant, ProductWithRelations, VariantOptionGroup } from "@/types"

function matchVariant(
	variants: ProductVariant[],
	selected: Record<string, string>,
): ProductVariant | null {
	if (!variants.length) return null
	return (
		variants.find((variant) =>
			Object.entries(variant.options ?? {}).every(([key, value]) => selected[key] === value),
		) ?? null
	)
}

export function ProductActions({
	product,
	optionGroups,
	inWishlist,
}: {
	product: ProductWithRelations
	optionGroups: VariantOptionGroup[]
	inWishlist: boolean
}) {
	const toast = useToast()
	const [pending, startTransition] = useTransition()
	const [buying, setBuying] = useState(false)
	const [quantity, setQuantity] = useState(1)
	const [selected, setSelected] = useState<Record<string, string>>(() => {
		const initial: Record<string, string> = {}
		for (const group of optionGroups) {
			if (group.values[0]) initial[group.name] = group.values[0]
		}
		return initial
	})

	const variant = useMemo(() => matchVariant(product.variants, selected), [product.variants, selected])
	const needsVariant = product.variants.length > 0
	const unitPrice = Number(variant?.price ?? product.price)
	const compareAt = variant ? null : product.compare_at_price
	const stock = needsVariant ? (variant?.stock ?? 0) : product.stock
	const soldOut = stock <= 0
	const maxQuantity = Math.max(1, Math.min(stock, 99))

	const run = (buyNow: boolean) => {
		if (needsVariant && !variant) {
			toast("اختار المواصفات أولًا.", "error")
			return
		}
		startTransition(async () => {
			const payload = {
				productId: product.id,
				variantId: variant?.id ?? null,
				quantity,
			}
			if (buyNow) {
				setBuying(true)
				const result = await buyNowAction(payload)
				setBuying(false)
				if (result && !result.ok) toast(result.error, "error")
				return
			}
			const result = await addToCartAction(payload)
			if (!result.ok) toast(result.error, "error")
			else toast(result.message ?? "تمت الإضافة للسلة 🤍")
		})
	}

	return (
		<div className="space-y-5">
			{optionGroups.map((group) => (
				<fieldset key={group.name}>
					<legend className="field-label mb-2">{group.name}</legend>
					<div className="flex flex-wrap gap-2">
						{group.values.map((value) => {
							const active = selected[group.name] === value
							return (
								<button
									key={value}
									type="button"
									onClick={() => setSelected((current) => ({ ...current, [group.name]: value }))}
									aria-pressed={active}
									className={cn("chip", active && "chip-active")}
								>
									{value}
								</button>
							)
						})}
					</div>
				</fieldset>
			))}

			{needsVariant && !variant ? (
				<p className="text-sm text-rose-700">المواصفات دي مش متاحة مع بعض. جرّب اختيار تاني.</p>
			) : null}

			<div className="flex flex-wrap items-end justify-between gap-4">
				<div>
					<p className="field-label">السعر</p>
					<Price value={unitPrice} compareAt={compareAt} size="lg" />
				</div>
				{!soldOut ? (
					<QuantitySelector value={quantity} onChange={setQuantity} min={1} max={maxQuantity} />
				) : null}
			</div>

			{!soldOut && stock <= 5 ? (
				<p className="nums text-sm font-medium text-rose-600">فاضل {stock} بس</p>
			) : null}

			<div className="flex flex-wrap items-center gap-3">
				<Button
					size="lg"
					className="flex-1"
					onClick={() => run(false)}
					disabled={pending || soldOut || (needsVariant && !variant)}
				>
					{pending && !buying ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShoppingBag className="h-4 w-4" />}
					أضف للسلة
				</Button>
				<Button
					size="lg"
					variant="secondary"
					className="flex-1"
					onClick={() => run(true)}
					disabled={pending || soldOut || (needsVariant && !variant)}
				>
					{buying ? <Loader2 className="h-4 w-4 animate-spin" /> : <Zap className="h-4 w-4" />}
					اشترِ الآن
				</Button>
				<WishlistButton productId={product.id} initialActive={inWishlist} className="h-12 w-12" />
			</div>
		</div>
	)
}
