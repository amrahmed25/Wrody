import Image from "next/image"
import Link from "next/link"
import { WishlistButton } from "@/components/product/wishlist-button"
import { Badge, Price, Rating } from "@/components/ui/display"
import { cn } from "@/lib/utils/cn"
import type { ProductCardData } from "@/types"

/**
 * Server component — the only interactive part is the wishlist toggle.
 * `priority` should be true only for above-the-fold cards.
 */
export function ProductCard({
	product,
	priority = false,
	inWishlist = false,
	className,
}: {
	product: ProductCardData
	priority?: boolean
	inWishlist?: boolean
	className?: string
}) {
	const image = product.images?.[0]
	const soldOut = product.stock <= 0

	return (
		<article
			className={cn(
				"group relative flex flex-col overflow-hidden rounded-3xl border border-sand bg-ivory transition-all duration-300 ease-soft hover:-translate-y-1 hover:shadow-lift",
				className,
			)}
		>
			<div className="absolute end-3 top-3 z-10">
				<WishlistButton productId={product.id} initialActive={inWishlist} />
			</div>

			<Link href={`/product/${product.slug}`} className="block" tabIndex={-1} aria-hidden="true">
				<div className="relative aspect-[4/5] overflow-hidden bg-rose-50">
					<Image
						src={image?.image_url ?? `/products/${product.slug}-1.svg`}
						alt={image?.alt_text ?? product.name}
						fill
						priority={priority}
						loading={priority ? undefined : "lazy"}
						sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 280px"
						className={cn(
							"object-cover transition-transform duration-500 ease-soft group-hover:scale-[1.05]",
							soldOut && "opacity-70 saturate-50",
						)}
					/>
					<div className="absolute start-3 top-3 flex flex-col items-start gap-1.5">
						{soldOut ? <Badge tone="muted">خلص من المخزن</Badge> : null}
						{!soldOut && product.is_best_seller ? <Badge tone="gold">الأكثر مبيعًا</Badge> : null}
						{!soldOut && product.is_featured && !product.is_best_seller ? (
							<Badge tone="sage">مختار ليك</Badge>
						) : null}
					</div>
				</div>
			</Link>

			<div className="flex flex-1 flex-col p-4">
				{product.category ? (
					<p className="text-[11px] font-medium uppercase tracking-wider text-ink-muted">
						{product.category.name}
					</p>
				) : null}

				<h3 className="mt-1.5 text-[0.98rem] font-semibold leading-snug">
					<Link
						href={`/product/${product.slug}`}
						className="transition-colors hover:text-rose-700 focus-visible:text-rose-700"
					>
						{product.name}
					</Link>
				</h3>

				{product.short_description ? (
					<p className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-ink-muted">
						{product.short_description}
					</p>
				) : null}

				{product.rating_count > 0 ? (
					<Rating value={product.rating_avg} count={product.rating_count} className="mt-2.5" />
				) : null}

				<div className="mt-3 flex items-end justify-between gap-2 pt-1">
					<Price value={product.price} compareAt={product.compare_at_price} />
					{!soldOut && product.stock <= 5 ? (
						<span className="nums text-[11px] font-medium text-rose-600">
							فاضل {product.stock}
						</span>
					) : null}
				</div>
			</div>
		</article>
	)
}
