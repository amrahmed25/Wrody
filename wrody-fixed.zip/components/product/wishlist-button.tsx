"use client"

import { Heart, Loader2 } from "lucide-react"
import { useRouter } from "next/navigation"
import { useState, useTransition } from "react"
import { toggleWishlistAction } from "@/app/actions/cart"
import { useToast } from "@/components/ui/toast"
import { cn } from "@/lib/utils/cn"

export function WishlistButton({
	productId,
	initialActive = false,
	className,
}: {
	productId: string
	initialActive?: boolean
	className?: string
}) {
	const [active, setActive] = useState(initialActive)
	const [pending, startTransition] = useTransition()
	const toast = useToast()
	const router = useRouter()

	const onToggle = () => {
		startTransition(async () => {
			const result = await toggleWishlistAction({ productId })
			if (!result.ok) {
				if (result.error.includes("سجل دخول")) {
					router.push("/login?next=/wishlist")
				}
				toast(result.error, "error")
				return
			}
			setActive(result.data?.inWishlist ?? !active)
			if (result.message) toast(result.message)
		})
	}

	return (
		<button
			type="button"
			onClick={onToggle}
			disabled={pending}
			aria-pressed={active}
			aria-label={active ? "حذف من المفضلة" : "أضف للمفضلة"}
			className={cn(
				"flex h-10 w-10 items-center justify-center rounded-full border border-sand bg-ivory/95 text-ink shadow-soft backdrop-blur transition-colors hover:border-rose-300 hover:text-rose-700 disabled:opacity-60",
				active && "border-rose-200 bg-rose-50 text-rose-600",
				className,
			)}
		>
			{pending ? (
				<Loader2 className="h-4 w-4 animate-spin" />
			) : (
				<Heart className={cn("h-4 w-4", active && "fill-current")} />
			)}
		</button>
	)
}
