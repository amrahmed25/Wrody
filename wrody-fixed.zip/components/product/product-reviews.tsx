import { MessageSquareHeart } from "lucide-react"
import { ReviewForm } from "@/components/product/review-form"
import { ButtonLink } from "@/components/ui/button"
import { EmptyState, Rating } from "@/components/ui/display"
import { formatDate } from "@/lib/utils/format"
import type { Review } from "@/types"

/** Server component. Only approved reviews are ever queried for this list. */
export function ProductReviews({
	productId,
	reviews,
	ratingAvg,
	ratingCount,
	canReview,
	isSignedIn,
}: {
	productId: string
	reviews: Review[]
	ratingAvg: number
	ratingCount: number
	canReview: boolean
	isSignedIn: boolean
}) {
	return (
		<section id="reviews" className="scroll-mt-24">
			<div className="flex flex-wrap items-end justify-between gap-4">
				<div>
					<h2 className="text-display-sm">التقييمات</h2>
					{ratingCount > 0 ? (
						<div className="mt-2 flex items-center gap-3">
							<span className="nums font-display text-3xl font-bold">{ratingAvg.toFixed(1)}</span>
							<Rating value={ratingAvg} count={ratingCount} size={16} />
						</div>
					) : (
						<p className="mt-2 text-sm text-ink-soft">لسة مفيش تقييمات للمنتج ده.</p>
					)}
				</div>
			</div>

			<div className="mt-6 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
				<div>
					{reviews.length ? (
						<ul className="divide-y divide-sand">
							{reviews.map((review) => (
								<li key={review.id} className="py-5 first:pt-0">
									<div className="flex items-center justify-between gap-3">
										<div className="flex items-center gap-3">
											<span className="flex h-9 w-9 items-center justify-center rounded-full bg-rose-100 text-sm font-semibold text-rose-700">
												{(review.author?.full_name ?? "ورودي").slice(0, 1)}
											</span>
											<div>
												<p className="text-sm font-medium">
													{review.author?.full_name ?? "عميلة ورودي"}
												</p>
												<p className="nums text-xs text-ink-muted">{formatDate(review.created_at)}</p>
											</div>
										</div>
										<Rating value={review.rating} />
									</div>
									{review.comment ? (
										<p className="mt-3 text-sm leading-relaxed text-ink-soft">{review.comment}</p>
									) : null}
								</li>
							))}
						</ul>
					) : (
						<EmptyState
							icon={<MessageSquareHeart className="h-6 w-6" />}
							title="كون أول واحد يقيمه"
							description="التقييمات متاحة للعملاء اللي استلموا المنتج فعليًا."
						/>
					)}
				</div>

				<div>
					{canReview ? (
						<ReviewForm productId={productId} />
					) : (
						<div className="rounded-3xl border border-sand bg-ivory p-5">
							<h3 className="text-base font-semibold">عاوز تقيم المنتج؟</h3>
							<p className="mt-2 text-sm leading-relaxed text-ink-soft">
								{isSignedIn
									? "التقييم متاح بعد استلام المنتج من أحد طلباتك المكتملة."
									: "سجل دخول بحسابك واطلب المنتج، وبعد الاستلام تقدر تقيمه."}
							</p>
							{!isSignedIn ? (
								<ButtonLink href="/login" variant="outline" size="sm" className="mt-4">
									تسجيل الدخول
								</ButtonLink>
							) : null}
						</div>
					)}
				</div>
			</div>
		</section>
	)
}
