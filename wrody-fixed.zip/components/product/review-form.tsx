"use client"

import { Loader2, Star } from "lucide-react"
import { useActionState, useState } from "react"
import { submitReviewAction } from "@/app/actions/reviews"
import { Button } from "@/components/ui/button"
import { Field, FormAlert, Textarea } from "@/components/ui/field"
import { cn } from "@/lib/utils/cn"

export function ReviewForm({
	productId,
	orderId,
	initialRating = 5,
}: {
	productId: string
	orderId?: string | null
	initialRating?: number
}) {
	const [state, formAction, pending] = useActionState(submitReviewAction, null)
	const [rating, setRating] = useState(initialRating)

	if (state?.ok) {
		return <FormAlert tone="success">{state.message}</FormAlert>
	}

	return (
		<form action={formAction} className="space-y-4 rounded-3xl border border-sand bg-ivory p-5">
			<input type="hidden" name="productId" value={productId} />
			{orderId ? <input type="hidden" name="orderId" value={orderId} /> : null}
			<input type="hidden" name="rating" value={rating} />

			<fieldset>
				<legend className="field-label mb-2">تقييمك</legend>
				<div className="flex items-center gap-1">
					{[1, 2, 3, 4, 5].map((value) => (
						<button
							key={value}
							type="button"
							onClick={() => setRating(value)}
							aria-label={`${value} من ٥`}
							aria-pressed={rating === value}
							className="flex h-11 w-11 items-center justify-center rounded-full transition-colors hover:bg-rose-50"
						>
							<Star
								className={cn(
									"h-6 w-6",
									value <= rating ? "fill-gold-500 text-gold-500" : "text-sand-dark",
								)}
							/>
						</button>
					))}
				</div>
			</fieldset>

			<Field label="رأيك في البوكيه" name="comment" hint="احكيلنا عن الخامة، التغليف، ورد فعل اللي استلم الهدية">
				<Textarea id="comment" name="comment" maxLength={1000} placeholder="البوكيه وصل أجمل من الصور..." />
			</Field>

			{state && !state.ok ? <FormAlert>{state.error}</FormAlert> : null}

			<Button type="submit" disabled={pending}>
				{pending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
				ابعت التقييم
			</Button>
			<p className="text-xs text-ink-muted">التقييم بيظهر بعد مراجعة فريق ورودي.</p>
		</form>
	)
}
