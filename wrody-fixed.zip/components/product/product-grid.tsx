import type { ReactNode } from "react"
import { PackageOpen } from "lucide-react"
import { ProductCard } from "@/components/product/product-card"
import { EmptyState } from "@/components/ui/display"
import { cn } from "@/lib/utils/cn"
import type { ProductCardData } from "@/types"

export function ProductGrid({
	products,
	wishlistIds,
	priorityCount = 0,
	columns = 4,
	emptyTitle = "مفيش منتجات هنا دلوقتي",
	emptyDescription = "جرب تفتح قسم تاني أو تمسح الفلاتر.",
	emptyAction,
	className,
}: {
	products: ProductCardData[]
	wishlistIds?: Set<string>
	priorityCount?: number
	columns?: 2 | 3 | 4
	emptyTitle?: string
	emptyDescription?: string
	emptyAction?: ReactNode
	className?: string
}) {
	if (!products.length) {
		return (
			<EmptyState
				icon={<PackageOpen className="h-6 w-6" />}
				title={emptyTitle}
				description={emptyDescription}
				action={emptyAction}
			/>
		)
	}

	return (
		<div
			className={cn(
				"grid grid-cols-2 gap-3 sm:gap-4",
				columns === 4 && "lg:grid-cols-4",
				columns === 3 && "lg:grid-cols-3",
				columns === 2 && "lg:grid-cols-2",
				className,
			)}
		>
			{products.map((product, index) => (
				<ProductCard
					key={product.id}
					product={product}
					priority={index < priorityCount}
					inWishlist={wishlistIds?.has(product.id) ?? false}
				/>
			))}
		</div>
	)
}
