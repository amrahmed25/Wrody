import { ShoppingBag } from "lucide-react"
import { CartItemRow } from "@/components/cart/cart-item"
import { CouponForm } from "@/components/cart/coupon-form"
import { OrderSummary } from "@/components/cart/order-summary"
import { ButtonLink } from "@/components/ui/button"
import { EmptyState } from "@/components/ui/display"
import type { CartView as CartViewData } from "@/types"

/** Server component: totals arrive already calculated by the cart service. */
export function CartView({ cart }: { cart: CartViewData }) {
	if (!cart.lines.length) {
		return (
			<EmptyState
				icon={<ShoppingBag className="h-6 w-6" />}
				title="السلة فارغة دلوقتي"
				description="اتفرج على البوكيهات الجاهزة، أو ابني بوكيه بالورد اللي يعجبك."
				action={
					<div className="flex flex-wrap justify-center gap-2">
						<ButtonLink href="/shop">تسوق الآن</ButtonLink>
						<ButtonLink href="/custom-bouquet" variant="outline">
							اصنع بوكيهك
						</ButtonLink>
					</div>
				}
			/>
		)
	}

	const hasUnavailable = cart.lines.some((line) => !line.isAvailable)

	return (
		<div className="grid gap-6 lg:grid-cols-[1.6fr_1fr] lg:items-start">
			<section aria-label="منتجات السلة" className="surface p-4 sm:p-6">
				<ul className="divide-y divide-sand">
					{cart.lines.map((line) => (
						<CartItemRow key={line.id} line={line} />
					))}
				</ul>
			</section>

			<aside
				aria-label="ملخص الطلب"
				className="surface space-y-5 p-5 lg:sticky lg:top-[calc(var(--header-height)+1.5rem)]"
			>
				<h2 className="text-base font-semibold">ملخص الطلب</h2>
				<CouponForm appliedCode={cart.totals.couponCode} message={cart.totals.couponMessage} />
				<OrderSummary
					totals={cart.totals}
					deliveryNote="مصاريف التوصيل بتتحدد بدقة بعد اختيار المحافظة."
				/>
				{hasUnavailable ? (
					<p role="alert" className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-xs text-rose-700">
						في منتجات خلصت من المخزن. امسحها عشان تكمل الطلب.
					</p>
				) : null}
				<ButtonLink href="/checkout" size="lg" className="w-full">
					إتمام الطلب
				</ButtonLink>
				<ButtonLink href="/shop" variant="ghost" size="sm" className="w-full">
					كمل تسوق
				</ButtonLink>
			</aside>
		</div>
	)
}
