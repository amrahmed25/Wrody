"use client"

import { Loader2, Tag, X } from "lucide-react"
import { useActionState, useEffect, useTransition } from "react"
import { applyCouponAction, removeCouponAction } from "@/app/actions/cart"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/field"
import { useToast } from "@/components/ui/toast"

/**
 * The coupon code is stored in an httpOnly cookie and re-validated on the
 * server on every cart read and again inside place_order().
 */
export function CouponForm({ appliedCode, message }: { appliedCode: string | null; message: string | null }) {
	const [state, formAction, pending] = useActionState(applyCouponAction, null)
	const [removing, startRemoving] = useTransition()
	const toast = useToast()

	useEffect(() => {
		if (state?.ok && state.message) toast(state.message, "success")
	}, [state, toast])

	if (appliedCode) {
		return (
			<div className="flex items-center justify-between gap-3 rounded-2xl border border-sage-300 bg-sage-50 px-4 py-3">
				<span className="flex items-center gap-2 text-sm font-medium text-sage-700">
					<Tag className="h-4 w-4" />
					{appliedCode}
				</span>
				<button
					type="button"
					disabled={removing}
					onClick={() =>
						startRemoving(async () => {
							const result = await removeCouponAction()
							toast(result.ok ? (result.message ?? "\u062a\u0645 \u0627\u0644\u0625\u0644\u063a\u0627\u0621") : result.error, result.ok ? "info" : "error")
						})
					}
					className="flex h-8 w-8 items-center justify-center rounded-full text-sage-700 transition-colors hover:bg-sage-100 disabled:opacity-50"
					aria-label="إلغاء الكوبون"
				>
					{removing ? <Loader2 className="h-4 w-4 animate-spin" /> : <X className="h-4 w-4" />}
				</button>
			</div>
		)
	}

	return (
		<form action={formAction} className="space-y-2">
			<div className="flex gap-2">
				<label htmlFor="coupon-code" className="sr-only">
					كود الخصم
				</label>
				<Input
					id="coupon-code"
					name="code"
					placeholder="كود الخصم"
					autoComplete="off"
					className="h-11 uppercase"
					aria-describedby={state && !state.ok ? "coupon-error" : undefined}
				/>
				<Button type="submit" variant="outline" disabled={pending} className="shrink-0">
					{pending ? <Loader2 className="h-4 w-4 animate-spin" /> : "تطبيق"}
				</Button>
			</div>
			{state && !state.ok ? (
				<p id="coupon-error" role="alert" className="field-error">
					{state.error}
				</p>
			) : null}
			{message ? <p className="text-xs text-ink-muted">{message}</p> : null}
		</form>
	)
}
