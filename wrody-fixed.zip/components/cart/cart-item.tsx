"use client"

import { Loader2, Trash2 } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useTransition } from "react"
import { removeCartItemAction, updateCartItemAction } from "@/app/actions/cart"
import { QuantitySelector } from "@/components/ui/quantity-selector"
import { useToast } from "@/components/ui/toast"
import { formatPrice } from "@/lib/utils/format"
import type { CartLine } from "@/types"

export function CartItemRow({ line, compact = false }: { line: CartLine; compact?: boolean }) {
	const [pending, startTransition] = useTransition()
	const toast = useToast()

	const onQuantityChange = (quantity: number) => {
		startTransition(async () => {
			const result = await updateCartItemAction({ itemId: line.id, quantity })
			if (!result.ok) toast(result.error, "error")
		})
	}

	const onRemove = () => {
		startTransition(async () => {
			const result = await removeCartItemAction({ itemId: line.id })
			if (!result.ok) toast(result.error, "error")
			else toast("\u0627\u062a\u0634\u0627\u0644 \u0645\u0646 \u0627\u0644\u0633\u0644\u0629", "success")
		})
	}

	const maxQuantity = Math.max(1, Math.min(line.availableStock || 1, 99))

	return (
		<li
			className={
				pending
					? "flex gap-3 py-4 opacity-60 transition-opacity sm:gap-4"
					: "flex gap-3 py-4 transition-opacity sm:gap-4"
			}
		>
			<div className="relative h-24 w-20 shrink-0 overflow-hidden rounded-2xl border border-sand bg-rose-50 sm:h-28 sm:w-24">
				<Image
					src={line.imageUrl ?? "/flowers/tulip.svg"}
					alt={line.name}
					fill
					loading="lazy"
					sizes="96px"
					className="object-cover"
				/>
			</div>

			<div className="flex min-w-0 flex-1 flex-col">
				<div className="flex items-start justify-between gap-3">
					<div className="min-w-0">
						<h3 className="truncate text-[0.95rem] font-semibold">
							{line.slug ? (
								<Link href={`/product/${line.slug}`} className="transition-colors hover:text-rose-700">
									{line.name}
								</Link>
							) : (
								line.name
							)}
						</h3>
						{line.variantName ? (
							<p className="mt-0.5 truncate text-xs text-ink-muted">{line.variantName}</p>
						) : null}
						{line.bouquet ? (
							<p className="mt-1 line-clamp-2 text-xs leading-relaxed text-ink-muted">
								{line.bouquet.size_name} · {line.bouquet.wrapping_name}
								{line.bouquet.card_name ? ` · ${line.bouquet.card_name}` : ""} ·{" "}
								<span className="nums">{line.bouquet.flower_count}</span> وردة
							</p>
						) : null}
						{!line.isAvailable ? (
							<p className="mt-1 text-xs font-medium text-rose-700">
								المنتج خلص — امسحه عشان تكمل الطلب
							</p>
						) : null}
					</div>

					<button
						type="button"
						onClick={onRemove}
						disabled={pending}
						className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-ink-muted transition-colors hover:bg-rose-50 hover:text-rose-700 disabled:opacity-50"
						aria-label={`شيل ${line.name} من السلة`}
					>
						{pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
					</button>
				</div>

				<div className="mt-auto flex flex-wrap items-center justify-between gap-3 pt-3">
					<QuantitySelector
						value={line.quantity}
						onChange={onQuantityChange}
						max={maxQuantity}
						disabled={pending || !line.isAvailable}
						size={compact ? "sm" : "md"}
					/>
					<div className="text-end">
						<p className="nums text-[0.95rem] font-semibold">{formatPrice(line.lineTotal)}</p>
						{line.quantity > 1 ? (
							<p className="nums text-xs text-ink-muted">{formatPrice(line.unitPrice)} للقطعة</p>
						) : null}
					</div>
				</div>
			</div>
		</li>
	)
}
