import { formatPrice } from "@/lib/utils/format"
import type { CartTotals } from "@/types"

/**
 * Read-only presentation of server-calculated totals. The client never adds up
 * money itself — every number here comes from the cart service.
 */
export function OrderSummary({
	totals,
	showDelivery = true,
	deliveryNote,
}: {
	totals: CartTotals
	showDelivery?: boolean
	deliveryNote?: string | null
}) {
	const remainingForFreeDelivery =
		totals.freeDeliveryThreshold && totals.subtotal - totals.discount < totals.freeDeliveryThreshold
			? totals.freeDeliveryThreshold - (totals.subtotal - totals.discount)
			: 0

	return (
		<div className="space-y-3 text-sm">
			<div className="flex items-center justify-between">
				<span className="text-ink-soft">المجموع الفرعي</span>
				<span className="nums font-medium">{formatPrice(totals.subtotal)}</span>
			</div>

			{totals.discount > 0 ? (
				<div className="flex items-center justify-between text-sage-700">
					<span>الخصم {totals.couponCode ? `(${totals.couponCode})` : ""}</span>
					<span className="nums font-medium">- {formatPrice(totals.discount)}</span>
				</div>
			) : null}

			{showDelivery ? (
				<div className="flex items-center justify-between">
					<span className="text-ink-soft">التوصيل</span>
					<span className="nums font-medium">
						{totals.deliveryFee > 0 ? formatPrice(totals.deliveryFee) : "مجانًا"}
					</span>
				</div>
			) : null}

			{remainingForFreeDelivery > 0 ? (
				<p className="rounded-2xl bg-rose-50 px-3 py-2 text-xs text-rose-700">
					فاضل <span className="nums font-semibold">{formatPrice(remainingForFreeDelivery)}</span> وتحصل على توصيل مجاني
				</p>
			) : null}

			{deliveryNote ? <p className="text-xs text-ink-muted">{deliveryNote}</p> : null}

			<div className="flex items-center justify-between border-t border-sand pt-3 text-base">
				<span className="font-semibold">الإجمالي</span>
				<span className="nums font-display text-xl font-bold">{formatPrice(totals.total)}</span>
			</div>
		</div>
	)
}
