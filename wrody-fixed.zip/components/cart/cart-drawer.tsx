"use client"

import { ShoppingBag } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useEffect, useState } from "react"
import { CartItemRow } from "@/components/cart/cart-item"
import { OrderSummary } from "@/components/cart/order-summary"
import { ButtonLink } from "@/components/ui/button"
import { Modal } from "@/components/ui/modal"
import type { CartLine, CartTotals } from "@/types"

/**
 * Mini cart. Data is rendered by the server on every request (the header is a
 * server component), so the drawer never fetches on the client.
 */
export function CartDrawer({
	lines,
	totals,
	count,
}: {
	lines: CartLine[]
	totals: CartTotals
	count: number
}) {
	const [open, setOpen] = useState(false)
	const pathname = usePathname()

	useEffect(() => setOpen(false), [pathname])

	return (
		<>
			<button
				type="button"
				onClick={() => setOpen(true)}
				className="relative flex h-11 min-w-11 items-center justify-center gap-2 rounded-full bg-rose-500 px-3 text-white transition-colors hover:bg-rose-600"
				aria-label={`السلة (${count})`}
				aria-haspopup="dialog"
			>
				<ShoppingBag className="h-5 w-5" />
				{count > 0 ? <span className="nums text-sm font-semibold">{count}</span> : null}
			</button>

			<Modal open={open} onClose={() => setOpen(false)} title="سلة المشتريات" size="md">
				{lines.length ? (
					<div className="space-y-5">
						<ul className="max-h-[46vh] divide-y divide-sand overflow-y-auto">
							{lines.map((line) => (
								<CartItemRow key={line.id} line={line} compact />
							))}
						</ul>
						<div className="rounded-3xl border border-sand bg-cream p-4">
							<OrderSummary totals={totals} showDelivery={false} deliveryNote="التوصيل بيتحسب حسب المحافظة في الخطوة التالية." />
						</div>
						<div className="flex flex-col gap-2 sm:flex-row">
							<ButtonLink href="/checkout" size="lg" className="flex-1">
								إتمام الطلب
							</ButtonLink>
							<ButtonLink href="/cart" size="lg" variant="outline" className="flex-1">
								عرض السلة
							</ButtonLink>
						</div>
					</div>
				) : (
					<div className="py-6 text-center">
						<p className="text-base font-semibold">السلة لسة فارغة</p>
						<p className="mt-2 text-sm text-ink-soft">اختار بوكيه جاهز أو اعمل واحد بمزاجك.</p>
						<div className="mt-5 flex flex-col gap-2 sm:flex-row sm:justify-center">
							<ButtonLink href="/shop">تسوق الآن</ButtonLink>
							<ButtonLink href="/custom-bouquet" variant="outline">
								اصنع بوكيهك
							</ButtonLink>
						</div>
					</div>
				)}
				<p className="mt-4 text-center text-xs text-ink-muted">
					<Link href="/cart" className="underline decoration-sand-dark underline-offset-4">
						كل الأسعار بتتحسب على السيرفر
					</Link>
				</p>
			</Modal>
		</>
	)
}
