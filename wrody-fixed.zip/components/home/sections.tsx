import { Gift, Heart, Palette, Sparkles } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { ButtonLink } from "@/components/ui/button"
import { Rating } from "@/components/ui/display"
import { Reveal } from "@/components/ui/reveal"
import type { Category, Review } from "@/types"

export function Hero({
	headline,
	subheadline,
	badge,
	cta,
	secondaryCta,
}: {
	headline: string
	subheadline: string
	badge?: string | null
	cta: string
	secondaryCta: string
}) {
	return (
		<section className="relative overflow-hidden bg-paper-grain">
			<div className="container-page grid items-center gap-10 py-12 lg:grid-cols-[1.05fr_1fr] lg:gap-16 lg:py-20">
				<div className="max-w-xl">
					{badge ? (
						<span className="inline-flex items-center gap-2 rounded-full border border-sand-dark bg-ivory px-4 py-1.5 text-xs font-medium text-ink-soft">
							<Sparkles className="h-3.5 w-3.5 text-rose-500" />
							{badge}
						</span>
					) : null}
					<h1 className="mt-5 text-display-lg">{headline}</h1>
					<p className="mt-5 text-base leading-relaxed text-ink-soft sm:text-lg">{subheadline}</p>
					<div className="mt-8 flex flex-wrap gap-3">
						<ButtonLink href="/shop" size="lg">
							{cta}
						</ButtonLink>
						<ButtonLink href="/custom-bouquet" size="lg" variant="outline">
							{secondaryCta}
						</ButtonLink>
					</div>
					<dl className="mt-10 grid max-w-md grid-cols-3 gap-4 border-t border-sand pt-6 text-center">
						{[
							{ value: "+٥٠٠", label: "بوكيه اتعمل بإيدينا" },
							{ value: "٤.٩", label: "تقييم العملاء" },
							{ value: "٢-٤ أيام", label: "وقت التنفيذ" },
						].map((stat) => (
							<div key={stat.label}>
								<dt className="font-display text-xl font-bold text-ink">{stat.value}</dt>
								<dd className="mt-1 text-xs text-ink-muted">{stat.label}</dd>
							</div>
						))}
					</dl>
				</div>

				<div className="relative">
					<div className="relative mx-auto aspect-[4/5] w-full max-w-md overflow-hidden rounded-[2.5rem] border border-sand bg-ivory shadow-lift">
						<Image
							src="/hero-bouquet.svg"
							alt="بوكيه ورد هاند ميد من خامة الـPipe Cleaners بألوان وردية وبيج"
							fill
							priority
							sizes="(max-width: 1024px) 90vw, 420px"
							className="object-cover"
						/>
					</div>
					<div className="absolute -bottom-4 start-2 hidden rounded-3xl border border-sand bg-ivory/95 px-4 py-3 shadow-soft backdrop-blur sm:block">
						<p className="text-xs text-ink-muted">خامة</p>
						<p className="text-sm font-semibold">Pipe Cleaners ناعمة</p>
					</div>
				</div>
			</div>
		</section>
	)
}

export function CategoryCard({ category, index }: { category: Category; index: number }) {
	return (
		<Reveal delay={index * 60}>
			<Link
				href={`/shop?category=${category.slug}`}
				className="group block overflow-hidden rounded-3xl border border-sand bg-ivory transition-all duration-300 ease-soft hover:-translate-y-1 hover:shadow-lift"
			>
				<div className="relative aspect-[5/4] overflow-hidden bg-rose-50">
					<Image
						src={category.image_url ?? `/categories/${category.slug}.svg`}
						alt={category.name}
						fill
						sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 220px"
						className="object-cover transition-transform duration-500 ease-soft group-hover:scale-[1.04]"
					/>
				</div>
				<div className="p-4">
					<h3 className="text-base font-semibold">{category.name}</h3>
					{category.description ? (
						<p className="mt-1 line-clamp-2 text-xs leading-relaxed text-ink-muted">
							{category.description}
						</p>
					) : null}
				</div>
			</Link>
		</Reveal>
	)
}

const VALUES = [
	{
		icon: Heart,
		title: "معمول بحب",
		body: "كل وردة بتتلف وتتشكل بإيد فنانين، مفيش قطعتين متطابقتين.",
	},
	{
		icon: Sparkles,
		title: "يفضل معاك",
		body: "خامة الـPipe Cleaners مابتذبلش ومابتحتاجش مياه ولا عناية.",
	},
	{
		icon: Palette,
		title: "تفصيل على مزاجك",
		body: "اختار الورد والألوان والتغليف والكارت، واحنا ننفذه.",
	},
	{
		icon: Gift,
		title: "جاهز كهدية",
		body: "بيوصل متغلف بعناية مع كارت مكتوب بخط اليد.",
	},
]

export function WhyWrody() {
	return (
		<div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
			{VALUES.map((value, index) => (
				<Reveal key={value.title} delay={index * 70}>
					<div className="h-full rounded-3xl border border-sand bg-ivory p-6">
						<span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-rose-50 text-rose-500">
							<value.icon className="h-5 w-5" />
						</span>
						<h3 className="mt-4 text-base font-semibold">{value.title}</h3>
						<p className="mt-2 text-sm leading-relaxed text-ink-soft">{value.body}</p>
					</div>
				</Reveal>
			))}
		</div>
	)
}

export function CustomBouquetBanner() {
	return (
		<section className="container-page">
			<Reveal>
				<div className="grid overflow-hidden rounded-[2.5rem] border border-sand bg-sage-50 lg:grid-cols-2">
					<div className="p-8 sm:p-12">
						<p className="text-xs font-semibold uppercase tracking-[0.18em] text-sage-700">
							اصنع بوكيهك
						</p>
						<h2 className="mt-3 text-display-sm sm:text-display-md">
							بوكيه بمزاجك، خطوة بخطوة
						</h2>
						<p className="mt-4 max-w-md leading-relaxed text-ink-soft">
							اختار نوع الورد وعدده، حدد الحجم والتغليف، وضيف كارت برسالتك. السعر بيتحسب
							قدامك لحظة بلحظة.
						</p>
						<ol className="mt-6 space-y-2.5 text-sm text-ink-soft">
							{["اختار الورد والكميات", "حدد الحجم والتغليف", "اكتب رسالتك على الكارت", "أضف البوكيه للسلة"].map(
								(step, index) => (
									<li key={step} className="flex items-center gap-3">
										<span className="nums flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-ivory text-xs font-semibold text-sage-700">
											{index + 1}
										</span>
										{step}
									</li>
								),
							)}
						</ol>
						<ButtonLink href="/custom-bouquet" variant="sage" size="lg" className="mt-8">
							ابدأ التصميم
						</ButtonLink>
					</div>
					<div className="relative min-h-64 lg:min-h-full">
						<Image
							src="/custom-bouquet.svg"
							alt="خامات ورد هاند ميد جاهزة للتشكيل"
							fill
							sizes="(max-width: 1024px) 100vw, 560px"
							className="object-cover"
						/>
					</div>
				</div>
			</Reveal>
		</section>
	)
}

export function Testimonials({ reviews }: { reviews: Review[] }) {
	if (!reviews.length) return null
	return (
		<div className="grid gap-4 md:grid-cols-3">
			{reviews.slice(0, 3).map((review, index) => (
				<Reveal key={review.id} delay={index * 70}>
					<figure className="h-full rounded-3xl border border-sand bg-ivory p-6">
						<Rating value={review.rating} />
						<blockquote className="mt-4 text-sm leading-relaxed text-ink-soft">
							{review.comment}
						</blockquote>
						<figcaption className="mt-5 flex items-center gap-3 border-t border-sand pt-4">
							<span className="flex h-9 w-9 items-center justify-center rounded-full bg-rose-100 text-sm font-semibold text-rose-700">
								{(review.author?.full_name ?? "ورودي").slice(0, 1)}
							</span>
							<span className="text-sm font-medium">{review.author?.full_name ?? "عميلة ورودي"}</span>
						</figcaption>
					</figure>
				</Reveal>
			))}
		</div>
	)
}

/** Placeholder gallery: clearly labelled, never mixed with real product data. */
export function GalleryStrip({ items }: { items: Array<{ image: string; caption: string }> }) {
	if (!items.length) return null
	return (
		<div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
			{items.map((item, index) => (
				<Reveal key={item.image} delay={index * 45}>
					<figure className="group relative aspect-square overflow-hidden rounded-2xl border border-sand bg-ivory">
						<Image
							src={item.image}
							alt={item.caption}
							fill
							loading="lazy"
							sizes="(max-width: 640px) 45vw, 180px"
							className="object-cover transition-transform duration-500 ease-soft group-hover:scale-105"
						/>
					</figure>
				</Reveal>
			))}
		</div>
	)
}

export function FinalCta({ headline, body }: { headline: string; body?: string | null }) {
	return (
		<section className="container-page">
			<Reveal>
				<div className="rounded-[2.5rem] bg-ink px-6 py-14 text-center text-cream sm:px-12">
					<h2 className="font-display text-display-sm text-cream sm:text-display-md">{headline}</h2>
					{body ? <p className="mx-auto mt-4 max-w-lg text-sm text-cream/75">{body}</p> : null}
					<div className="mt-8 flex flex-wrap justify-center gap-3">
						<ButtonLink href="/shop" size="lg">
							تسوق الآن
						</ButtonLink>
						<ButtonLink
							href="/custom-bouquet"
							size="lg"
							variant="outline"
							className="border-cream/25 bg-transparent text-cream hover:border-cream hover:text-cream"
						>
							اصنع بوكيهك
						</ButtonLink>
					</div>
				</div>
			</Reveal>
		</section>
	)
}
