"use client"

import { Loader2, XCircle } from "lucide-react"
import { useRouter } from "next/navigation"
import { useState, useTransition } from "react"
import { cancelOrderAction } from "@/app/actions/checkout"
import { Button } from "@/components/ui/button"
import { ConfirmDialog } from "@/components/ui/modal"
import { useToast } from "@/components/ui/toast"

/** Cancellation is authorised by cancel_own_order() — this is only the prompt. */
export function CancelOrderButton({ orderId }: { orderId: string }) {
	const router = useRouter()
	const toast = useToast()
	const [open, setOpen] = useState(false)
	const [pending, startTransition] = useTransition()

	const confirm = () =>
		startTransition(async () => {
			const result = await cancelOrderAction(orderId)
			if (!result.ok) {
				toast(result.error, "error")
				return
			}
			setOpen(false)
			toast(result.message ?? "تم إلغاء الطلب.", "success")
			router.refresh()
		})

	return (
		<>
			<Button type="button" variant="ghost" size="sm" onClick={() => setOpen(true)} disabled={pending}>
				{pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <XCircle className="h-4 w-4" />}
				إلغاء الطلب
			</Button>
			<ConfirmDialog
				open={open}
				onClose={() => setOpen(false)}
				onConfirm={confirm}
				pending={pending}
				title="تلغي الطلب؟"
				description="ممكن تلغي الطلب قبل ما يخرج للتوصيل فقط. هنرجع الكميات للمخزن تلقائيًا."
				confirmLabel="أكيد، الغي الطلب"
			/>
		</>
	)
}
