import { Check, CircleSlash } from "lucide-react"
import { cn } from "@/lib/utils/cn"
import { ORDER_STATUS_LABELS, ORDER_TIMELINE, formatDateTime } from "@/lib/utils/format"
import type { OrderEvent, OrderStatus } from "@/types"

export function OrderStatusBadge({ status }: { status: OrderStatus }) {
	const tone =
		status === "delivered"
			? "bg-sage-100 text-sage-700"
			: status === "cancelled"
				? "bg-rose-100 text-rose-700"
				: status === "out_for_delivery"
					? "bg-gold-100 text-[#8A6636]"
					: "bg-cream text-ink-soft"

	return (
		<span className={cn("inline-flex items-center rounded-full px-3 py-1 text-xs font-medium", tone)}>
			{ORDER_STATUS_LABELS[status]}
		</span>
	)
}

/** Vertical timeline on mobile, horizontal on desktop. Pure server component. */
export function OrderTimeline({
	status,
	events = [],
}: {
	status: OrderStatus
	events?: OrderEvent[]
}) {
	if (status === "cancelled") {
		const cancelledAt = events.find((event) => event.status === "cancelled")
		return (
			<div className="flex items-start gap-3 rounded-3xl border border-rose-200 bg-rose-50 p-5">
				<CircleSlash className="mt-0.5 h-5 w-5 shrink-0 text-rose-700" aria-hidden="true" />
				<div>
					<p className="font-semibold text-rose-700">الطلب اتلغى</p>
					<p className="mt-1 text-sm text-rose-700/80">
						{cancelledAt?.note ?? "رجعنا الكميات للمخزون. لو ده مكانش مقصود كلمنا وهنظبطها."}
					</p>
					{cancelledAt ? (
						<p className="nums mt-1 text-xs text-rose-700/70">{formatDateTime(cancelledAt.created_at)}</p>
					) : null}
				</div>
			</div>
		)
	}

	const currentIndex = ORDER_TIMELINE.indexOf(status)
	const eventByStatus = new Map(events.map((event) => [event.status, event]))

	return (
		<ol className="relative space-y-6 sm:flex sm:space-y-0" aria-label="مراحل الطلب">
			{ORDER_TIMELINE.map((step, index) => {
				const done = index <= currentIndex
				const active = index === currentIndex
				const event = eventByStatus.get(step)
				return (
					<li key={step} className="relative flex gap-3 sm:flex-1 sm:flex-col sm:gap-2">
						<div className="flex flex-col items-center sm:w-full sm:flex-row">
							<span
								className={cn(
									"z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 text-xs font-semibold transition-colors",
									done
										? "border-rose-500 bg-rose-500 text-white"
										: "border-sand-dark bg-ivory text-ink-muted",
									active && "ring-4 ring-rose-100",
								)}
								aria-hidden="true"
							>
								{done ? <Check className="h-4 w-4" /> : index + 1}
							</span>
							{index < ORDER_TIMELINE.length - 1 ? (
								<span
									className={cn(
										"absolute start-4 top-8 h-[calc(100%+0.5rem)] w-0.5 sm:static sm:h-0.5 sm:w-full sm:flex-1",
										index < currentIndex ? "bg-rose-400" : "bg-sand",
									)}
									aria-hidden="true"
								/>
							) : null}
						</div>
						<div className="pb-1 sm:pe-4">
							<p className={cn("text-sm", done ? "font-semibold text-ink" : "text-ink-muted")}>
								{ORDER_STATUS_LABELS[step]}
							</p>
							{event ? (
								<p className="nums mt-0.5 text-xs text-ink-muted">{formatDateTime(event.created_at)}</p>
							) : null}
						</div>
					</li>
				)
			})}
		</ol>
	)
}
