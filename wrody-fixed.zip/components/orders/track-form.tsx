"use client"

import { Loader2, Search } from "lucide-react"
import { useActionState } from "react"
import { trackOrderAction } from "@/app/actions/checkout"
import { OrderStatusBadge, OrderTimeline } from "@/components/orders/order-status"
import { Button } from "@/components/ui/button"
import { Field, FormAlert, Input } from "@/components/ui/field"
import type { OrderStatus, PaymentStatus } from "@/types"
import { PAYMENT_STATUS_LABELS, formatDateTime, formatPrice } from "@/lib/utils/format"

/** Shape returned by the track_order() SQL function. */
type TrackResult = {
	found: boolean
	order_number: string
	status: OrderStatus
	payment_status: PaymentStatus
	total: number
	created_at: string
	customer_name: string
	city: string | null
	items: Array<{
		product_name: string
		variant_name: string | null
		quantity: number
		total_price: number
	}>
	events: Array<{ status: OrderStatus; note: string | null; created_at: string }>
}

export function TrackForm({ defaultOrderNumber }: { defaultOrderNumber?: string }) {
	const [state, formAction, pending] = useActionState(trackOrderAction, null)
	const result = state?.ok ? (state.data as unknown as TrackResult | undefined) : undefined

	return (
		<div className="space-y-6">
			<form action={formAction} className="surface space-y-4 p-5">
				{state && !state.ok ? <FormAlert>{state.error}</FormAlert> : null}
				<Field label="رقم الطلب" name="orderNumber" required hint="موجود في رسالة تأكيد الطلب، مثلاً WRD-2026-000124">
					<Input
						id="orderNumber"
						name="orderNumber"
						defaultValue={defaultOrderNumber ?? ""}
						dir="ltr"
						placeholder="WRD-2026-000124"
						className="nums text-start uppercase"
						required
					/>
				</Field>
				<Field label="رقم الموبايل" name="phone" required hint="نفس الرقم اللي طلبت بيه">
					<Input
						id="phone"
						name="phone"
						type="tel"
						inputMode="tel"
						dir="ltr"
						placeholder="01xxxxxxxxx"
						className="nums text-start"
						required
					/>
				</Field>
				<Button type="submit" size="lg" className="w-full" disabled={pending}>
					{pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
					تتبع الطلب
				</Button>
			</form>

			{result ? (
				<section className="surface space-y-5 p-5" aria-live="polite">
					<header className="flex flex-wrap items-start justify-between gap-3">
						<div>
							<p className="nums font-display text-xl font-bold" dir="ltr">
								{result.order_number}
							</p>
							<p className="mt-1 text-xs text-ink-muted">
								{formatDateTime(result.created_at)}
								{result.city ? ` — ${result.city}` : ""}
							</p>
						</div>
						<div className="flex items-center gap-2">
							<span className="text-xs text-ink-soft">{PAYMENT_STATUS_LABELS[result.payment_status]}</span>
							<OrderStatusBadge status={result.status} />
						</div>
					</header>

					<OrderTimeline
						status={result.status}
						events={(result.events ?? []).map((event, index) => ({ id: String(index), ...event }))}
					/>

					<ul className="divide-y divide-sand border-t border-sand pt-2 text-sm">
						{(result.items ?? []).map((item, index) => (
							<li key={`${item.product_name}-${index}`} className="flex items-start justify-between gap-3 py-2.5">
								<span className="min-w-0">
									<span className="block">{item.product_name}</span>
									{item.variant_name ? (
										<span className="block text-xs text-ink-muted">{item.variant_name}</span>
									) : null}
									<span className="nums block text-xs text-ink-muted">× {item.quantity}</span>
								</span>
								<span className="nums shrink-0 font-medium">{formatPrice(item.total_price)}</span>
							</li>
						))}
					</ul>

					<div className="flex items-center justify-between border-t border-sand pt-4">
						<span className="text-sm text-ink-soft">الإجمالي</span>
						<span className="nums font-display text-xl font-bold">{formatPrice(result.total)}</span>
					</div>
				</section>
			) : null}
		</div>
	)
}
