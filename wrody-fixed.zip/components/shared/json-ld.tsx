/**
 * Server-rendered structured data. Kept in one place so every page emits the
 * same shape (Product, Offer, AggregateRating, BreadcrumbList, Organization).
 */
export function JsonLd({ data }: { data: Record<string, unknown> | Array<Record<string, unknown>> }) {
	return (
		<script
			type="application/ld+json"
			dangerouslySetInnerHTML={{ __html: JSON.stringify(data).replace(/</g, "\\u003c") }}
		/>
	)
}
