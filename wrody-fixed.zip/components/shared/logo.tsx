import { cn } from "@/lib/utils/cn"

/**
 * The Wrody mark: five looped chenille petals around a wound core.
 * Drawn with strokes (not fills) so it reads as bent pipe-cleaner wire.
 */
export function LogoMark({ size = 36, className }: { size?: number; className?: string }) {
	return (
		<svg
			width={size}
			height={size}
			viewBox="0 0 48 48"
			fill="none"
			aria-hidden="true"
			className={cn("shrink-0", className)}
		>
			<g stroke="currentColor" strokeWidth="2.4" strokeLinecap="round">
				{[0, 72, 144, 216, 288].map((angle) => (
					<ellipse
						key={angle}
						cx="24"
						cy="14.5"
						rx="6.2"
						ry="9.5"
						transform={`rotate(${angle} 24 24)`}
						opacity="0.95"
					/>
				))}
			</g>
			<circle cx="24" cy="24" r="4.2" fill="currentColor" opacity="0.9" />
		</svg>
	)
}

export function Logo({
	size = 36,
	withWordmark = true,
	className,
	tagline,
}: {
	size?: number
	withWordmark?: boolean
	className?: string
	tagline?: string
}) {
	return (
		<span className={cn("inline-flex items-center gap-2.5", className)}>
			<LogoMark size={size} className="text-rose-500" />
			{withWordmark ? (
				<span className="flex flex-col leading-none">
					<span className="font-display text-xl font-bold tracking-tight text-ink">ورودي</span>
					<span className="mt-0.5 text-[10px] font-medium uppercase tracking-[0.28em] text-ink-muted">
						{tagline ?? "WRODY"}
					</span>
				</span>
			) : null}
		</span>
	)
}
