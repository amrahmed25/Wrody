"use client"

import { Loader2, Save } from "lucide-react"
import { useActionState } from "react"
import { updateProfileAction } from "@/app/actions/account"
import { Button } from "@/components/ui/button"
import { Field, FormAlert, Input } from "@/components/ui/field"

export function ProfileForm({
	fullName,
	phone,
	email,
}: {
	fullName: string
	phone: string
	email: string
}) {
	const [state, formAction, pending] = useActionState(updateProfileAction, null)
	const errors = state && !state.ok ? (state.fieldErrors ?? {}) : {}

	return (
		<form action={formAction} className="space-y-4">
			{state ? (
				<FormAlert tone={state.ok ? "success" : "error"}>
					{state.ok ? (state.message ?? "تم الحفظ.") : state.error}
				</FormAlert>
			) : null}

			<Field label="الاسم بالكامل" name="fullName" required error={errors.fullName}>
				<Input id="fullName" name="fullName" defaultValue={fullName} autoComplete="name" required />
			</Field>
			<Field label="رقم الموبايل" name="phone" required error={errors.phone}>
				<Input
					id="phone"
					name="phone"
					type="tel"
					inputMode="tel"
					dir="ltr"
					defaultValue={phone}
					className="nums text-start"
					autoComplete="tel"
					required
				/>
			</Field>
			<Field label="البريد الإلكتروني" name="email" hint="مرتبط بحساب الدخول ومش بيتغير من هنا">
				<Input id="email" value={email} dir="ltr" className="text-start" disabled readOnly />
			</Field>

			<Button type="submit" disabled={pending}>
				{pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
				احفظ التغييرات
			</Button>
		</form>
	)
}
