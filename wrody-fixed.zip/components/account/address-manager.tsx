"use client"

import { Loader2, MapPin, Plus, Star, Trash2 } from "lucide-react"
import { useRouter } from "next/navigation"
import { useActionState, useEffect, useState, useTransition } from "react"
import {
	deleteAddressAction,
	saveAddressAction,
	setDefaultAddressAction,
} from "@/app/actions/account"
import { Button } from "@/components/ui/button"
import { Checkbox, Field, FormAlert, Input } from "@/components/ui/field"
import { ConfirmDialog } from "@/components/ui/modal"
import { useToast } from "@/components/ui/toast"
import { cn } from "@/lib/utils/cn"
import type { Address } from "@/types"

export function AddressManager({
	addresses,
	cities,
}: {
	addresses: Address[]
	cities: string[]
}) {
	const router = useRouter()
	const toast = useToast()
	const [state, formAction, saving] = useActionState(saveAddressAction, null)
	const [open, setOpen] = useState(addresses.length === 0)
	const [editing, setEditing] = useState<Address | null>(null)
	const [pendingId, setPendingId] = useState<string | null>(null)
	const [confirmDelete, setConfirmDelete] = useState<Address | null>(null)
	const [busy, startTransition] = useTransition()
	const errors = state && !state.ok ? (state.fieldErrors ?? {}) : {}

	useEffect(() => {
		if (state?.ok) {
			setOpen(false)
			setEditing(null)
			router.refresh()
		}
	}, [state, router])

	const runAddressAction = (id: string, action: () => Promise<{ ok: boolean; error?: string }>) => {
		setPendingId(id)
		startTransition(async () => {
			const result = await action()
			setPendingId(null)
			if (!result.ok) {
				toast(result.error ?? "حصل خطأ.", "error")
				return
			}
			setConfirmDelete(null)
			router.refresh()
		})
	}

	return (
		<div className="space-y-4">
			{addresses.length ? (
				<ul className="grid gap-3 sm:grid-cols-2">
					{addresses.map((address) => (
						<li
							key={address.id}
							className={cn(
								"rounded-3xl border p-4",
								address.is_default ? "border-rose-300 bg-rose-50" : "border-sand bg-ivory",
							)}
						>
							<div className="flex items-start justify-between gap-2">
								<p className="flex items-center gap-1.5 text-sm font-semibold">
									<MapPin className="h-4 w-4 text-rose-500" aria-hidden="true" />
									{address.city} — {address.area}
								</p>
								{address.is_default ? (
									<span className="rounded-full bg-rose-100 px-2.5 py-1 text-[0.7rem] font-medium text-rose-700">
										الافتراضي
									</span>
								) : null}
							</div>
							<p className="mt-2 text-xs leading-relaxed text-ink-soft">
								{address.street}
								{address.building ? ` — عمارة ${address.building}` : ""}
								{address.floor ? ` — الدور ${address.floor}` : ""}
								{address.apartment ? ` — شقة ${address.apartment}` : ""}
							</p>
							<p className="nums mt-1 text-xs text-ink-muted" dir="ltr">
								{address.phone}
							</p>

							<div className="mt-3 flex flex-wrap gap-2">
								<Button
									type="button"
									variant="outline"
									size="sm"
									onClick={() => {
										setEditing(address)
										setOpen(true)
									}}
								>
									تعديل
								</Button>
								{!address.is_default ? (
									<Button
										type="button"
										variant="ghost"
										size="sm"
										disabled={busy && pendingId === address.id}
										onClick={() => runAddressAction(address.id, () => setDefaultAddressAction(address.id))}
									>
										{busy && pendingId === address.id ? (
											<Loader2 className="h-4 w-4 animate-spin" />
										) : (
											<Star className="h-4 w-4" />
										)}
										خليه الافتراضي
									</Button>
								) : null}
								<Button
									type="button"
									variant="ghost"
									size="sm"
									onClick={() => setConfirmDelete(address)}
								>
									<Trash2 className="h-4 w-4" />
									حذف
								</Button>
							</div>
						</li>
					))}
				</ul>
			) : null}

			{!open ? (
				<Button
					type="button"
					variant="outline"
					onClick={() => {
						setEditing(null)
						setOpen(true)
					}}
				>
					<Plus className="h-4 w-4" />
					ضيف عنوان جديد
				</Button>
			) : (
				<form action={formAction} className="space-y-4 rounded-3xl border border-sand bg-cream p-4">
					{state && !state.ok ? <FormAlert>{state.error}</FormAlert> : null}
					{editing ? <input type="hidden" name="id" value={editing.id} /> : null}

					<div className="grid gap-4 sm:grid-cols-2">
						<Field label="اسم المستلم" name="fullName" required error={errors.fullName}>
							<Input id="fullName" name="fullName" defaultValue={editing?.full_name ?? ""} required />
						</Field>
						<Field label="رقم الموبايل" name="phone" required error={errors.phone}>
							<Input
								id="phone"
								name="phone"
								type="tel"
								dir="ltr"
								className="nums text-start"
								defaultValue={editing?.phone ?? ""}
								required
							/>
						</Field>
						<Field label="المحافظة" name="city" required error={errors.city}>
							<Input
								id="city"
								name="city"
								list="wrody-cities"
								defaultValue={editing?.city ?? ""}
								required
							/>
						</Field>
						<Field label="المنطقة" name="area" required error={errors.area}>
							<Input id="area" name="area" defaultValue={editing?.area ?? ""} required />
						</Field>
					</div>
					<datalist id="wrody-cities">
						{cities.map((city) => (
							<option key={city} value={city} />
						))}
					</datalist>

					<Field label="الشارع" name="street" required error={errors.street}>
						<Input id="street" name="street" defaultValue={editing?.street ?? ""} required />
					</Field>

					<div className="grid gap-4 sm:grid-cols-3">
						<Field label="العمارة" name="building" error={errors.building}>
							<Input id="building" name="building" className="nums" defaultValue={editing?.building ?? ""} />
						</Field>
						<Field label="الدور" name="floor" error={errors.floor}>
							<Input id="floor" name="floor" className="nums" defaultValue={editing?.floor ?? ""} />
						</Field>
						<Field label="الشقة" name="apartment" error={errors.apartment}>
							<Input id="apartment" name="apartment" className="nums" defaultValue={editing?.apartment ?? ""} />
						</Field>
					</div>

					<Field label="علامة مميزة" name="additionalInfo" error={errors.additionalInfo}>
						<Input
							id="additionalInfo"
							name="additionalInfo"
							defaultValue={editing?.additional_info ?? ""}
							placeholder="جنب أي مكان معروف؟"
						/>
					</Field>

					<label className="flex min-h-11 cursor-pointer items-center gap-3 text-sm text-ink-soft">
						<Checkbox name="isDefault" defaultChecked={editing?.is_default ?? addresses.length === 0} />
						خليه العنوان الافتراضي
					</label>

					<div className="flex gap-3">
						<Button type="submit" disabled={saving}>
							{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
							{editing ? "احفظ التعديل" : "احفظ العنوان"}
						</Button>
						{addresses.length ? (
							<Button
								type="button"
								variant="ghost"
								onClick={() => {
									setOpen(false)
									setEditing(null)
								}}
							>
								إلغاء
							</Button>
						) : null}
					</div>
				</form>
			)}

			<ConfirmDialog
				open={Boolean(confirmDelete)}
				onClose={() => setConfirmDelete(null)}
				onConfirm={() => {
					if (confirmDelete) runAddressAction(confirmDelete.id, () => deleteAddressAction(confirmDelete.id))
				}}
				pending={busy}
				title="تحذف العنوان؟"
				description="الطلبات القديمة مش هتتأثر، لأن العنوان متخزن جواها كنسخة."
				confirmLabel="احذف"
			/>
		</div>
	)
}
