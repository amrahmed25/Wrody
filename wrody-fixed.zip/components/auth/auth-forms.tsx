"use client"

import { Loader2, LogIn, MailCheck, UserPlus } from "lucide-react"
import { useActionState } from "react"
import {
	loginAction,
	registerAction,
	requestPasswordResetAction,
	updatePasswordAction,
} from "@/app/actions/auth"
import { Button } from "@/components/ui/button"
import { Field, FormAlert, Input } from "@/components/ui/field"

export function LoginForm({ next }: { next?: string }) {
	const [state, formAction, pending] = useActionState(loginAction, null)
	const errors = state && !state.ok ? (state.fieldErrors ?? {}) : {}

	return (
		<form action={formAction} className="space-y-4">
			{state && !state.ok ? <FormAlert>{state.error}</FormAlert> : null}
			{next ? <input type="hidden" name="next" value={next} /> : null}

			<Field label="البريد الإلكتروني" name="email" required error={errors.email}>
				<Input
					id="email"
					name="email"
					type="email"
					dir="ltr"
					className="text-start"
					autoComplete="email"
					required
				/>
			</Field>
			<Field label="كلمة السر" name="password" required error={errors.password}>
				<Input
					id="password"
					name="password"
					type="password"
					dir="ltr"
					className="text-start"
					autoComplete="current-password"
					required
				/>
			</Field>

			<Button type="submit" size="lg" className="w-full" disabled={pending}>
				{pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <LogIn className="h-4 w-4" />}
				تسجيل الدخول
			</Button>
		</form>
	)
}

export function RegisterForm({ next }: { next?: string }) {
	const [state, formAction, pending] = useActionState(registerAction, null)
	const errors = state && !state.ok ? (state.fieldErrors ?? {}) : {}

	return (
		<form action={formAction} className="space-y-4">
			{state && !state.ok ? <FormAlert>{state.error}</FormAlert> : null}
			{state?.ok ? <FormAlert tone="success">{state.message ?? "تم إنشاء الحساب."}</FormAlert> : null}
			{next ? <input type="hidden" name="next" value={next} /> : null}

			<Field label="الاسم بالكامل" name="fullName" required error={errors.fullName}>
				<Input id="fullName" name="fullName" autoComplete="name" required />
			</Field>
			<Field label="البريد الإلكتروني" name="email" required error={errors.email}>
				<Input
					id="email"
					name="email"
					type="email"
					dir="ltr"
					className="text-start"
					autoComplete="email"
					required
				/>
			</Field>
			<Field label="رقم الموبايل" name="phone" required error={errors.phone}>
				<Input
					id="phone"
					name="phone"
					type="tel"
					inputMode="tel"
					dir="ltr"
					placeholder="01xxxxxxxxx"
					className="nums text-start"
					autoComplete="tel"
					required
				/>
			</Field>
			<Field label="كلمة السر" name="password" required error={errors.password} hint="٨ حروف على الأقل">
				<Input
					id="password"
					name="password"
					type="password"
					dir="ltr"
					className="text-start"
					autoComplete="new-password"
					required
				/>
			</Field>
			<Field label="تأكيد كلمة السر" name="confirmPassword" required error={errors.confirmPassword}>
				<Input
					id="confirmPassword"
					name="confirmPassword"
					type="password"
					dir="ltr"
					className="text-start"
					autoComplete="new-password"
					required
				/>
			</Field>

			<Button type="submit" size="lg" className="w-full" disabled={pending}>
				{pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserPlus className="h-4 w-4" />}
				إنشاء الحساب
			</Button>
		</form>
	)
}

export function ResetRequestForm() {
	const [state, formAction, pending] = useActionState(requestPasswordResetAction, null)

	return (
		<form action={formAction} className="space-y-4">
			{state ? (
				<FormAlert tone={state.ok ? "success" : "error"}>
					{state.ok ? (state.message ?? "بعتنالك الرابط.") : state.error}
				</FormAlert>
			) : null}

			<Field label="البريد الإلكتروني" name="email" required>
				<Input
					id="email"
					name="email"
					type="email"
					dir="ltr"
					className="text-start"
					autoComplete="email"
					required
				/>
			</Field>

			<Button type="submit" size="lg" className="w-full" disabled={pending}>
				{pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <MailCheck className="h-4 w-4" />}
				ابعتلي رابط الاستعادة
			</Button>
		</form>
	)
}

export function UpdatePasswordForm() {
	const [state, formAction, pending] = useActionState(updatePasswordAction, null)
	const errors = state && !state.ok ? (state.fieldErrors ?? {}) : {}

	return (
		<form action={formAction} className="space-y-4">
			{state && !state.ok ? <FormAlert>{state.error}</FormAlert> : null}

			<Field label="كلمة السر الجديدة" name="password" required error={errors.password}>
				<Input
					id="password"
					name="password"
					type="password"
					dir="ltr"
					className="text-start"
					autoComplete="new-password"
					required
				/>
			</Field>
			<Field label="تأكيد كلمة السر" name="confirmPassword" required error={errors.confirmPassword}>
				<Input
					id="confirmPassword"
					name="confirmPassword"
					type="password"
					dir="ltr"
					className="text-start"
					autoComplete="new-password"
					required
				/>
			</Field>

			<Button type="submit" size="lg" className="w-full" disabled={pending}>
				{pending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
				احفظ كلمة السر الجديدة
			</Button>
		</form>
	)
}
