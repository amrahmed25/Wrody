"use client"

import { Check, Eye, EyeOff, Loader2, Pencil, Plus, Star, Trash2, X } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useState, useTransition } from "react"
import {
	deleteCategoryAction,
	deleteProductAction,
	setProductActiveAction,
	toggleProductFlagAction,
} from "@/app/actions/admin/catalog"
import {
	deleteCouponAction,
	deleteDeliveryZoneAction,
	deleteReviewAction,
	moderateReviewAction,
	toggleCouponAction,
	updateBouquetStatusAction,
} from "@/app/actions/admin/operations"
import {
	CategoryForm,
	CouponForm,
	DeliveryZoneForm,
	type CategoryFormValues,
	type CouponFormValues,
	type DeliveryZoneFormValues,
} from "@/components/admin/forms"
import { AdminTable, type AdminColumn } from "@/components/admin/table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/display"
import { Select } from "@/components/ui/field"
import { ConfirmDialog, Modal } from "@/components/ui/modal"
import { useToast } from "@/components/ui/toast"
import { formatDate, formatPrice } from "@/lib/utils/format"

type ActionLike = () => Promise<{ ok: boolean; error?: string; message?: string }>

/** Shared runner: toast the server message, then refresh server data. */
function useRunner() {
	const router = useRouter()
	const toast = useToast()
	const [busy, startTransition] = useTransition()

	const run = (action: ActionLike, onSuccess?: () => void) =>
		startTransition(async () => {
			const result = await action()
			if (!result.ok) {
				toast(result.error ?? "حصل خطأ.", "error")
				return
			}
			if (result.message) toast(result.message, "success")
			onSuccess?.()
			router.refresh()
		})

	return { busy, run }
}

export type AdminCategoryRow = CategoryFormValues & { products_count?: number }

export function CategoryManager({ categories }: { categories: AdminCategoryRow[] }) {
	const { busy, run } = useRunner()
	const [editing, setEditing] = useState<AdminCategoryRow | null>(null)
	const [creating, setCreating] = useState(false)
	const [confirmDelete, setConfirmDelete] = useState<AdminCategoryRow | null>(null)

	const columns: AdminColumn<AdminCategoryRow>[] = [
		{
			key: "name",
			header: "القسم",
			render: (row) => (
				<div>
					<p className="font-medium">{row.name}</p>
					<p className="text-xs text-ink-muted" dir="ltr">
						/{row.slug}
					</p>
				</div>
			),
		},
		{
			key: "products",
			header: "المنتجات",
			align: "center",
			hideOnMobile: true,
			render: (row) => <span className="nums">{row.products_count ?? 0}</span>,
		},
		{
			key: "sort",
			header: "الترتيب",
			align: "center",
			hideOnMobile: true,
			render: (row) => <span className="nums">{row.sort_order}</span>,
		},
		{
			key: "status",
			header: "الحالة",
			align: "center",
			render: (row) => (
				<Badge tone={row.is_active ? "sage" : "muted"}>{row.is_active ? "ظاهر" : "مخفي"}</Badge>
			),
		},
		{
			key: "actions",
			header: "إجراءات",
			align: "end",
			render: (row) => (
				<div className="flex justify-end gap-1">
					<Button type="button" variant="ghost" size="sm" onClick={() => setEditing(row)}>
						<Pencil className="h-4 w-4" />
						<span className="sr-only">تعديل</span>
					</Button>
					<Button type="button" variant="ghost" size="sm" onClick={() => setConfirmDelete(row)}>
						<Trash2 className="h-4 w-4" />
						<span className="sr-only">حذف</span>
					</Button>
				</div>
			),
		},
	]

	return (
		<div className="space-y-4">
			<div className="flex justify-end">
				<Button type="button" onClick={() => setCreating(true)}>
					<Plus className="h-4 w-4" />
					قسم جديد
				</Button>
			</div>

			<AdminTable columns={columns} rows={categories} empty="مفيش أقسام لسة. أضف أول قسم." />

			<Modal open={creating} onClose={() => setCreating(false)} title="قسم جديد">
				<CategoryForm onDone={() => setCreating(false)} />
			</Modal>

			<Modal open={Boolean(editing)} onClose={() => setEditing(null)} title="تعديل القسم">
				{editing ? <CategoryForm category={editing} onDone={() => setEditing(null)} /> : null}
			</Modal>

			<ConfirmDialog
				open={Boolean(confirmDelete)}
				onClose={() => setConfirmDelete(null)}
				pending={busy}
				title="تحذف القسم؟"
				description="المنتجات مش هتتحذف — هتبقى بدون قسم وتقدر تنقلها بعدين."
				confirmLabel="احذف"
				onConfirm={() => {
					if (confirmDelete) {
						run(() => deleteCategoryAction(confirmDelete.id), () => setConfirmDelete(null))
					}
				}}
			/>
		</div>
	)
}

export type AdminCouponRow = CouponFormValues & { usage_count: number }

export function CouponManager({ coupons }: { coupons: AdminCouponRow[] }) {
	const { busy, run } = useRunner()
	const [editing, setEditing] = useState<AdminCouponRow | null>(null)
	const [creating, setCreating] = useState(false)
	const [confirmDelete, setConfirmDelete] = useState<AdminCouponRow | null>(null)

	const columns: AdminColumn<AdminCouponRow>[] = [
		{
			key: "code",
			header: "الكود",
			render: (row) => (
				<div>
					<p className="font-semibold" dir="ltr">
						{row.code}
					</p>
					{row.description ? <p className="text-xs text-ink-muted">{row.description}</p> : null}
				</div>
			),
		},
		{
			key: "value",
			header: "الخصم",
			render: (row) => (
				<span className="nums">
					{row.discount_type === "percentage" ? `${row.discount_value}%` : formatPrice(row.discount_value)}
				</span>
			),
		},
		{
			key: "usage",
			header: "الاستخدام",
			align: "center",
			hideOnMobile: true,
			render: (row) => (
				<span className="nums">
					{row.usage_count}
					{row.usage_limit ? ` / ${row.usage_limit}` : ""}
				</span>
			),
		},
		{
			key: "expires",
			header: "الانتهاء",
			align: "center",
			hideOnMobile: true,
			render: (row) => (
				<span className="text-xs text-ink-muted">{row.expires_at ? formatDate(row.expires_at) : "مفتوح"}</span>
			),
		},
		{
			key: "status",
			header: "الحالة",
			align: "center",
			render: (row) => (
				<Badge tone={row.is_active ? "sage" : "muted"}>{row.is_active ? "مفعّل" : "متوقف"}</Badge>
			),
		},
		{
			key: "actions",
			header: "إجراءات",
			align: "end",
			render: (row) => (
				<div className="flex justify-end gap-1">
					<Button
						type="button"
						variant="ghost"
						size="sm"
						disabled={busy}
						onClick={() => run(() => toggleCouponAction({ couponId: row.id, isActive: !row.is_active }))}
					>
						{row.is_active ? <X className="h-4 w-4" /> : <Check className="h-4 w-4" />}
						<span className="sr-only">{row.is_active ? "تعطيل" : "تفعيل"}</span>
					</Button>
					<Button type="button" variant="ghost" size="sm" onClick={() => setEditing(row)}>
						<Pencil className="h-4 w-4" />
						<span className="sr-only">تعديل</span>
					</Button>
					<Button type="button" variant="ghost" size="sm" onClick={() => setConfirmDelete(row)}>
						<Trash2 className="h-4 w-4" />
						<span className="sr-only">حذف</span>
					</Button>
				</div>
			),
		},
	]

	return (
		<div className="space-y-4">
			<div className="flex justify-end">
				<Button type="button" onClick={() => setCreating(true)}>
					<Plus className="h-4 w-4" />
					كوبون جديد
				</Button>
			</div>

			<AdminTable columns={columns} rows={coupons} empty="مفيش كوبونات لسة." />

			<Modal open={creating} onClose={() => setCreating(false)} title="كوبون جديد" size="lg">
				<CouponForm onDone={() => setCreating(false)} />
			</Modal>

			<Modal open={Boolean(editing)} onClose={() => setEditing(null)} title="تعديل الكوبون" size="lg">
				{editing ? <CouponForm coupon={editing} onDone={() => setEditing(null)} /> : null}
			</Modal>

			<ConfirmDialog
				open={Boolean(confirmDelete)}
				onClose={() => setConfirmDelete(null)}
				pending={busy}
				title="تحذف الكوبون؟"
				description="لو الكوبون استخدم في طلبات قبل كده، الأفضل تعطيله بدل الحذف."
				confirmLabel="احذف"
				onConfirm={() => {
					if (confirmDelete) {
						run(() => deleteCouponAction(confirmDelete.id), () => setConfirmDelete(null))
					}
				}}
			/>
		</div>
	)
}

export type AdminZoneRow = DeliveryZoneFormValues

export function DeliveryZoneManager({ zones }: { zones: AdminZoneRow[] }) {
	const { busy, run } = useRunner()
	const [editing, setEditing] = useState<AdminZoneRow | null>(null)
	const [confirmDelete, setConfirmDelete] = useState<AdminZoneRow | null>(null)

	return (
		<div className="space-y-4">
			{zones.length ? (
				<ul className="divide-y divide-sand">
					{zones.map((zone) => (
						<li key={zone.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
							<div>
								<p className="text-sm font-medium">
									{zone.city} {zone.is_active ? null : <Badge tone="muted">متوقفة</Badge>}
								</p>
								<p className="nums text-xs text-ink-muted">
									{formatPrice(zone.fee)}
									{zone.estimated_days ? ` • ${zone.estimated_days}` : ""}
								</p>
							</div>
							<div className="flex gap-1">
								<Button type="button" variant="ghost" size="sm" onClick={() => setEditing(zone)}>
									<Pencil className="h-4 w-4" />
									<span className="sr-only">تعديل</span>
								</Button>
								<Button type="button" variant="ghost" size="sm" onClick={() => setConfirmDelete(zone)}>
									<Trash2 className="h-4 w-4" />
									<span className="sr-only">حذف</span>
								</Button>
							</div>
						</li>
					))}
				</ul>
			) : (
				<p className="text-sm text-ink-muted">مفيش مناطق مضافة — هيتم حساب سعر التوصيل الافتراضي لكل المدن.</p>
			)}

			<div className="rounded-2xl border border-sand bg-cream p-4">
				<h3 className="mb-3 text-sm font-semibold text-ink-soft">أضف منطقة توصيل</h3>
				<DeliveryZoneForm />
			</div>

			<Modal open={Boolean(editing)} onClose={() => setEditing(null)} title="تعديل منطقة التوصيل">
				{editing ? <DeliveryZoneForm zone={editing} onDone={() => setEditing(null)} /> : null}
			</Modal>

			<ConfirmDialog
				open={Boolean(confirmDelete)}
				onClose={() => setConfirmDelete(null)}
				pending={busy}
				title="تحذف المنطقة؟"
				confirmLabel="احذف"
				onConfirm={() => {
					if (confirmDelete) {
						run(() => deleteDeliveryZoneAction(confirmDelete.id), () => setConfirmDelete(null))
					}
				}}
			/>
		</div>
	)
}

export function ReviewModerationActions({
	reviewId,
	isApproved,
}: {
	reviewId: string
	isApproved: boolean
}) {
	const { busy, run } = useRunner()
	const [confirmDelete, setConfirmDelete] = useState(false)

	return (
		<div className="flex flex-wrap gap-2">
			<Button
				type="button"
				variant={isApproved ? "outline" : "primary"}
				size="sm"
				disabled={busy}
				onClick={() => run(() => moderateReviewAction({ reviewId, approve: !isApproved }))}
			>
				{busy ? (
					<Loader2 className="h-4 w-4 animate-spin" />
				) : isApproved ? (
					<EyeOff className="h-4 w-4" />
				) : (
					<Check className="h-4 w-4" />
				)}
				{isApproved ? "إخفاء" : "موافقة ونشر"}
			</Button>
			<Button type="button" variant="ghost" size="sm" onClick={() => setConfirmDelete(true)}>
				<Trash2 className="h-4 w-4" />
				حذف
			</Button>

			<ConfirmDialog
				open={confirmDelete}
				onClose={() => setConfirmDelete(false)}
				pending={busy}
				title="تحذف التقييم؟"
				confirmLabel="احذف"
				onConfirm={() => run(() => deleteReviewAction(reviewId), () => setConfirmDelete(false))}
			/>
		</div>
	)
}

export const BOUQUET_STATUS_LABELS: Record<string, string> = {
	draft: "مسودة",
	in_cart: "في العربة",
	ordered: "مطلوب",
	in_production: "تحت التنفيذ",
	completed: "تم التسليم",
	cancelled: "ملغي",
}

const BOUQUET_STATUS_OPTIONS = ["ordered", "in_production", "completed", "cancelled"] as const

export function BouquetStatusControl({
	bouquetId,
	status,
}: {
	bouquetId: string
	status: string
}) {
	const { busy, run } = useRunner()

	return (
		<label className="flex items-center gap-2 text-xs text-ink-muted">
			<span className="sr-only">حالة البوكيه</span>
			<Select
				value={status}
				disabled={busy}
				onChange={(event) =>
					run(() =>
						updateBouquetStatusAction({
							bouquetId,
							status: event.target.value as (typeof BOUQUET_STATUS_OPTIONS)[number],
						}),
					)
				}
				className="min-w-36"
			>
				{BOUQUET_STATUS_OPTIONS.map((option) => (
					<option key={option} value={option}>
						{BOUQUET_STATUS_LABELS[option]}
					</option>
				))}
				{BOUQUET_STATUS_OPTIONS.includes(status as (typeof BOUQUET_STATUS_OPTIONS)[number]) ? null : (
					<option value={status}>{BOUQUET_STATUS_LABELS[status] ?? status}</option>
				)}
			</Select>
			{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
		</label>
	)
}

export function ProductRowActions({
	productId,
	isActive,
	isFeatured,
	isBestSeller,
}: {
	productId: string
	isActive: boolean
	isFeatured: boolean
	isBestSeller: boolean
}) {
	const { busy, run } = useRunner()
	const [confirmDelete, setConfirmDelete] = useState(false)

	return (
		<div className="flex flex-wrap justify-end gap-1">
			<Button
				type="button"
				variant="ghost"
				size="sm"
				disabled={busy}
				title={isFeatured ? "شيل من المميز" : "إضافة للمميز"}
				onClick={() =>
					run(() => toggleProductFlagAction({ productId, flag: "is_featured", value: !isFeatured }))
				}
			>
				<Star className={isFeatured ? "h-4 w-4 fill-gold-500 text-gold-500" : "h-4 w-4"} />
				<span className="sr-only">منتج مميز</span>
			</Button>
			<Button
				type="button"
				variant="ghost"
				size="sm"
				disabled={busy}
				title={isBestSeller ? "شيل من الأكتر مبيعًا" : "إضافة للأكتر مبيعًا"}
				onClick={() =>
					run(() => toggleProductFlagAction({ productId, flag: "is_best_seller", value: !isBestSeller }))
				}
			>
				<span aria-hidden="true" className={isBestSeller ? "text-sm text-rose-600" : "text-sm text-ink-muted"}>
					♥
				</span>
				<span className="sr-only">الأكثر مبيعًا</span>
			</Button>
			<Button
				type="button"
				variant="ghost"
				size="sm"
				disabled={busy}
				title={isActive ? "إخفاء من المتجر" : "نشر في المتجر"}
				onClick={() => run(() => setProductActiveAction({ productId, isActive: !isActive }))}
			>
				{isActive ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
				<span className="sr-only">{isActive ? "إخفاء" : "نشر"}</span>
			</Button>
			<Link
				href={`/admin/products/${productId}`}
				className="grid h-9 w-9 place-items-center rounded-full text-ink-soft transition-colors hover:bg-sand"
				title="تعديل المنتج"
			>
				<Pencil className="h-4 w-4" />
				<span className="sr-only">تعديل</span>
			</Link>
			<Button type="button" variant="ghost" size="sm" onClick={() => setConfirmDelete(true)} title="حذف">
				<Trash2 className="h-4 w-4" />
				<span className="sr-only">حذف</span>
			</Button>

			<ConfirmDialog
				open={confirmDelete}
				onClose={() => setConfirmDelete(false)}
				pending={busy}
				title="تحذف المنتج نهائيًا؟"
				description="لو عايز تشيله من المتجر مع الحفاظ على تاريخه، استخدم الإخفاء."
				confirmLabel="احذف"
				onConfirm={() => run(() => deleteProductAction(productId), () => setConfirmDelete(false))}
			/>
		</div>
	)
}
