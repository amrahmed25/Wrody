"use client"

import { Loader2, Save } from "lucide-react"
import { useRouter } from "next/navigation"
import { useState, useTransition } from "react"
import {
	updateOrderStatusAction,
	updatePaymentStatusAction,
} from "@/app/actions/admin/operations"
import { Button } from "@/components/ui/button"
import { Field, Input, Select } from "@/components/ui/field"
import { useToast } from "@/components/ui/toast"
import { ORDER_STATUS_LABELS, PAYMENT_STATUS_LABELS } from "@/lib/utils/format"
import type { OrderStatus, PaymentStatus } from "@/types"

const ORDER_STATUSES: OrderStatus[] = [
	"pending",
	"confirmed",
	"preparing",
	"out_for_delivery",
	"delivered",
	"cancelled",
]

const PAYMENT_STATUSES: PaymentStatus[] = ["pending", "paid", "failed", "refunded"]

/**
 * Status transitions are validated inside `set_order_status()` in Postgres, so
 * an invalid jump is rejected even if this select is tampered with.
 */
export function OrderStatusControls({
	orderId,
	status,
	paymentStatus,
}: {
	orderId: string
	status: OrderStatus
	paymentStatus: PaymentStatus
}) {
	const router = useRouter()
	const toast = useToast()
	const [nextStatus, setNextStatus] = useState<OrderStatus>(status)
	const [note, setNote] = useState("")
	const [nextPayment, setNextPayment] = useState<PaymentStatus>(paymentStatus)
	const [reference, setReference] = useState("")
	const [busy, startTransition] = useTransition()

	const run = (action: () => Promise<{ ok: boolean; error?: string; message?: string }>) =>
		startTransition(async () => {
			const result = await action()
			if (!result.ok) {
				toast(result.error ?? "حصل خطأ.", "error")
				return
			}
			toast(result.message ?? "تم التحديث.", "success")
			setNote("")
			setReference("")
			router.refresh()
		})

	return (
		<div className="grid gap-4 sm:grid-cols-2">
			<div className="surface space-y-3 p-5">
				<h2 className="text-sm font-semibold text-ink-soft">حالة الطلب</h2>
				<Field label="الحالة الجديدة" name="orderStatus">
					<Select
						id="orderStatus"
						name="orderStatus"
						value={nextStatus}
						onChange={(event) => setNextStatus(event.target.value as OrderStatus)}
					>
						{ORDER_STATUSES.map((option) => (
							<option key={option} value={option}>
								{ORDER_STATUS_LABELS[option]}
							</option>
						))}
					</Select>
				</Field>
				<Field label="ملاحزة تظهر للعميل في التتبع" name="note">
					<Input
						id="note"
						name="note"
						value={note}
						onChange={(event) => setNote(event.target.value)}
						placeholder="مثال: البوكيه تحت التنفيذ دلوقتي"
					/>
				</Field>
				<Button
					type="button"
					disabled={busy || nextStatus === status}
					onClick={() =>
						run(() => updateOrderStatusAction({ orderId, status: nextStatus, note: note.trim() || null }))
					}
				>
					{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
					حدّث الحالة
				</Button>
			</div>

			<div className="surface space-y-3 p-5">
				<h2 className="text-sm font-semibold text-ink-soft">حالة الدفع</h2>
				<Field label="حالة الدفع الجديدة" name="paymentStatus">
					<Select
						id="paymentStatus"
						name="paymentStatus"
						value={nextPayment}
						onChange={(event) => setNextPayment(event.target.value as PaymentStatus)}
					>
						{PAYMENT_STATUSES.map((option) => (
							<option key={option} value={option}>
								{PAYMENT_STATUS_LABELS[option]}
							</option>
						))}
					</Select>
				</Field>
				<Field label="مرجع الدفع (اختياري)" name="reference" hint="رقم إيصال أو مرجع تحويل">
					<Input
						id="reference"
						name="reference"
						dir="ltr"
						className="text-start"
						value={reference}
						onChange={(event) => setReference(event.target.value)}
					/>
				</Field>
				<Button
					type="button"
					variant="outline"
					disabled={busy || nextPayment === paymentStatus}
					onClick={() =>
						run(() =>
							updatePaymentStatusAction({
								orderId,
								paymentStatus: nextPayment,
								reference: reference.trim() || null,
							}),
						)
					}
				>
					{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
					حدّث الدفع
				</Button>
				<p className="text-xs text-ink-muted">
					الدفع عند الاستلام بيتأكد يدويًا من هنا. لما يتركّب بوابة دفع، هي اللي هتحدّث الحالة أوتوماتيك.
				</p>
			</div>
		</div>
	)
}
