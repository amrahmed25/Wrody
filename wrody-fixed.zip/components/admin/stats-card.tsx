import type { ReactNode } from "react"
import { cn } from "@/lib/utils/cn"

export function StatsCard({
	label,
	value,
	hint,
	icon,
	tone = "default",
}: {
	label: string
	value: string | number
	hint?: string
	icon?: ReactNode
	tone?: "default" | "rose" | "sage" | "gold"
}) {
	return (
		<div className="surface p-5">
			<div className="flex items-start justify-between gap-3">
				<p className="text-sm text-ink-soft">{label}</p>
				{icon ? (
					<span
						className={cn(
							"flex h-9 w-9 items-center justify-center rounded-2xl",
							tone === "rose" && "bg-rose-50 text-rose-600",
							tone === "sage" && "bg-sage-50 text-sage-700",
							tone === "gold" && "bg-gold-100 text-gold-500",
							tone === "default" && "bg-cream text-ink-soft",
						)}
						aria-hidden="true"
					>
						{icon}
					</span>
				) : null}
			</div>
			<p className="nums mt-3 font-display text-2xl font-bold text-ink">{value}</p>
			{hint ? <p className="mt-1 text-xs text-ink-muted">{hint}</p> : null}
		</div>
	)
}
