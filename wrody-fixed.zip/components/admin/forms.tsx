"use client"

import { Loader2, Save } from "lucide-react"
import { useRouter } from "next/navigation"
import { useActionState, useEffect } from "react"
import { saveCategoryAction } from "@/app/actions/admin/catalog"
import {
	saveCouponAction,
	saveDeliveryZoneAction,
	updateSettingsAction,
} from "@/app/actions/admin/operations"
import { Button } from "@/components/ui/button"
import { Checkbox, Field, FormAlert, Input, Select, Textarea } from "@/components/ui/field"
import { useToast } from "@/components/ui/toast"

/** Trims a timestamptz down to the value shape `datetime-local` expects. */
function toLocalInput(value?: string | null) {
	if (!value) return ""
	return value.slice(0, 16)
}

export type CategoryFormValues = {
	id: string
	name: string
	slug: string
	description: string | null
	image_url: string | null
	sort_order: number
	is_active: boolean
}

export function CategoryForm({
	category,
	onDone,
}: {
	category?: CategoryFormValues | null
	onDone?: () => void
}) {
	const router = useRouter()
	const toast = useToast()
	const [state, formAction, pending] = useActionState(saveCategoryAction, null)
	const errors = state && !state.ok ? (state.fieldErrors ?? {}) : {}

	useEffect(() => {
		if (state?.ok) {
			toast(state.message ?? "تم الحفظ.", "success")
			onDone?.()
			router.refresh()
		}
	}, [state, onDone, router, toast])

	return (
		<form action={formAction} className="space-y-4">
			{state && !state.ok ? <FormAlert>{state.error}</FormAlert> : null}
			{category ? <input type="hidden" name="id" value={category.id} /> : null}

			<Field label="اسم القسم" name="name" required error={errors.name}>
				<Input id="categoryName" name="name" defaultValue={category?.name ?? ""} required />
			</Field>
			<Field label="الرابط (slug)" name="slug" error={errors.slug} hint="سيبه فاضي وهنولده من الاسم">
				<Input
					id="categorySlug"
					name="slug"
					dir="ltr"
					className="text-start"
					defaultValue={category?.slug ?? ""}
				/>
			</Field>
			<Field label="الوصف" name="description" error={errors.description}>
				<Textarea id="categoryDescription" name="description" rows={3} defaultValue={category?.description ?? ""} />
			</Field>
			<Field label="صورة القسم" name="imageUrl" error={errors.imageUrl} hint="رابط داخلي أو رابط Supabase Storage">
				<Input
					id="categoryImage"
					name="imageUrl"
					dir="ltr"
					className="text-start"
					defaultValue={category?.image_url ?? ""}
					placeholder="/categories/bouquets.svg"
				/>
			</Field>
			<Field label="ترتيب الظهور" name="sortOrder" error={errors.sortOrder}>
				<Input
					id="categorySort"
					name="sortOrder"
					type="number"
					min={0}
					step="1"
					className="nums"
					defaultValue={category?.sort_order ?? 0}
				/>
			</Field>
			<label className="flex min-h-11 cursor-pointer items-center gap-3 text-sm">
				<Checkbox name="isActive" defaultChecked={category?.is_active ?? true} />
				ظاهر في المتجر
			</label>

			<Button type="submit" disabled={pending}>
				{pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
				احفظ القسم
			</Button>
		</form>
	)
}

export type CouponFormValues = {
	id: string
	code: string
	description: string | null
	discount_type: "percentage" | "fixed"
	discount_value: number
	minimum_order: number | null
	maximum_discount: number | null
	usage_limit: number | null
	usage_limit_per_user: number | null
	starts_at: string | null
	expires_at: string | null
	is_active: boolean
}

export function CouponForm({
	coupon,
	onDone,
}: {
	coupon?: CouponFormValues | null
	onDone?: () => void
}) {
	const router = useRouter()
	const toast = useToast()
	const [state, formAction, pending] = useActionState(saveCouponAction, null)
	const errors = state && !state.ok ? (state.fieldErrors ?? {}) : {}

	useEffect(() => {
		if (state?.ok) {
			toast(state.message ?? "تم الحفظ.", "success")
			onDone?.()
			router.refresh()
		}
	}, [state, onDone, router, toast])

	return (
		<form action={formAction} className="space-y-4">
			{state && !state.ok ? <FormAlert>{state.error}</FormAlert> : null}
			{coupon ? <input type="hidden" name="id" value={coupon.id} /> : null}

			<div className="grid gap-4 sm:grid-cols-2">
				<Field label="الكود" name="code" required error={errors.code} hint="حروف إنجليزية كبيرة وأرقام">
					<Input
						id="couponCode"
						name="code"
						dir="ltr"
						className="text-start uppercase"
						defaultValue={coupon?.code ?? ""}
						placeholder="WELCOME10"
						required
					/>
				</Field>
				<Field label="نوع الخصم" name="discountType" required error={errors.discountType}>
					<Select id="discountType" name="discountType" defaultValue={coupon?.discount_type ?? "percentage"}>
						<option value="percentage">نسبة مئوية %</option>
						<option value="fixed">مبلغ ثابت (ج.م)</option>
					</Select>
				</Field>
				<Field label="قيمة الخصم" name="discountValue" required error={errors.discountValue}>
					<Input
						id="discountValue"
						name="discountValue"
						type="number"
						min={0}
						step="0.01"
						className="nums"
						defaultValue={coupon?.discount_value ?? ""}
						required
					/>
				</Field>
				<Field label="أقل قيمة للطلب" name="minimumOrder" error={errors.minimumOrder}>
					<Input
						id="minimumOrder"
						name="minimumOrder"
						type="number"
						min={0}
						step="0.01"
						className="nums"
						defaultValue={coupon?.minimum_order ?? ""}
					/>
				</Field>
				<Field label="أقصى خصم" name="maximumDiscount" error={errors.maximumDiscount} hint="مفيد مع الخصم بالنسبة">
					<Input
						id="maximumDiscount"
						name="maximumDiscount"
						type="number"
						min={0}
						step="0.01"
						className="nums"
						defaultValue={coupon?.maximum_discount ?? ""}
					/>
				</Field>
				<Field label="حد الاستخدام الكلي" name="usageLimit" error={errors.usageLimit}>
					<Input
						id="usageLimit"
						name="usageLimit"
						type="number"
						min={1}
						step="1"
						className="nums"
						defaultValue={coupon?.usage_limit ?? ""}
					/>
				</Field>
				<Field label="حد الاستخدام للعميل" name="usageLimitPerUser" error={errors.usageLimitPerUser}>
					<Input
						id="usageLimitPerUser"
						name="usageLimitPerUser"
						type="number"
						min={1}
						step="1"
						className="nums"
						defaultValue={coupon?.usage_limit_per_user ?? ""}
					/>
				</Field>
				<Field label="يبدأ في" name="startsAt" error={errors.startsAt}>
					<Input
						id="startsAt"
						name="startsAt"
						type="datetime-local"
						className="nums"
						defaultValue={toLocalInput(coupon?.starts_at)}
					/>
				</Field>
				<Field label="ينتهي في" name="expiresAt" error={errors.expiresAt}>
					<Input
						id="expiresAt"
						name="expiresAt"
						type="datetime-local"
						className="nums"
						defaultValue={toLocalInput(coupon?.expires_at)}
					/>
				</Field>
			</div>

			<Field label="وصف داخلي" name="description" error={errors.description}>
				<Input id="couponDescription" name="description" defaultValue={coupon?.description ?? ""} />
			</Field>

			<label className="flex min-h-11 cursor-pointer items-center gap-3 text-sm">
				<Checkbox name="isActive" defaultChecked={coupon?.is_active ?? true} />
				مفعّل
			</label>

			<Button type="submit" disabled={pending}>
				{pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
				احفظ الكوبون
			</Button>
		</form>
	)
}

export type DeliveryZoneFormValues = {
	id: string
	city: string
	fee: number
	estimated_days: string | null
	is_active: boolean
}

export function DeliveryZoneForm({
	zone,
	onDone,
}: {
	zone?: DeliveryZoneFormValues | null
	onDone?: () => void
}) {
	const router = useRouter()
	const toast = useToast()
	const [state, formAction, pending] = useActionState(saveDeliveryZoneAction, null)
	const errors = state && !state.ok ? (state.fieldErrors ?? {}) : {}

	useEffect(() => {
		if (state?.ok) {
			toast(state.message ?? "تم الحفظ.", "success")
			onDone?.()
			router.refresh()
		}
	}, [state, onDone, router, toast])

	return (
		<form action={formAction} className="grid gap-4 sm:grid-cols-4 sm:items-end">
			{state && !state.ok ? (
				<div className="sm:col-span-4">
					<FormAlert>{state.error}</FormAlert>
				</div>
			) : null}
			{zone ? <input type="hidden" name="id" value={zone.id} /> : null}

			<Field label="المحافظة" name="city" required error={errors.city}>
				<Input id="zoneCity" name="city" defaultValue={zone?.city ?? ""} required />
			</Field>
			<Field label="سعر التوصيل" name="fee" required error={errors.fee}>
				<Input
					id="zoneFee"
					name="fee"
					type="number"
					min={0}
					step="0.01"
					className="nums"
					defaultValue={zone?.fee ?? ""}
					required
				/>
			</Field>
			<Field label="مدة التوصيل" name="estimatedDays" error={errors.estimatedDays}>
				<Input id="zoneDays" name="estimatedDays" defaultValue={zone?.estimated_days ?? ""} placeholder="٢-٣ أيام" />
			</Field>
			<div className="space-y-3">
				<label className="flex min-h-11 cursor-pointer items-center gap-3 text-sm">
					<Checkbox name="isActive" defaultChecked={zone?.is_active ?? true} />
					متاحة
				</label>
				<Button type="submit" variant="outline" disabled={pending} className="w-full">
					{pending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
					{zone ? "احفظ" : "أضف منطقة"}
				</Button>
			</div>
		</form>
	)
}

export type SettingsFormValues = {
	deliveryFee: number
	freeDeliveryThreshold: number | null
	heroHeadline: string
	heroSubheadline: string
	heroBadge: string
	ctaHeadline: string
	ctaBody: string
	contactPhone: string
	contactEmail: string
	instagram: string
}

/** Homepage copy + delivery pricing. Values are stored in `site_settings`. */
export function SettingsForm({ values }: { values: SettingsFormValues }) {
	const router = useRouter()
	const toast = useToast()
	const [state, formAction, pending] = useActionState(updateSettingsAction, null)
	const errors = state && !state.ok ? (state.fieldErrors ?? {}) : {}

	useEffect(() => {
		if (state?.ok) {
			toast(state.message ?? "تم حفظ الإعدادات.", "success")
			router.refresh()
		}
	}, [state, router, toast])

	return (
		<form action={formAction} className="space-y-5">
			{state && !state.ok ? <FormAlert>{state.error}</FormAlert> : null}

			<div className="surface space-y-4 p-5">
				<h2 className="text-sm font-semibold text-ink-soft">التوصيل</h2>
				<div className="grid gap-4 sm:grid-cols-2">
					<Field label="سعر التوصيل الافتراضي" name="deliveryFee" required error={errors.deliveryFee}>
						<Input
							id="deliveryFee"
							name="deliveryFee"
							type="number"
							min={0}
							step="0.01"
							className="nums"
							defaultValue={values.deliveryFee}
							required
						/>
					</Field>
					<Field
						label="التوصيل مجانًا بعد"
						name="freeDeliveryThreshold"
						error={errors.freeDeliveryThreshold}
						hint="سيبه فاضي لتعطيل العرض"
					>
						<Input
							id="freeDeliveryThreshold"
							name="freeDeliveryThreshold"
							type="number"
							min={0}
							step="0.01"
							className="nums"
							defaultValue={values.freeDeliveryThreshold ?? ""}
						/>
					</Field>
				</div>
			</div>

			<div className="surface space-y-4 p-5">
				<h2 className="text-sm font-semibold text-ink-soft">محتوى الصفحة الرئيسية</h2>
				<Field label="عنوان الهيرو" name="heroHeadline" required error={errors.heroHeadline}>
					<Input id="heroHeadline" name="heroHeadline" defaultValue={values.heroHeadline} required />
				</Field>
				<Field label="النص المساعد" name="heroSubheadline" required error={errors.heroSubheadline}>
					<Textarea
						id="heroSubheadline"
						name="heroSubheadline"
						rows={3}
						defaultValue={values.heroSubheadline}
						required
					/>
				</Field>
				<Field label="شارة صغيرة فوق العنوان" name="heroBadge" error={errors.heroBadge}>
					<Input id="heroBadge" name="heroBadge" defaultValue={values.heroBadge} />
				</Field>
				<Field label="عنوان قسم النهاية" name="ctaHeadline" required error={errors.ctaHeadline}>
					<Input id="ctaHeadline" name="ctaHeadline" defaultValue={values.ctaHeadline} required />
				</Field>
				<Field label="نص قسم النهاية" name="ctaBody" error={errors.ctaBody}>
					<Textarea id="ctaBody" name="ctaBody" rows={2} defaultValue={values.ctaBody} />
				</Field>
			</div>

			<div className="surface space-y-4 p-5">
				<h2 className="text-sm font-semibold text-ink-soft">بيانات التواصل</h2>
				<div className="grid gap-4 sm:grid-cols-3">
					<Field label="رقم الموبايل" name="contactPhone" error={errors.contactPhone}>
						<Input
							id="contactPhone"
							name="contactPhone"
							dir="ltr"
							className="nums text-start"
							defaultValue={values.contactPhone}
						/>
					</Field>
					<Field label="البريد الإلكتروني" name="contactEmail" error={errors.contactEmail}>
						<Input
							id="contactEmail"
							name="contactEmail"
							type="email"
							dir="ltr"
							className="text-start"
							defaultValue={values.contactEmail}
						/>
					</Field>
					<Field label="إنستجرام" name="instagram" error={errors.instagram} hint="بدون @">
						<Input
							id="instagram"
							name="instagram"
							dir="ltr"
							className="text-start"
							defaultValue={values.instagram}
						/>
					</Field>
				</div>
			</div>

			<Button type="submit" disabled={pending}>
				{pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
				احفظ الإعدادات
			</Button>
		</form>
	)
}
