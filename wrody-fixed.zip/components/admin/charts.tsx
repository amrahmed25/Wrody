import { cn } from "@/lib/utils/cn"

export type ChartPoint = { label: string; value: number }

/**
 * Hand-rolled SVG/CSS charts — no charting dependency ships to the browser and
 * these render entirely on the server.
 */
export function TrendChart({
	points,
	formatValue,
	height = 160,
	tone = "rose",
}: {
	points: ChartPoint[]
	formatValue?: (value: number) => string
	height?: number
	tone?: "rose" | "sage"
}) {
	if (points.length < 2) {
		return <p className="py-10 text-center text-sm text-ink-muted">محتاجين بيانات أكتر عشان نرسم المنحنى.</p>
	}

	const width = 600
	const max = Math.max(...points.map((point) => point.value), 1)
	const stepX = width / (points.length - 1)
	const y = (value: number) => height - (value / max) * (height - 24) - 12
	const line = points.map((point, index) => `${index * stepX},${y(point.value)}`).join(" ")
	const area = `0,${height} ${line} ${width},${height}`
	const stroke = tone === "sage" ? "#7F9C86" : "#C27B8C"
	const fill = tone === "sage" ? "rgba(127,156,134,0.14)" : "rgba(194,123,140,0.14)"
	const last = points[points.length - 1]

	return (
		<figure className="space-y-2">
			<svg
				viewBox={`0 0 ${width} ${height}`}
				className="h-40 w-full"
				role="img"
				aria-label={`منحنى ينتهي عند ${formatValue ? formatValue(last.value) : last.value} في ${last.label}`}
				preserveAspectRatio="none"
			>
				<polygon points={area} fill={fill} />
				<polyline
					points={line}
					fill="none"
					stroke={stroke}
					strokeWidth={2.5}
					strokeLinejoin="round"
					strokeLinecap="round"
					vectorEffect="non-scaling-stroke"
				/>
			</svg>
			<div className="flex justify-between text-xs text-ink-muted">
				<span className="nums">{points[0].label}</span>
				<span className="nums">{last.label}</span>
			</div>
		</figure>
	)
}

export function BarList({
	items,
	formatValue,
	tone = "rose",
	emptyLabel = "مفيش بيانات لسة.",
}: {
	items: ChartPoint[]
	formatValue?: (value: number) => string
	tone?: "rose" | "sage" | "gold"
	emptyLabel?: string
}) {
	if (!items.length) return <p className="py-8 text-center text-sm text-ink-muted">{emptyLabel}</p>
	const max = Math.max(...items.map((item) => item.value), 1)

	return (
		<ul className="space-y-3">
			{items.map((item) => (
				<li key={item.label}>
					<div className="flex items-center justify-between gap-3 text-sm">
						<span className="truncate text-ink-soft">{item.label}</span>
						<span className="nums shrink-0 font-medium">
							{formatValue ? formatValue(item.value) : item.value}
						</span>
					</div>
					<div className="mt-1.5 h-2 overflow-hidden rounded-full bg-sand">
						<div
							className={cn(
								"h-full rounded-full",
								tone === "sage" ? "bg-sage-500" : tone === "gold" ? "bg-gold-500" : "bg-rose-400",
							)}
							style={{ width: `${Math.max(4, Math.round((item.value / max) * 100))}%` }}
						/>
					</div>
				</li>
			))}
		</ul>
	)
}
