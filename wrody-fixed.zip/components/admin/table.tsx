import type { ReactNode } from "react"
import { cn } from "@/lib/utils/cn"

export type AdminColumn<T> = {
	key: string
	header: string
	render: (row: T) => ReactNode
	align?: "start" | "center" | "end"
	/** Hide on small screens to keep mobile tables readable. */
	hideOnMobile?: boolean
	width?: string
}

export function AdminTable<T extends { id: string }>({
	columns,
	rows,
	empty = "مفيش بيانات للعرض دلوقتي.",
	caption,
}: {
	columns: AdminColumn<T>[]
	rows: T[]
	empty?: ReactNode
	caption?: string
}) {
	if (!rows.length) {
		return (
			<div className="surface p-10 text-center text-sm text-ink-soft">{empty}</div>
		)
	}

	return (
		<div className="surface overflow-x-auto">
			<table className="w-full min-w-[38rem] border-collapse text-sm">
				{caption ? <caption className="sr-only">{caption}</caption> : null}
				<thead>
					<tr className="border-b border-sand text-xs text-ink-muted">
						{columns.map((column) => (
							<th
								key={column.key}
								scope="col"
								style={column.width ? { width: column.width } : undefined}
								className={cn(
									"px-4 py-3 font-medium",
									column.align === "end" ? "text-end" : column.align === "center" ? "text-center" : "text-start",
									column.hideOnMobile && "hidden md:table-cell",
								)}
							>
								{column.header}
							</th>
						))}
					</tr>
				</thead>
				<tbody className="divide-y divide-sand">
					{rows.map((row) => (
						<tr key={row.id} className="transition-colors hover:bg-cream/60">
							{columns.map((column) => (
								<td
									key={column.key}
									className={cn(
										"px-4 py-3.5 align-middle",
										column.align === "end" ? "text-end" : column.align === "center" ? "text-center" : "text-start",
										column.hideOnMobile && "hidden md:table-cell",
									)}
								>
									{column.render(row)}
								</td>
							))}
						</tr>
					))}
				</tbody>
			</table>
		</div>
	)
}
