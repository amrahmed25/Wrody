"use client"

import { Menu, Store, X } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useEffect, useState, type ReactNode } from "react"
import { AdminNav } from "@/components/admin/sidebar"
import { Logo } from "@/components/shared/logo"

/**
 * Only the shell is a client component (it owns the mobile drawer state);
 * every admin page rendered inside it stays a server component.
 */
export function AdminShell({ children, adminName }: { children: ReactNode; adminName: string }) {
	const [open, setOpen] = useState(false)
	const pathname = usePathname()

	useEffect(() => setOpen(false), [pathname])

	return (
		<div className="min-h-dvh bg-cream lg:grid lg:grid-cols-[16rem_1fr]">
			<aside className="hidden border-e border-sand bg-ivory lg:sticky lg:top-0 lg:block lg:h-dvh lg:overflow-y-auto">
				<div className="flex h-[4.5rem] items-center border-b border-sand px-5">
					<Link href="/admin" aria-label="لوحة تحكم ورودي">
						<Logo size={32} />
					</Link>
				</div>
				<div className="p-4">
					<p className="px-3.5 pb-3 text-xs text-ink-muted">أهلًا {adminName}</p>
					<AdminNav />
					<Link
						href="/"
						className="mt-6 flex min-h-11 items-center gap-3 rounded-2xl px-3.5 text-sm text-ink-soft transition-colors hover:bg-cream hover:text-ink"
					>
						<Store className="h-4.5 w-4.5" aria-hidden="true" />
						رجوع للمتجر
					</Link>
				</div>
			</aside>

			<div className="min-w-0">
				<header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-sand bg-ivory/95 px-4 backdrop-blur lg:hidden">
					<Link href="/admin" aria-label="لوحة تحكم ورودي">
						<Logo size={28} />
					</Link>
					<button
						type="button"
						onClick={() => setOpen(true)}
						className="flex h-11 w-11 items-center justify-center rounded-full text-ink transition-colors hover:bg-cream"
						aria-label="فتح قائمة الإدارة"
						aria-expanded={open}
					>
						<Menu className="h-5 w-5" />
					</button>
				</header>

				{open ? (
					<div className="fixed inset-0 z-50 lg:hidden">
						<button
							type="button"
							className="absolute inset-0 bg-ink/40 backdrop-blur-sm"
							onClick={() => setOpen(false)}
							aria-label="إغلاق القائمة"
						/>
						<div className="absolute inset-y-0 end-0 w-[17rem] overflow-y-auto bg-ivory p-4 shadow-lift animate-slide-up">
							<div className="mb-4 flex items-center justify-between">
								<Logo size={28} />
								<button
									type="button"
									onClick={() => setOpen(false)}
									className="flex h-11 w-11 items-center justify-center rounded-full text-ink hover:bg-cream"
									aria-label="إغلاق"
								>
									<X className="h-5 w-5" />
								</button>
							</div>
							<AdminNav onNavigate={() => setOpen(false)} />
						</div>
					</div>
				) : null}

				<main className="px-4 py-6 sm:px-6 lg:px-8 lg:py-8">{children}</main>
			</div>
		</div>
	)
}
