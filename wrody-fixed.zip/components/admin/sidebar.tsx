"use client"

import {
	BarChart3,
	Flower2,
	LayoutGrid,
	Package,
	Settings,
	ShoppingCart,
	Star,
	Ticket,
	Users,
} from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils/cn"

export const ADMIN_NAV = [
	{ href: "/admin", label: "نظرة عامة", icon: BarChart3, exact: true },
	{ href: "/admin/orders", label: "الطلبات", icon: ShoppingCart },
	{ href: "/admin/products", label: "المنتجات", icon: Package },
	{ href: "/admin/categories", label: "الأقسام", icon: LayoutGrid },
	{ href: "/admin/bouquets", label: "البوكيهات المخصصة", icon: Flower2 },
	{ href: "/admin/customers", label: "العملاء", icon: Users },
	{ href: "/admin/coupons", label: "الكوبونات", icon: Ticket },
	{ href: "/admin/reviews", label: "التقييمات", icon: Star },
	{ href: "/admin/settings", label: "الإعدادات", icon: Settings },
] as const

export function AdminNav({ onNavigate }: { onNavigate?: () => void }) {
	const pathname = usePathname()

	return (
		<nav aria-label="أقسام لوحة التحكم" className="space-y-1">
			{ADMIN_NAV.map((item) => {
				const active = item.exact ? pathname === item.href : pathname.startsWith(item.href)
				const Icon = item.icon
				return (
					<Link
						key={item.href}
						href={item.href}
						onClick={onNavigate}
						aria-current={active ? "page" : undefined}
						className={cn(
							"flex min-h-11 items-center gap-3 rounded-2xl px-3.5 text-sm transition-colors",
							active ? "bg-rose-50 font-semibold text-rose-700" : "text-ink-soft hover:bg-cream hover:text-ink",
						)}
					>
						<Icon className="h-4.5 w-4.5 shrink-0" aria-hidden="true" />
						{item.label}
					</Link>
				)
			})}
		</nav>
	)
}
