"use client"

import { Eye, EyeOff, Loader2, Save, Trash2 } from "lucide-react"
import { useRouter } from "next/navigation"
import { useActionState, useEffect, useState, useTransition } from "react"
import {
	deleteProductAction,
	saveProductAction,
	setProductActiveAction,
} from "@/app/actions/admin/catalog"
import { Button } from "@/components/ui/button"
import { Checkbox, Field, FormAlert, Input, Select, Textarea } from "@/components/ui/field"
import { ConfirmDialog } from "@/components/ui/modal"
import { useToast } from "@/components/ui/toast"
import type { Category } from "@/types"

export type ProductFormValues = {
	id: string
	name: string
	slug: string
	category_id: string | null
	short_description: string | null
	description: string | null
	price: number
	compare_at_price: number | null
	stock: number
	sku: string | null
	is_active: boolean
	is_featured: boolean
	is_best_seller: boolean
}

/**
 * One form for create + edit. The server action re-validates everything and
 * derives the slug when it is left empty, so nothing here is trusted.
 */
export function ProductForm({
	product,
	categories,
}: {
	product: ProductFormValues | null
	categories: Category[]
}) {
	const router = useRouter()
	const toast = useToast()
	const [state, formAction, pending] = useActionState(saveProductAction, null)
	const [confirmDelete, setConfirmDelete] = useState(false)
	const [busy, startTransition] = useTransition()
	const errors = state && !state.ok ? (state.fieldErrors ?? {}) : {}
	const savedId = state?.ok ? state.data?.id : undefined

	useEffect(() => {
		if (!state) return
		if (state.ok) {
			toast(state.message ?? "تم الحفظ.", "success")
			if (!product && savedId) router.replace(`/admin/products/${savedId}`)
			else router.refresh()
		}
	}, [state, savedId, product, router, toast])

	return (
		<>
			<form action={formAction} className="space-y-5">
				{state && !state.ok ? <FormAlert>{state.error}</FormAlert> : null}
				{product ? <input type="hidden" name="id" value={product.id} /> : null}

				<div className="surface space-y-4 p-5">
					<h2 className="text-sm font-semibold text-ink-soft">البيانات الأساسية</h2>
					<Field label="اسم المنتج" name="name" required error={errors.name}>
						<Input id="name" name="name" defaultValue={product?.name ?? ""} required />
					</Field>
					<div className="grid gap-4 sm:grid-cols-2">
						<Field
							label="الرابط (slug)"
							name="slug"
							error={errors.slug}
							hint="سيبه فاضي وهنولده من الاسم"
						>
							<Input id="slug" name="slug" dir="ltr" className="text-start" defaultValue={product?.slug ?? ""} />
						</Field>
						<Field label="القسم" name="categoryId" error={errors.categoryId}>
							<Select id="categoryId" name="categoryId" defaultValue={product?.category_id ?? ""}>
								<option value="">بدون قسم</option>
								{categories.map((category) => (
									<option key={category.id} value={category.id}>
										{category.name}
									</option>
								))}
							</Select>
						</Field>
					</div>
					<Field label="وصف مختصر" name="shortDescription" error={errors.shortDescription}>
						<Input
							id="shortDescription"
							name="shortDescription"
							defaultValue={product?.short_description ?? ""}
							placeholder="سطر واحد بيظهر في كارت المنتج"
						/>
					</Field>
					<Field label="الوصف الكامل" name="description" error={errors.description}>
						<Textarea id="description" name="description" rows={6} defaultValue={product?.description ?? ""} />
					</Field>
				</div>

				<div className="surface space-y-4 p-5">
					<h2 className="text-sm font-semibold text-ink-soft">السعر والمخزون</h2>
					<div className="grid gap-4 sm:grid-cols-2">
						<Field label="السعر (ج.م)" name="price" required error={errors.price}>
							<Input
								id="price"
								name="price"
								type="number"
								min={0}
								step="0.01"
								className="nums"
								defaultValue={product?.price ?? ""}
								required
							/>
						</Field>
						<Field
							label="السعر قبل الخصم"
							name="compareAtPrice"
							error={errors.compareAtPrice}
							hint="سيبه فاضي لو مفيش خصم"
						>
							<Input
								id="compareAtPrice"
								name="compareAtPrice"
								type="number"
								min={0}
								step="0.01"
								className="nums"
								defaultValue={product?.compare_at_price ?? ""}
							/>
						</Field>
						<Field label="المخزون" name="stock" required error={errors.stock}>
							<Input
								id="stock"
								name="stock"
								type="number"
								min={0}
								step="1"
								className="nums"
								defaultValue={product?.stock ?? 0}
								required
							/>
						</Field>
						<Field label="كود المنتج (SKU)" name="sku" error={errors.sku}>
							<Input id="sku" name="sku" dir="ltr" className="text-start" defaultValue={product?.sku ?? ""} />
						</Field>
					</div>
				</div>

				<div className="surface space-y-3 p-5">
					<h2 className="text-sm font-semibold text-ink-soft">الظهور في المتجر</h2>
					<label className="flex min-h-11 cursor-pointer items-center gap-3 text-sm">
						<Checkbox name="isActive" defaultChecked={product?.is_active ?? true} />
						منشور في المتجر
					</label>
					<label className="flex min-h-11 cursor-pointer items-center gap-3 text-sm">
						<Checkbox name="isFeatured" defaultChecked={product?.is_featured ?? false} />
						منتج مميز (يظهر في قسم المميز بالرئيسية)
					</label>
					<label className="flex min-h-11 cursor-pointer items-center gap-3 text-sm">
						<Checkbox name="isBestSeller" defaultChecked={product?.is_best_seller ?? false} />
						الأكثر مبيعًا
					</label>
				</div>

				<div className="flex flex-wrap gap-3">
					<Button type="submit" disabled={pending}>
						{pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
						{product ? "احفظ التعديلات" : "أضف المنتج"}
					</Button>

					{product ? (
						<>
							<Button
								type="button"
								variant="outline"
								disabled={busy}
								onClick={() =>
									startTransition(async () => {
										const result = await setProductActiveAction({
											productId: product.id,
											isActive: !product.is_active,
										})
										toast(result.ok ? (result.message ?? "تم.") : result.error, result.ok ? "success" : "error")
										if (result.ok) router.refresh()
									})
								}
							>
								{product.is_active ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
								{product.is_active ? "إخفاء من المتجر" : "نشر في المتجر"}
							</Button>
							<Button type="button" variant="ghost" onClick={() => setConfirmDelete(true)}>
								<Trash2 className="h-4 w-4" />
								حذف نهائي
							</Button>
						</>
					) : null}
				</div>
			</form>

			<ConfirmDialog
				open={confirmDelete}
				onClose={() => setConfirmDelete(false)}
				pending={busy}
				title="تحذف المنتج نهائيًا؟"
				description="الطلبات القديمة بتحتفظ باسم وسعر المنتج وقت الشراء. لو عايز تشيله من المتجر بس، استخدم الإخفاء."
				confirmLabel="احذف"
				onConfirm={() => {
					if (!product) return
					startTransition(async () => {
						const result = await deleteProductAction(product.id)
						if (!result.ok) {
							toast(result.error, "error")
							return
						}
						setConfirmDelete(false)
						toast(result.message ?? "تم الحذف.", "success")
						router.push("/admin/products")
					})
				}}
			/>
		</>
	)
}
