"use client"

import { ArrowRight, ArrowLeft, ImagePlus, Loader2, Plus, Trash2, Upload } from "lucide-react"
import { useRouter } from "next/navigation"
import { useActionState, useEffect, useState, useTransition } from "react"
import {
	addProductImageAction,
	deleteProductImageAction,
	deleteVariantAction,
	reorderProductImagesAction,
	saveVariantAction,
	uploadProductImageAction,
} from "@/app/actions/admin/catalog"
import { Button } from "@/components/ui/button"
import { Checkbox, Field, FormAlert, Input } from "@/components/ui/field"
import { Badge } from "@/components/ui/display"
import { ConfirmDialog } from "@/components/ui/modal"
import { useToast } from "@/components/ui/toast"
import { formatPrice } from "@/lib/utils/format"
import type { ProductImage, ProductVariant } from "@/types"

/** Upload + link + reorder + delete for a single product's gallery. */
export function ProductImagesManager({
	productId,
	images,
}: {
	productId: string
	images: ProductImage[]
}) {
	const router = useRouter()
	const toast = useToast()
	const [state, formAction, uploading] = useActionState(uploadProductImageAction, null)
	const [formKey, setFormKey] = useState(0)
	const [manualUrl, setManualUrl] = useState("")
	const [manualAlt, setManualAlt] = useState("")
	const [confirmDelete, setConfirmDelete] = useState<ProductImage | null>(null)
	const [busy, startTransition] = useTransition()

	useEffect(() => {
		if (state?.ok) {
			toast(state.message ?? "تم رفع الصورة.", "success")
			setFormKey((key) => key + 1)
			router.refresh()
		}
	}, [state, router, toast])

	const run = (action: () => Promise<{ ok: boolean; error?: string; message?: string }>) =>
		startTransition(async () => {
			const result = await action()
			if (!result.ok) {
				toast(result.error ?? "حصل خطأ.", "error")
				return
			}
			setConfirmDelete(null)
			toast(result.message ?? "تم.", "success")
			router.refresh()
		})

	const move = (index: number, direction: -1 | 1) => {
		const next = [...images]
		const target = index + direction
		if (target < 0 || target >= next.length) return
		const [moved] = next.splice(index, 1)
		next.splice(target, 0, moved)
		run(() => reorderProductImagesAction({ productId, orderedIds: next.map((image) => image.id) }))
	}

	return (
		<div className="surface space-y-5 p-5">
			<div className="flex items-center justify-between gap-3">
				<h2 className="text-sm font-semibold text-ink-soft">صور المنتج</h2>
				<span className="nums text-xs text-ink-muted">{images.length} صورة</span>
			</div>

			{images.length ? (
				<ul className="grid grid-cols-2 gap-3 sm:grid-cols-3">
					{images.map((image, index) => (
						<li key={image.id} className="overflow-hidden rounded-2xl border border-sand bg-ivory">
							{/* eslint-disable-next-line @next/next/no-img-element */}
							<img
								src={image.image_url}
								alt={image.alt_text ?? ""}
								className="aspect-[4/5] w-full object-cover"
								loading="lazy"
							/>
							<div className="flex items-center justify-between gap-1 p-2">
								<div className="flex gap-1">
									<button
										type="button"
										className="grid h-9 w-9 place-items-center rounded-full text-ink-soft transition-colors hover:bg-sand disabled:opacity-40"
										onClick={() => move(index, -1)}
										disabled={busy || index === 0}
										aria-label="تحريك لليمين"
									>
										<ArrowRight className="h-4 w-4" />
									</button>
									<button
										type="button"
										className="grid h-9 w-9 place-items-center rounded-full text-ink-soft transition-colors hover:bg-sand disabled:opacity-40"
										onClick={() => move(index, 1)}
										disabled={busy || index === images.length - 1}
										aria-label="تحريك لليسار"
									>
										<ArrowLeft className="h-4 w-4" />
									</button>
								</div>
								<button
									type="button"
									className="grid h-9 w-9 place-items-center rounded-full text-ink-soft transition-colors hover:bg-rose-100 hover:text-rose-700"
									onClick={() => setConfirmDelete(image)}
									aria-label="حذف الصورة"
								>
									<Trash2 className="h-4 w-4" />
								</button>
							</div>
						</li>
					))}
				</ul>
			) : (
				<p className="rounded-2xl border border-dashed border-sand-dark p-6 text-center text-sm text-ink-muted">
					مفيش صور لسة. أول صورة هي اللي بتظهر في كارت المنتج.
				</p>
			)}

			<form key={formKey} action={formAction} className="space-y-3 rounded-2xl border border-sand bg-cream p-4">
				{state && !state.ok ? <FormAlert>{state.error}</FormAlert> : null}
				<input type="hidden" name="productId" value={productId} />
				<Field label="ارفع صورة جديدة" name="file" hint="JPG أو PNG أو WebP — أقصى حجم ٥ ميجا">
					<input
						id="file"
						name="file"
						type="file"
						accept="image/jpeg,image/png,image/webp"
						className="block w-full cursor-pointer rounded-2xl border border-sand bg-ivory px-4 py-2.5 text-sm file:me-3 file:rounded-full file:border-0 file:bg-rose-100 file:px-4 file:py-2 file:text-sm file:text-rose-700"
						required
					/>
				</Field>
				<Field label="وصف الصورة (alt)" name="altText">
					<Input id="altText" name="altText" placeholder="بوكيه توليب وردي هاند ميد" />
				</Field>
				<Button type="submit" variant="outline" disabled={uploading}>
					{uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
					ارفع الصورة
				</Button>
			</form>

			<div className="space-y-3 rounded-2xl border border-sand bg-cream p-4">
				<Field label="أو اربط صورة موجودة برابط" name="imageUrl">
					<Input
						id="imageUrl"
						name="imageUrl"
						dir="ltr"
						className="text-start"
						value={manualUrl}
						onChange={(event) => setManualUrl(event.target.value)}
						placeholder="/products/tulip-pink-bouquet-1.svg"
					/>
				</Field>
				<Field label="وصف الصورة (alt)" name="manualAlt">
					<Input
						id="manualAlt"
						name="manualAlt"
						value={manualAlt}
						onChange={(event) => setManualAlt(event.target.value)}
					/>
				</Field>
				<Button
					type="button"
					variant="ghost"
					disabled={busy || manualUrl.trim().length === 0}
					onClick={() => {
						run(() =>
							addProductImageAction({
								productId,
								imageUrl: manualUrl.trim(),
								altText: manualAlt.trim() || null,
							}),
						)
						setManualUrl("")
						setManualAlt("")
					}}
				>
					<ImagePlus className="h-4 w-4" />
					اربط الصورة
				</Button>
			</div>

			<ConfirmDialog
				open={Boolean(confirmDelete)}
				onClose={() => setConfirmDelete(null)}
				pending={busy}
				title="تحذف الصورة؟"
				confirmLabel="احذف"
				onConfirm={() => {
					if (confirmDelete) run(() => deleteProductImageAction({ imageId: confirmDelete.id, productId }))
				}}
			/>
		</div>
	)
}

type OptionRow = { key: string; value: string }

/** Variants carry their own price/stock; options are a free-form key/value map. */
export function ProductVariantsManager({
	productId,
	variants,
}: {
	productId: string
	variants: ProductVariant[]
}) {
	const router = useRouter()
	const toast = useToast()
	const [state, formAction, saving] = useActionState(saveVariantAction, null)
	const [editing, setEditing] = useState<ProductVariant | null>(null)
	const [open, setOpen] = useState(false)
	const [options, setOptions] = useState<OptionRow[]>([{ key: "", value: "" }])
	const [confirmDelete, setConfirmDelete] = useState<ProductVariant | null>(null)
	const [busy, startTransition] = useTransition()
	const errors = state && !state.ok ? (state.fieldErrors ?? {}) : {}

	useEffect(() => {
		if (state?.ok) {
			toast(state.message ?? "تم الحفظ.", "success")
			setOpen(false)
			setEditing(null)
			setOptions([{ key: "", value: "" }])
			router.refresh()
		}
	}, [state, router, toast])

	const startEditing = (variant: ProductVariant | null) => {
		setEditing(variant)
		const raw = (variant?.options ?? {}) as Record<string, string>
		const rows = Object.entries(raw).map(([key, value]) => ({ key, value: String(value) }))
		setOptions(rows.length ? rows : [{ key: "", value: "" }])
		setOpen(true)
	}

	return (
		<div className="surface space-y-4 p-5">
			<div className="flex items-center justify-between gap-3">
				<h2 className="text-sm font-semibold text-ink-soft">التنويعات (مقاس / لون / تغليف)</h2>
				<Button type="button" variant="ghost" size="sm" onClick={() => startEditing(null)}>
					<Plus className="h-4 w-4" />
					تنويع جديد
				</Button>
			</div>

			{variants.length ? (
				<ul className="divide-y divide-sand">
					{variants.map((variant) => {
						const variantOptions = (variant.options ?? {}) as Record<string, string>
						return (
							<li key={variant.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
								<div>
									<p className="text-sm font-medium">
										{variant.name}{" "}
										{variant.is_active ? null : <Badge tone="muted">متوقف</Badge>}
									</p>
									<p className="nums mt-1 text-xs text-ink-muted">
										{variant.price === null || variant.price === undefined
											? "بسعر المنتج"
											: formatPrice(variant.price)}{" "}
										• مخزون {variant.stock}
										{Object.entries(variantOptions).length
											? ` • ${Object.entries(variantOptions)
													.map(([key, value]) => `${key}: ${value}`)
													.join(" / ")}`
											: ""}
									</p>
								</div>
								<div className="flex gap-2">
									<Button type="button" variant="outline" size="sm" onClick={() => startEditing(variant)}>
										تعديل
									</Button>
									<Button type="button" variant="ghost" size="sm" onClick={() => setConfirmDelete(variant)}>
										<Trash2 className="h-4 w-4" />
									</Button>
								</div>
							</li>
						)
					})}
				</ul>
			) : (
				<p className="text-sm text-ink-muted">مفيش تنويعات — المنتج هيتباع بسعر ومخزون واحد.</p>
			)}

			{open ? (
				<form action={formAction} className="space-y-4 rounded-2xl border border-sand bg-cream p-4">
					{state && !state.ok ? <FormAlert>{state.error}</FormAlert> : null}
					<input type="hidden" name="productId" value={productId} />
					{editing ? <input type="hidden" name="id" value={editing.id} /> : null}

					<div className="grid gap-4 sm:grid-cols-2">
						<Field label="اسم التنويع" name="name" required error={errors.name}>
							<Input id="variantName" name="name" defaultValue={editing?.name ?? ""} required />
						</Field>
						<Field label="كود التنويع (SKU)" name="sku" error={errors.sku}>
							<Input id="variantSku" name="sku" dir="ltr" className="text-start" defaultValue={editing?.sku ?? ""} />
						</Field>
						<Field label="السعر" name="price" error={errors.price} hint="سيبه فاضي ليستخدم سعر المنتج">
							<Input
								id="variantPrice"
								name="price"
								type="number"
								min={0}
								step="0.01"
								className="nums"
								defaultValue={editing?.price ?? ""}
							/>
						</Field>
						<Field label="المخزون" name="stock" required error={errors.stock}>
							<Input
								id="variantStock"
								name="stock"
								type="number"
								min={0}
								step="1"
								className="nums"
								defaultValue={editing?.stock ?? 0}
								required
							/>
						</Field>
					</div>

					<fieldset className="space-y-2">
						<legend className="field-label">الخصائص</legend>
						{options.map((row, index) => (
							<div key={index} className="flex gap-2">
								<Input
									name="optionKey"
									aria-label="اسم الخاصية"
									placeholder="اللون"
									value={row.key}
									onChange={(event) =>
										setOptions((rows) =>
											rows.map((item, i) => (i === index ? { ...item, key: event.target.value } : item)),
										)
									}
								/>
								<Input
									name="optionValue"
									aria-label="قيمة الخاصية"
									placeholder="وردي"
									value={row.value}
									onChange={(event) =>
										setOptions((rows) =>
											rows.map((item, i) => (i === index ? { ...item, value: event.target.value } : item)),
										)
									}
								/>
							</div>
						))}
						<Button
							type="button"
							variant="ghost"
							size="sm"
							onClick={() => setOptions((rows) => [...rows, { key: "", value: "" }])}
						>
							<Plus className="h-4 w-4" />
							خاصية تانية
						</Button>
					</fieldset>

					<label className="flex min-h-11 cursor-pointer items-center gap-3 text-sm">
						<Checkbox name="isActive" defaultChecked={editing?.is_active ?? true} />
						متاح للبيع
					</label>

					<div className="flex gap-3">
						<Button type="submit" disabled={saving}>
							{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
							احفظ التنويع
						</Button>
						<Button
							type="button"
							variant="ghost"
							onClick={() => {
								setOpen(false)
								setEditing(null)
							}}
						>
							إلغاء
						</Button>
					</div>
				</form>
			) : null}

			<ConfirmDialog
				open={Boolean(confirmDelete)}
				onClose={() => setConfirmDelete(null)}
				pending={busy}
				title="تحذف التنويع؟"
				confirmLabel="احذف"
				onConfirm={() => {
					if (!confirmDelete) return
					startTransition(async () => {
						const result = await deleteVariantAction({ variantId: confirmDelete.id, productId })
						if (!result.ok) {
							toast(result.error, "error")
							return
						}
						setConfirmDelete(null)
						toast(result.message ?? "تم الحذف.", "success")
						router.refresh()
					})
				}}
			/>
		</div>
	)
}
