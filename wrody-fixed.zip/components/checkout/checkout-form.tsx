"use client"

import { ArrowLeft, ArrowRight, Loader2, Lock, ShieldCheck } from "lucide-react"
import { useActionState, useEffect, useState } from "react"
import { placeOrderAction } from "@/app/actions/checkout"
import { OrderSummary } from "@/components/cart/order-summary"
import { Button } from "@/components/ui/button"
import { Checkbox, Field, FormAlert, Input, Select, Textarea } from "@/components/ui/field"
import { cn } from "@/lib/utils/cn"
import { formatPrice } from "@/lib/utils/format"
import type { CartView, PaymentMethod } from "@/types"

export type CheckoutZone = {
	id: string
	city: string
	fee: number
	estimated_days: string | number | null
}

export type CheckoutPaymentMethod = {
	id: PaymentMethod
	label: string
	description: string
	note?: string
}

export type CheckoutDefaults = {
	fullName?: string | null
	phone?: string | null
	email?: string | null
	city?: string | null
	area?: string | null
	street?: string | null
	building?: string | null
	floor?: string | null
	apartment?: string | null
	additionalInfo?: string | null
}

const STEPS = [
	{ id: 1, label: "بياناتك" },
	{ id: 2, label: "التوصيل" },
	{ id: 3, label: "الدفع والمراجعة" },
] as const

/** RFC-4122 v4 id used as the order idempotency key (survives double submits). */
function makeUuid(): string {
	if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID()
	return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (char) => {
		const random = (Math.random() * 16) | 0
		const value = char === "x" ? random : (random & 0x3) | 0x8
		return value.toString(16)
	})
}

/**
 * Multi-step UI over a single native form: every field stays mounted (hidden
 * steps are display:none) so one submit carries the whole payload and the
 * server re-validates it with Zod before place_order() re-prices everything.
 */
export function CheckoutForm({
	cart,
	zones,
	defaultFee,
	freeThreshold,
	paymentMethods,
	defaults,
	isSignedIn,
}: {
	cart: CartView
	zones: CheckoutZone[]
	defaultFee: number
	freeThreshold: number
	paymentMethods: CheckoutPaymentMethod[]
	defaults?: CheckoutDefaults | null
	isSignedIn: boolean
}) {
	const [state, formAction, pending] = useActionState(placeOrderAction, null)
	const [step, setStep] = useState<1 | 2 | 3>(1)
	const [idempotencyKey, setIdempotencyKey] = useState("")

	useEffect(() => {
		setIdempotencyKey(makeUuid())
	}, [])
	const [city, setCity] = useState(defaults?.city ?? zones[0]?.city ?? "")
	const [otherCity, setOtherCity] = useState(
		Boolean(defaults?.city) && !zones.some((zone) => zone.city === defaults?.city),
	)
	const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(paymentMethods[0]?.id ?? "cod")

	const errors = state && !state.ok ? (state.fieldErrors ?? {}) : {}
	const blocked = cart.lines.some((line) => !line.isAvailable)

	const zone = zones.find((item) => item.city === city)
	const payable = cart.totals.subtotal - cart.totals.discount
	const estimatedFee = freeThreshold > 0 && payable >= freeThreshold ? 0 : (zone?.fee ?? defaultFee)
	const estimatedTotal = Math.max(payable + estimatedFee, 0)

	return (
		<form action={formAction} className="grid gap-6 lg:grid-cols-[1.5fr_1fr] lg:items-start">
			<input type="hidden" name="idempotencyKey" value={idempotencyKey} />
			<input type="hidden" name="paymentMethod" value={paymentMethod} />

			<div className="space-y-5">
				<ol className="flex items-center gap-2" aria-label="خطوات إتمام الطلب">
					{STEPS.map((item) => (
						<li key={item.id} className="flex flex-1 items-center gap-2">
							<button
								type="button"
								onClick={() => setStep(item.id)}
								aria-current={step === item.id ? "step" : undefined}
								className={cn(
									"flex min-h-11 w-full items-center justify-center gap-2 rounded-full border px-3 text-xs font-medium transition-colors sm:text-sm",
									step === item.id
										? "border-rose-400 bg-rose-50 text-rose-700"
										: step > item.id
											? "border-sage-300 bg-sage-50 text-sage-700"
											: "border-sand-dark bg-ivory text-ink-muted",
								)}
							>
								<span className="nums">{item.id}</span>
								{item.label}
							</button>
						</li>
					))}
				</ol>

				{state && !state.ok ? <FormAlert>{state.error}</FormAlert> : null}

				<section className={cn("surface space-y-4 p-5", step !== 1 && "hidden")} aria-label="بيانات التواصل">
					<h2 className="text-base font-semibold">بيانات التواصل</h2>
					<Field label="الاسم بالكامل" name="fullName" required error={errors.fullName}>
						<Input
							id="fullName"
							name="fullName"
							defaultValue={defaults?.fullName ?? ""}
							autoComplete="name"
							required
						/>
					</Field>
					<Field label="رقم الموبايل" name="phone" required error={errors.phone} hint="هنكلمك عليه لتأكيد الطلب">
						<Input
							id="phone"
							name="phone"
							type="tel"
							inputMode="tel"
							dir="ltr"
							placeholder="01xxxxxxxxx"
							defaultValue={defaults?.phone ?? ""}
							autoComplete="tel"
							className="nums text-start"
							required
						/>
					</Field>
					<Field label="البريد الإلكتروني (اختياري)" name="email" error={errors.email} hint="عشان نبعتلك تأكيد الطلب">
						<Input
							id="email"
							name="email"
							type="email"
							dir="ltr"
							defaultValue={defaults?.email ?? ""}
							autoComplete="email"
							className="text-start"
						/>
					</Field>
					<Button type="button" size="lg" className="w-full" onClick={() => setStep(2)}>
						كمل للتوصيل
						<ArrowLeft className="h-4 w-4" />
					</Button>
				</section>

				<section className={cn("surface space-y-4 p-5", step !== 2 && "hidden")} aria-label="عنوان التوصيل">
					<h2 className="text-base font-semibold">عنوان التوصيل</h2>

					<div className="grid gap-4 sm:grid-cols-2">
						<Field label="المحافظة" name="city" required error={errors.city}>
							{otherCity ? (
								<Input
									id="city"
									name="city"
									value={city}
									onChange={(event) => setCity(event.target.value)}
									placeholder="اكتب اسم المحافظة"
									required
								/>
							) : (
								<Select
									id="city"
									name="city"
									value={city}
									onChange={(event) => {
										if (event.target.value === "__other__") {
											setOtherCity(true)
											setCity("")
											return
										}
										setCity(event.target.value)
									}}
									required
								>
									{zones.map((item) => (
										<option key={item.id} value={item.city}>
											{item.city}
										</option>
									))}
									<option value="__other__">محافظة تانية…</option>
								</Select>
							)}
						</Field>
						<Field label="المنطقة / الحي" name="area" required error={errors.area}>
							<Input id="area" name="area" defaultValue={defaults?.area ?? ""} required />
						</Field>
					</div>

					<Field label="الشارع" name="street" required error={errors.street}>
						<Input
							id="street"
							name="street"
							defaultValue={defaults?.street ?? ""}
							autoComplete="street-address"
							required
						/>
					</Field>

					<div className="grid gap-4 sm:grid-cols-3">
						<Field label="رقم العمارة" name="building" error={errors.building}>
							<Input id="building" name="building" defaultValue={defaults?.building ?? ""} className="nums" />
						</Field>
						<Field label="الدور" name="floor" error={errors.floor}>
							<Input id="floor" name="floor" defaultValue={defaults?.floor ?? ""} className="nums" />
						</Field>
						<Field label="الشقة" name="apartment" error={errors.apartment}>
							<Input id="apartment" name="apartment" defaultValue={defaults?.apartment ?? ""} className="nums" />
						</Field>
					</div>

					<Field label="علامة مميزة (اختياري)" name="additionalInfo" error={errors.additionalInfo}>
						<Input
							id="additionalInfo"
							name="additionalInfo"
							defaultValue={defaults?.additionalInfo ?? ""}
							placeholder="جنب أي مكان معروف؟"
						/>
					</Field>

					<Field label="ملاحظات للطلب (اختياري)" name="notes" error={errors.notes} hint="لو الطلب هدية أو ليه ميعاد معين، اكتبه هنا">
						<Textarea id="notes" name="notes" maxLength={500} className="min-h-24" />
					</Field>

					{isSignedIn ? (
						<label className="flex min-h-11 cursor-pointer items-center gap-3 text-sm text-ink-soft">
							<Checkbox name="saveAddress" defaultChecked />
							احفظ العنوان ده في حسابي
						</label>
					) : null}

					<div className="flex gap-3">
						<Button type="button" variant="outline" size="lg" onClick={() => setStep(1)}>
							<ArrowRight className="h-4 w-4" />
							رجوع
						</Button>
						<Button type="button" size="lg" className="flex-1" onClick={() => setStep(3)}>
							كمل للدفع
							<ArrowLeft className="h-4 w-4" />
						</Button>
					</div>
				</section>

				<section className={cn("surface space-y-4 p-5", step !== 3 && "hidden")} aria-label="طريقة الدفع">
					<h2 className="text-base font-semibold">طريقة الدفع</h2>
					<div className="space-y-3">
						{paymentMethods.map((method) => (
							<label
								key={method.id}
								className={cn(
									"flex cursor-pointer items-start gap-3 rounded-3xl border p-4 transition-colors",
									paymentMethod === method.id
										? "border-rose-400 bg-rose-50"
										: "border-sand-dark bg-ivory hover:border-rose-200",
								)}
							>
								<input
									type="radio"
									name="paymentMethodChoice"
									value={method.id}
									checked={paymentMethod === method.id}
									onChange={() => setPaymentMethod(method.id)}
									className="mt-1 h-5 w-5 accent-rose-500"
								/>
								<span>
									<span className="block text-sm font-semibold">{method.label}</span>
									<span className="mt-0.5 block text-xs leading-relaxed text-ink-soft">{method.description}</span>
									{method.note ? (
										<span className="mt-1 block text-xs text-ink-muted">{method.note}</span>
									) : null}
								</span>
							</label>
						))}
					</div>

					<p className="flex items-start gap-2 rounded-2xl bg-cream px-4 py-3 text-xs leading-relaxed text-ink-soft">
						<ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-sage-700" aria-hidden="true" />
						الأسعار والخصومات والمخزون بيتأكدوا على السيرفر لحظة تأكيد الطلب، فمفيش أي فرق ممكن يحصل بعد الدفع.
					</p>

					<div className="flex gap-3">
						<Button type="button" variant="outline" size="lg" onClick={() => setStep(2)}>
							<ArrowRight className="h-4 w-4" />
							رجوع
						</Button>
						<Button type="submit" size="lg" className="flex-1" disabled={pending || blocked || !cart.lines.length}>
							{pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Lock className="h-4 w-4" />}
							تأكيد الطلب
						</Button>
					</div>
					{blocked ? (
						<p role="alert" className="field-error">
							فيه منتج خلص من المخزن. ارجع للسلة وامسحه عشان تكمل.
						</p>
					) : null}
				</section>
			</div>

			<aside className="surface space-y-4 p-5 lg:sticky lg:top-[calc(var(--header-height)+1.5rem)]" aria-label="ملخص الطلب">
				<h2 className="text-base font-semibold">ملخص الطلب</h2>
				<ul className="space-y-3 text-sm">
					{cart.lines.map((line) => (
						<li key={line.id} className="flex items-start justify-between gap-3">
							<span className="min-w-0">
								<span className="block truncate">{line.name}</span>
								<span className="nums text-xs text-ink-muted">
									{line.quantity} × {formatPrice(line.unitPrice)}
								</span>
							</span>
							<span className="nums shrink-0 font-medium">{formatPrice(line.lineTotal)}</span>
						</li>
					))}
				</ul>
				<div className="border-t border-sand pt-4">
					<OrderSummary
						totals={{ ...cart.totals, deliveryFee: estimatedFee, total: estimatedTotal }}
						deliveryNote={
							zone?.estimated_days
								? `التوصيل لـ${zone.city} خلال ${zone.estimated_days} يوم تقريبًا.`
								: "مصاريف التوصيل بتتأكد نهائيًا على السيرفر وقت تأكيد الطلب."
						}
					/>
				</div>
			</aside>
		</form>
	)
}
