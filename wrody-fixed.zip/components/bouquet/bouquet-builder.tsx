"use client"

import { ArrowLeft, ArrowRight, Check, Loader2, ShoppingBag, Sparkles } from "lucide-react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { useEffect, useMemo, useState, useTransition } from "react"
import { addBouquetToCartAction, priceBouquetAction } from "@/app/actions/bouquet"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/field"
import { QuantitySelector } from "@/components/ui/quantity-selector"
import { useToast } from "@/components/ui/toast"
import { cn } from "@/lib/utils/cn"
import { formatPrice } from "@/lib/utils/format"
import type { BouquetCatalog } from "@/lib/services/bouquet"
import type { BouquetPriceBreakdown } from "@/types"

const STEPS = [
	{ id: 1, label: "اختار الورد" },
	{ id: 2, label: "العدد" },
	{ id: 3, label: "الحجم" },
	{ id: 4, label: "التغليف" },
	{ id: 5, label: "الكارت" },
	{ id: 6, label: "الرسالة" },
] as const

type StepId = (typeof STEPS)[number]["id"]

/**
 * The builder keeps a local estimate for instant feedback, but the number that
 * is displayed as the price — and the one stored on the bouquet — always comes
 * back from price_custom_bouquet() on the server.
 */
export function BouquetBuilder({ catalog }: { catalog: BouquetCatalog }) {
	const router = useRouter()
	const toast = useToast()
	const [step, setStep] = useState<StepId>(1)
	const [quantities, setQuantities] = useState<Record<string, number>>({})
	const [sizeSlug, setSizeSlug] = useState(catalog.sizes[0]?.slug ?? "")
	const [wrappingSlug, setWrappingSlug] = useState(catalog.wrappings[0]?.slug ?? "")
	const [cardSlug, setCardSlug] = useState(catalog.cards[0]?.slug ?? "")
	const [message, setMessage] = useState("")
	const [breakdown, setBreakdown] = useState<BouquetPriceBreakdown | null>(null)
	const [priceError, setPriceError] = useState<string | null>(null)
	const [pricing, setPricing] = useState(false)
	const [adding, startAdding] = useTransition()

	const items = useMemo(
		() =>
			Object.entries(quantities)
				.filter(([, quantity]) => quantity > 0)
				.map(([slug, quantity]) => ({ slug, quantity })),
		[quantities],
	)
	const flowerCount = items.reduce((total, item) => total + item.quantity, 0)
	const size = catalog.sizes.find((option) => option.slug === sizeSlug) ?? null
	const payload = useMemo(
		() => ({ sizeSlug, wrappingSlug, cardSlug: cardSlug || null, message: message || null, items }),
		[sizeSlug, wrappingSlug, cardSlug, message, items],
	)

	// Debounced server pricing: never trust a total computed in the browser.
	useEffect(() => {
		if (!items.length || !sizeSlug || !wrappingSlug) {
			setBreakdown(null)
			setPriceError(null)
			return
		}
		let cancelled = false
		setPricing(true)
		const timer = window.setTimeout(async () => {
			const result = await priceBouquetAction(payload)
			if (cancelled) return
			setPricing(false)
			if (result.ok && result.data) {
				setBreakdown(result.data)
				setPriceError(null)
			} else if (!result.ok) {
				setBreakdown(null)
				setPriceError(result.error)
			}
		}, 350)
		return () => {
			cancelled = true
			window.clearTimeout(timer)
			window.setTimeout(() => setPricing(false), 0)
		}
	}, [payload, items.length, sizeSlug, wrappingSlug])

	const toggleFlower = (slug: string) =>
		setQuantities((current) => {
			const next = { ...current }
			if (next[slug]) delete next[slug]
			else next[slug] = 3
			return next
		})

	const canContinue = step === 1 ? items.length > 0 : true
	const withinRange =
		!size || (flowerCount >= (size.min_flowers ?? 1) && flowerCount <= (size.max_flowers ?? 99))

	const onAddToCart = () =>
		startAdding(async () => {
			const result = await addBouquetToCartAction(payload)
			if (!result.ok) {
				toast(result.error, "error")
				return
			}
			toast(result.message ?? "البوكيه اتضاف للسلة 🤍", "success")
			router.push("/cart")
		})

	return (
		<div className="grid gap-6 lg:grid-cols-[1.55fr_1fr] lg:items-start">
			<div className="space-y-5">
				<ol className="hide-scrollbar flex gap-2 overflow-x-auto pb-1" aria-label="خطوات تصميم البوكيه">
					{STEPS.map((item) => (
						<li key={item.id}>
							<button
								type="button"
								onClick={() => setStep(item.id)}
								aria-current={step === item.id ? "step" : undefined}
								className={cn(
									"flex min-h-10 items-center gap-1.5 whitespace-nowrap rounded-full border px-3.5 text-xs transition-colors",
									step === item.id
										? "border-rose-400 bg-rose-50 font-semibold text-rose-700"
										: step > item.id
											? "border-sage-300 bg-sage-50 text-sage-700"
											: "border-sand-dark bg-ivory text-ink-muted",
								)}
							>
								<span className="nums">{item.id}</span>
								{item.label}
							</button>
						</li>
					))}
				</ol>

				<section className="surface p-5">
					{step === 1 ? (
						<div>
							<h2 className="text-base font-semibold">اختار أنواع الورد</h2>
							<p className="mt-1 text-sm text-ink-soft">تقدر تخلط لحد ٨ أنواع في بوكيه واحد.</p>
							<div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
								{catalog.flowers.map((flower) => {
									const selected = Boolean(quantities[flower.slug])
									return (
										<button
											key={flower.id}
											type="button"
											onClick={() => toggleFlower(flower.slug)}
											aria-pressed={selected}
											className={cn(
												"group relative overflow-hidden rounded-3xl border p-3 text-start transition-all duration-200 ease-soft",
												selected
													? "border-rose-400 bg-rose-50 shadow-soft"
													: "border-sand-dark bg-ivory hover:border-rose-200",
											)}
										>
											<span className="relative block h-24 w-full overflow-hidden rounded-2xl bg-cream">
												<Image
													src={flower.image_url ?? `/flowers/${flower.slug}.svg`}
													alt={flower.name}
													fill
													sizes="(max-width: 640px) 45vw, 200px"
													className="object-contain p-2 transition-transform duration-300 ease-soft group-hover:scale-105"
												/>
											</span>
											<span className="mt-2 flex items-center justify-between gap-2">
												<span className="text-sm font-medium">{flower.name}</span>
												{selected ? <Check className="h-4 w-4 text-rose-600" /> : null}
											</span>
											<span className="nums mt-0.5 block text-xs text-ink-muted">
												{formatPrice(flower.unit_price)} للوردة
											</span>
										</button>
									)
								})}
							</div>
						</div>
					) : null}

					{step === 2 ? (
						<div>
							<h2 className="text-base font-semibold">عدد كل نوع</h2>
							<p className="mt-1 text-sm text-ink-soft">
								{size
									? `حجم ${size.name} بيستحمل من ${size.min_flowers ?? 1} لـ${size.max_flowers ?? 99} وردة.`
									: "اختار العدد المناسب لكل نوع."}
							</p>
							{items.length ? (
								<ul className="mt-4 divide-y divide-sand">
									{items.map((item) => {
										const flower = catalog.flowers.find((entry) => entry.slug === item.slug)
										if (!flower) return null
										return (
											<li key={item.slug} className="flex items-center justify-between gap-3 py-3">
												<div>
													<p className="text-sm font-medium">{flower.name}</p>
													<p className="nums text-xs text-ink-muted">
														{formatPrice(flower.unit_price * item.quantity)}
													</p>
												</div>
												<QuantitySelector
													value={item.quantity}
													max={50}
													label={`عدد ${flower.name}`}
													onChange={(next) =>
														setQuantities((current) => ({ ...current, [item.slug]: next }))
													}
												/>
											</li>
										)
									})}
								</ul>
							) : (
								<p className="mt-4 text-sm text-rose-700">ارجع للخطوة الأولى واختار نوع ورد الأول.</p>
							)}
						</div>
					) : null}

					{step === 3 || step === 4 || step === 5 ? (
						<OptionPicker
							title={step === 3 ? "حجم البوكيه" : step === 4 ? "لون التغليف" : "كارت المعايدة"}
							description={
								step === 3
									? "الحجم بيحدد عدد الورد المسموح والسعر الأساسي."
									: step === 4
										? "كل بوكيه بنلفه بإيدينا قبل ما يوصلك."
										: "اختار كارت مكتوب بخط اليد، أو من غير كارت."
							}
							options={step === 3 ? catalog.sizes : step === 4 ? catalog.wrappings : catalog.cards}
							value={step === 3 ? sizeSlug : step === 4 ? wrappingSlug : cardSlug}
							onChange={step === 3 ? setSizeSlug : step === 4 ? setWrappingSlug : setCardSlug}
						/>
					) : null}

					{step === 6 ? (
						<div>
							<h2 className="text-base font-semibold">رسالتك الشخصية</h2>
							<p className="mt-1 text-sm text-ink-soft">هنكتبها بخط اليد على الكارت (٣٠٠ حرف كحد أقصى).</p>
							<label htmlFor="bouquet-message" className="sr-only">
								رسالة الكارت
							</label>
							<Textarea
								id="bouquet-message"
								value={message}
								onChange={(event) => setMessage(event.target.value.slice(0, 300))}
								maxLength={300}
								placeholder="كل سنة وإنتي طيبة يا أمي 🤍"
								className="mt-4"
							/>
							<p className="nums mt-1.5 text-xs text-ink-muted">{message.length}/300</p>
						</div>
					) : null}

					<div className="mt-6 flex gap-3">
						<Button
							type="button"
							variant="outline"
							onClick={() => setStep((current) => (current > 1 ? ((current - 1) as StepId) : current))}
							disabled={step === 1}
						>
							<ArrowRight className="h-4 w-4" />
							رجوع
						</Button>
						{step < 6 ? (
							<Button
								type="button"
								className="flex-1"
								disabled={!canContinue}
								onClick={() => setStep((current) => ((current + 1) as StepId))}
							>
								الخطوة اللي بعدها
								<ArrowLeft className="h-4 w-4" />
							</Button>
						) : (
							<Button
								type="button"
								className="flex-1"
								onClick={onAddToCart}
								disabled={adding || !breakdown || !withinRange}
							>
								{adding ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShoppingBag className="h-4 w-4" />}
								ضيف البوكيه للسلة
							</Button>
						)}
					</div>
				</section>
			</div>

			<aside
				className="surface space-y-4 p-5 lg:sticky lg:top-[calc(var(--header-height)+1.5rem)]"
				aria-label="ملخص البوكيه"
				aria-live="polite"
			>
				<div className="flex items-center gap-2">
					<Sparkles className="h-4 w-4 text-rose-500" aria-hidden="true" />
					<h2 className="text-base font-semibold">بوكيهك لحد دلوقتي</h2>
				</div>

				{breakdown ? (
					<ul className="space-y-2 text-sm">
						{breakdown.flowers.map((flower) => (
							<li key={flower.slug} className="flex items-center justify-between gap-3">
								<span className="text-ink-soft">
									{flower.name} × <span className="nums">{flower.quantity}</span>
								</span>
								<span className="nums">{formatPrice(flower.total)}</span>
							</li>
						))}
						<li className="flex items-center justify-between gap-3 border-t border-sand pt-2">
							<span className="text-ink-soft">حجم {breakdown.size_name}</span>
							<span className="nums">{formatPrice(breakdown.base_price)}</span>
						</li>
						<li className="flex items-center justify-between gap-3">
							<span className="text-ink-soft">تغليف {breakdown.wrapping_name}</span>
							<span className="nums">{formatPrice(breakdown.wrapping_price)}</span>
						</li>
						{breakdown.card_name ? (
							<li className="flex items-center justify-between gap-3">
								<span className="text-ink-soft">{breakdown.card_name}</span>
								<span className="nums">{formatPrice(breakdown.card_price)}</span>
							</li>
						) : null}
					</ul>
				) : (
					<p className="text-sm text-ink-soft">اختار الورد وهنحسبلك السعر فورًا.</p>
				)}

				{priceError ? (
					<p role="alert" className="field-error">
						{priceError}
					</p>
				) : null}

				<div className="flex items-end justify-between border-t border-sand pt-4">
					<div>
						<p className="text-xs text-ink-muted">الإجمالي (محسوب على السيرفر)</p>
						<p className="nums font-display text-2xl font-bold">
							{breakdown ? formatPrice(breakdown.total) : "—"}
						</p>
					</div>
					{pricing ? <Loader2 className="mb-1 h-4 w-4 animate-spin text-ink-muted" /> : null}
				</div>

				<p className="nums text-xs text-ink-muted">عدد الورد: {flowerCount}</p>
				{!withinRange && size ? (
					<p role="alert" className="field-error">
						حجم {size.name} محتاج من {size.min_flowers ?? 1} لـ{size.max_flowers ?? 99} وردة.
					</p>
				) : null}
			</aside>
		</div>
	)
}

function OptionPicker({
	title,
	description,
	options,
	value,
	onChange,
}: {
	title: string
	description: string
	options: BouquetCatalog["sizes"]
	value: string
	onChange: (slug: string) => void
}) {
	return (
		<div>
			<h2 className="text-base font-semibold">{title}</h2>
			<p className="mt-1 text-sm text-ink-soft">{description}</p>
			<div className="mt-4 grid gap-3 sm:grid-cols-2">
				{options.map((option) => (
					<button
						key={option.id}
						type="button"
						onClick={() => onChange(option.slug)}
						aria-pressed={value === option.slug}
						className={cn(
							"rounded-3xl border p-4 text-start transition-colors",
							value === option.slug
								? "border-rose-400 bg-rose-50"
								: "border-sand-dark bg-ivory hover:border-rose-200",
						)}
					>
						<span className="flex items-center justify-between gap-2">
							<span className="text-sm font-semibold">{option.name}</span>
							<span className="nums text-sm">
								{option.price > 0 ? `+ ${formatPrice(option.price)}` : "مجانًا"}
							</span>
						</span>
						{option.description ? (
							<span className="mt-1 block text-xs leading-relaxed text-ink-soft">{option.description}</span>
						) : null}
					</button>
				))}
			</div>
		</div>
	)
}
