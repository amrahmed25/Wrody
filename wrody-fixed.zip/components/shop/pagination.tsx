import { ChevronLeft, ChevronRight } from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils/cn"

function pageWindow(page: number, totalPages: number): number[] {
	const pages = new Set<number>([1, totalPages, page, page - 1, page + 1])
	return [...pages].filter((value) => value >= 1 && value <= totalPages).sort((a, b) => a - b)
}

/** Server component: real links, so pagination works without JavaScript and is crawlable. */
export function Pagination({
	page,
	totalPages,
	buildHref,
}: {
	page: number
	totalPages: number
	buildHref: (page: number) => string
}) {
	if (totalPages <= 1) return null
	const pages = pageWindow(page, totalPages)

	return (
		<nav aria-label="صفحات المنتجات" className="mt-10 flex items-center justify-center gap-1.5">
			{page > 1 ? (
				<Link
					href={buildHref(page - 1)}
					rel="prev"
					className="flex h-11 w-11 items-center justify-center rounded-full border border-sand-dark bg-ivory transition-colors hover:border-rose-300"
					aria-label="الصفحة السابقة"
				>
					<ChevronRight className="h-4 w-4" />
				</Link>
			) : null}

			{pages.map((value, index) => (
				<span key={value} className="flex items-center gap-1.5">
					{index > 0 && value - pages[index - 1] > 1 ? (
						<span className="px-1 text-ink-muted" aria-hidden="true">
							…
						</span>
					) : null}
					<Link
						href={buildHref(value)}
						aria-current={value === page ? "page" : undefined}
						className={cn(
							"nums flex h-11 min-w-11 items-center justify-center rounded-full border px-3 text-sm transition-colors",
							value === page
								? "border-rose-400 bg-rose-50 font-semibold text-rose-700"
								: "border-sand-dark bg-ivory text-ink hover:border-rose-300",
						)}
					>
						{value}
					</Link>
				</span>
			))}

			{page < totalPages ? (
				<Link
					href={buildHref(page + 1)}
					rel="next"
					className="flex h-11 w-11 items-center justify-center rounded-full border border-sand-dark bg-ivory transition-colors hover:border-rose-300"
					aria-label="الصفحة التالية"
				>
					<ChevronLeft className="h-4 w-4" />
				</Link>
			) : null}
		</nav>
	)
}
