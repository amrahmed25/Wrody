"use client"

import { SlidersHorizontal, X } from "lucide-react"
import { usePathname, useRouter, useSearchParams } from "next/navigation"
import { useState, useTransition } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/field"
import { Modal } from "@/components/ui/modal"
import { cn } from "@/lib/utils/cn"
import type { Category } from "@/types"

export const SORT_OPTIONS = [
	{ value: "newest", label: "الأحدث" },
	{ value: "price_asc", label: "السعر: من الأقل" },
	{ value: "price_desc", label: "السعر: من الأعلى" },
	{ value: "best_selling", label: "الأكثر مبيعًا" },
	{ value: "featured", label: "مختارات ورودي" },
] as const

/**
 * All filtering lives in the URL, so every filtered view is shareable and the
 * server component re-queries with fresh params. Client state is only the
 * mobile sheet toggle and the two uncommitted price inputs.
 */
export function ShopFilters({ categories }: { categories: Category[] }) {
	const router = useRouter()
	const pathname = usePathname()
	const searchParams = useSearchParams()
	const [pending, startTransition] = useTransition()
	const [sheetOpen, setSheetOpen] = useState(false)

	const current = {
		category: searchParams.get("category") ?? "",
		minPrice: searchParams.get("minPrice") ?? "",
		maxPrice: searchParams.get("maxPrice") ?? "",
		sort: searchParams.get("sort") ?? "newest",
		inStock: searchParams.get("inStock") === "1",
		featured: searchParams.get("featured") === "1",
		bestSeller: searchParams.get("bestSeller") === "1",
		q: searchParams.get("q") ?? "",
	}

	const activeCount = [
		current.category,
		current.minPrice,
		current.maxPrice,
		current.inStock ? "1" : "",
		current.featured ? "1" : "",
		current.bestSeller ? "1" : "",
	].filter(Boolean).length

	const push = (mutate: (params: URLSearchParams) => void) => {
		const params = new URLSearchParams(searchParams.toString())
		mutate(params)
		params.delete("page")
		const query = params.toString()
		startTransition(() => router.push(query ? `${pathname}?${query}` : pathname, { scroll: false }))
	}

	const setParam = (key: string, value?: string | null) =>
		push((params) => (value ? params.set(key, value) : params.delete(key)))

	const toggleParam = (key: string, on: boolean) => setParam(key, on ? "1" : null)

	const clearAll = () =>
		push((params) => {
			for (const key of ["category", "minPrice", "maxPrice", "inStock", "featured", "bestSeller"]) {
				params.delete(key)
			}
		})

	const panel = (
		<div className={cn("space-y-7", pending && "opacity-60")}>
			<div>
				<h3 className="field-label mb-3">الأقسام</h3>
				<div className="flex flex-wrap gap-2">
					<button
						type="button"
						onClick={() => setParam("category", null)}
						aria-pressed={!current.category}
						className={cn("chip", !current.category && "chip-active")}
					>
						الكل
					</button>
					{categories.map((category) => (
						<button
							key={category.id}
							type="button"
							onClick={() => setParam("category", category.slug)}
							aria-pressed={current.category === category.slug}
							className={cn("chip", current.category === category.slug && "chip-active")}
						>
							{category.name}
						</button>
					))}
				</div>
			</div>

			<form
				onSubmit={(event) => {
					event.preventDefault()
					const data = new FormData(event.currentTarget)
					const min = String(data.get("minPrice") ?? "").trim()
					const max = String(data.get("maxPrice") ?? "").trim()
					push((params) => {
						if (min) params.set("minPrice", min)
						else params.delete("minPrice")
						if (max) params.set("maxPrice", max)
						else params.delete("maxPrice")
					})
				}}
			>
				<h3 className="field-label mb-3">السعر (ج.م)</h3>
				<div className="flex items-center gap-2">
					<label htmlFor="minPrice" className="sr-only">
						أقل سعر
					</label>
					<Input
						id="minPrice"
						name="minPrice"
						type="number"
						min={0}
						inputMode="numeric"
						defaultValue={current.minPrice}
						placeholder="من"
						className="nums h-11"
					/>
					<span aria-hidden="true" className="text-ink-muted">
						—
					</span>
					<label htmlFor="maxPrice" className="sr-only">
						أعلى سعر
					</label>
					<Input
						id="maxPrice"
						name="maxPrice"
						type="number"
						min={0}
						inputMode="numeric"
						defaultValue={current.maxPrice}
						placeholder="لغاية"
						className="nums h-11"
					/>
				</div>
				<Button type="submit" variant="outline" size="sm" className="mt-3 w-full">
					تطبيق السعر
				</Button>
			</form>

			<div>
				<h3 className="field-label mb-3">تصفية سريعة</h3>
				<div className="space-y-2.5">
					{[
						{ key: "inStock", label: "المتوفر بس", checked: current.inStock },
						{ key: "bestSeller", label: "الأكثر مبيعًا", checked: current.bestSeller },
						{ key: "featured", label: "مختارات ورودي", checked: current.featured },
					].map((filter) => (
						<label
							key={filter.key}
							className="flex min-h-11 cursor-pointer items-center gap-3 text-sm text-ink-soft"
						>
							<input
								type="checkbox"
								checked={filter.checked}
								onChange={(event) => toggleParam(filter.key, event.target.checked)}
								className="h-5 w-5 rounded-md accent-rose-500"
							/>
							{filter.label}
						</label>
					))}
				</div>
			</div>

			{activeCount > 0 ? (
				<Button type="button" variant="ghost" size="sm" onClick={clearAll} className="w-full">
					<X className="h-4 w-4" />
					مسح الفلاتر
				</Button>
			) : null}
		</div>
	)

	return (
		<>
			<div className="flex items-center gap-2 lg:hidden">
				<Button type="button" variant="outline" onClick={() => setSheetOpen(true)} className="flex-1">
					<SlidersHorizontal className="h-4 w-4" />
					الفلاتر
					{activeCount ? <span className="nums text-rose-600">({activeCount})</span> : null}
				</Button>
				<label htmlFor="sort-mobile" className="sr-only">
					الترتيب
				</label>
				<select
					id="sort-mobile"
					value={current.sort}
					onChange={(event) => setParam("sort", event.target.value)}
					className="field-input h-11 w-auto flex-1 appearance-none bg-ivory"
				>
					{SORT_OPTIONS.map((option) => (
						<option key={option.value} value={option.value}>
							{option.label}
						</option>
					))}
				</select>
			</div>

			<div className="hidden lg:block">
				<div className="mb-6">
					<label htmlFor="sort-desktop" className="field-label mb-3 block">
						الترتيب
					</label>
					<select
						id="sort-desktop"
						value={current.sort}
						onChange={(event) => setParam("sort", event.target.value)}
						className="field-input appearance-none bg-ivory"
					>
						{SORT_OPTIONS.map((option) => (
							<option key={option.value} value={option.value}>
								{option.label}
							</option>
						))}
					</select>
				</div>
				{panel}
			</div>

			<Modal open={sheetOpen} onClose={() => setSheetOpen(false)} title="الفلاتر">
				{panel}
				<Button type="button" onClick={() => setSheetOpen(false)} className="mt-6 w-full" size="lg">
					شوف النتايج
				</Button>
			</Modal>
		</>
	)
}
