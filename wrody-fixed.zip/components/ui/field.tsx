import type { ComponentProps, ReactNode } from "react"
import { cn } from "@/lib/utils/cn"

export function Label({ className, children, ...props }: ComponentProps<"label">) {
	return (
		<label className={cn("field-label", className)} {...props}>
			{children}
		</label>
	)
}

export function Input({ className, ...props }: ComponentProps<"input">) {
	return <input className={cn("field-input", className)} {...props} />
}

export function Textarea({ className, ...props }: ComponentProps<"textarea">) {
	return <textarea className={cn("field-input min-h-28 resize-y", className)} {...props} />
}

export function Select({ className, children, ...props }: ComponentProps<"select">) {
	return (
		<select className={cn("field-input appearance-none bg-ivory pe-10", className)} {...props}>
			{children}
		</select>
	)
}

export function Checkbox({ className, ...props }: ComponentProps<"input">) {
	return (
		<input
			type="checkbox"
			className={cn(
				"h-5 w-5 shrink-0 cursor-pointer rounded-md border-sand-dark text-rose-500 accent-rose-500",
				className,
			)}
			{...props}
		/>
	)
}

/** Label + control + error, wired with aria-describedby for screen readers. */
export function Field({
	label,
	name,
	error,
	hint,
	required,
	className,
	children,
}: {
	label: string
	name: string
	error?: string | string[] | null
	hint?: string
	required?: boolean
	className?: string
	children: ReactNode
}) {
	const message = Array.isArray(error) ? error[0] : error
	return (
		<div className={cn("w-full", className)}>
			<Label htmlFor={name}>
				{label}
				{required ? <span className="ms-1 text-rose-500">*</span> : null}
			</Label>
			{children}
			{hint && !message ? <p className="mt-1.5 text-xs text-ink-muted">{hint}</p> : null}
			{message ? (
				<p id={`${name}-error`} role="alert" className="field-error">
					{message}
				</p>
			) : null}
		</div>
	)
}

export function FormAlert({ tone = "error", children }: { tone?: "error" | "success"; children: ReactNode }) {
	if (!children) return null
	return (
		<p
			role={tone === "error" ? "alert" : "status"}
			className={cn(
				"rounded-2xl border px-4 py-3 text-sm",
				tone === "error"
					? "border-rose-200 bg-rose-50 text-rose-700"
					: "border-sage-300 bg-sage-50 text-sage-700",
			)}
		>
			{children}
		</p>
	)
}
