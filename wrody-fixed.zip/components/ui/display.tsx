import { Star } from "lucide-react"
import type { ReactNode } from "react"
import { cn } from "@/lib/utils/cn"
import { discountPercent, formatPrice } from "@/lib/utils/format"

export function Price({
	value,
	compareAt,
	size = "md",
	className,
}: {
	value: number
	compareAt?: number | null
	size?: "sm" | "md" | "lg"
	className?: string
}) {
	const discount = discountPercent(value, compareAt)
	return (
		<span className={cn("nums inline-flex flex-wrap items-baseline gap-2", className)}>
			<span
				className={cn(
					"font-semibold text-ink",
					size === "sm" && "text-sm",
					size === "md" && "text-base",
					size === "lg" && "text-2xl",
				)}
			>
				{formatPrice(value)}
			</span>
			{compareAt && compareAt > value ? (
				<>
					<s className={cn("text-ink-muted", size === "lg" ? "text-base" : "text-xs")}>
						{formatPrice(compareAt)}
					</s>
					{discount ? (
						<span className="rounded-full bg-rose-100 px-2 py-0.5 text-[11px] font-semibold text-rose-700">
							خصم {discount}%
						</span>
					) : null}
				</>
			) : null}
		</span>
	)
}

export function Rating({
	value,
	count,
	size = 14,
	className,
}: {
	value: number
	count?: number | null
	size?: number
	className?: string
}) {
	const rounded = Math.round(value)
	return (
		<span
			className={cn("inline-flex items-center gap-1", className)}
			aria-label={`التقييم ${value.toFixed(1)} من 5`}
		>
			<span className="flex items-center gap-0.5" aria-hidden="true">
				{[1, 2, 3, 4, 5].map((star) => (
					<Star
						key={star}
						width={size}
						height={size}
						className={star <= rounded ? "fill-gold-500 text-gold-500" : "text-sand-dark"}
					/>
				))}
			</span>
			{typeof count === "number" && count > 0 ? (
				<span className="nums text-xs text-ink-muted">({count})</span>
			) : null}
		</span>
	)
}

export function Badge({
	children,
	tone = "rose",
	className,
}: {
	children: ReactNode
	tone?: "rose" | "sage" | "gold" | "ink" | "muted"
	className?: string
}) {
	const tones = {
		rose: "bg-rose-100 text-rose-700",
		sage: "bg-sage-100 text-sage-700",
		gold: "bg-gold-100 text-[#8A6636]",
		ink: "bg-ink text-cream",
		muted: "bg-sand text-ink-soft",
	} as const
	return (
		<span
			className={cn(
				"inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-semibold",
				tones[tone],
				className,
			)}
		>
			{children}
		</span>
	)
}

export function SectionHeading({
	eyebrow,
	title,
	description,
	action,
	center,
	className,
}: {
	eyebrow?: string
	title: string
	description?: string
	action?: ReactNode
	center?: boolean
	className?: string
}) {
	return (
		<div
			className={cn(
				"mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
				center && "sm:flex-col sm:items-center sm:text-center",
				className,
			)}
		>
			<div className={cn("max-w-prose", center && "mx-auto text-center")}>
				{eyebrow ? (
					<p className="mb-2 text-xs font-semibold uppercase tracking-[0.18em] text-rose-500">{eyebrow}</p>
				) : null}
				<h2 className="text-display-sm sm:text-display-md">{title}</h2>
				{description ? <p className="mt-3 text-ink-soft">{description}</p> : null}
			</div>
			{action ? <div className="shrink-0">{action}</div> : null}
		</div>
	)
}

export function EmptyState({
	icon,
	title,
	description,
	action,
	className,
}: {
	icon?: ReactNode
	title: string
	description?: string
	action?: ReactNode
	className?: string
}) {
	return (
		<div
			className={cn(
				"surface flex flex-col items-center justify-center gap-3 px-6 py-14 text-center",
				className,
			)}
		>
			{icon ? (
				<span className="flex h-14 w-14 items-center justify-center rounded-full bg-rose-50 text-rose-500">
					{icon}
				</span>
			) : null}
			<h3 className="text-lg font-semibold">{title}</h3>
			{description ? <p className="max-w-sm text-sm text-ink-soft">{description}</p> : null}
			{action ? <div className="mt-2">{action}</div> : null}
		</div>
	)
}

export function Skeleton({ className }: { className?: string }) {
	return <div className={cn("skeleton h-4 w-full", className)} aria-hidden="true" />
}

export function ProductCardSkeleton() {
	return (
		<div className="surface overflow-hidden p-3">
			<Skeleton className="aspect-[4/5] w-full rounded-2xl" />
			<div className="space-y-2 p-3">
				<Skeleton className="h-4 w-3/4" />
				<Skeleton className="h-3 w-1/2" />
				<Skeleton className="h-5 w-1/3" />
			</div>
		</div>
	)
}
