"use client"

import { Minus, Plus } from "lucide-react"
import { cn } from "@/lib/utils/cn"

export function QuantitySelector({
	value,
	onChange,
	min = 1,
	max = 99,
	disabled,
	size = "md",
	label = "الكمية",
}: {
	value: number
	onChange: (next: number) => void
	min?: number
	max?: number
	disabled?: boolean
	size?: "sm" | "md"
	label?: string
}) {
	const clamp = (next: number) => Math.min(max, Math.max(min, next))
	const buttonSize = size === "sm" ? "h-9 w-9" : "h-11 w-11"

	return (
		<div
			className={cn(
				"inline-flex items-center gap-1 rounded-full border border-sand-dark bg-ivory p-1",
				disabled && "opacity-60",
			)}
			role="group"
			aria-label={label}
		>
			<button
				type="button"
				className={cn(
					buttonSize,
					"flex items-center justify-center rounded-full text-ink transition-colors hover:bg-rose-50 hover:text-rose-700 disabled:pointer-events-none disabled:opacity-40",
				)}
				onClick={() => onChange(clamp(value - 1))}
				disabled={disabled || value <= min}
				aria-label="تقليل الكمية"
			>
				<Minus className="h-4 w-4" />
			</button>
			<span className="nums min-w-8 text-center text-sm font-semibold" aria-live="polite">
				{value}
			</span>
			<button
				type="button"
				className={cn(
					buttonSize,
					"flex items-center justify-center rounded-full text-ink transition-colors hover:bg-rose-50 hover:text-rose-700 disabled:pointer-events-none disabled:opacity-40",
				)}
				onClick={() => onChange(clamp(value + 1))}
				disabled={disabled || value >= max}
				aria-label="زيادة الكمية"
			>
				<Plus className="h-4 w-4" />
			</button>
		</div>
	)
}
