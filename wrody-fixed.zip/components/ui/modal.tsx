"use client"

import { X } from "lucide-react"
import { useEffect, useRef, useState, type ReactNode } from "react"
import { createPortal } from "react-dom"
import { cn } from "@/lib/utils/cn"
import { Button } from "@/components/ui/button"

const FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]), select, textarea, [tabindex]:not([tabindex="-1"])'

export function Modal({
	open,
	onClose,
	title,
	description,
	children,
	footer,
	size = "md",
	sheetOnMobile = true,
}: {
	open: boolean
	onClose: () => void
	title: string
	description?: string
	children?: ReactNode
	footer?: ReactNode
	size?: "sm" | "md" | "lg"
	sheetOnMobile?: boolean
}) {
	const [mounted, setMounted] = useState(false)
	const panelRef = useRef<HTMLDivElement>(null)
	const returnFocusRef = useRef<HTMLElement | null>(null)

	useEffect(() => setMounted(true), [])

	useEffect(() => {
		if (!open) return
		returnFocusRef.current = document.activeElement as HTMLElement
		const { overflow } = document.body.style
		document.body.style.overflow = "hidden"

		const focusables = panelRef.current?.querySelectorAll<HTMLElement>(FOCUSABLE)
		focusables?.[0]?.focus()

		function onKeyDown(event: KeyboardEvent) {
			if (event.key === "Escape") {
				event.preventDefault()
				onClose()
				return
			}
			if (event.key !== "Tab") return
			const nodes = panelRef.current?.querySelectorAll<HTMLElement>(FOCUSABLE)
			if (!nodes || nodes.length === 0) return
			const first = nodes[0]
			const last = nodes[nodes.length - 1]
			if (event.shiftKey && document.activeElement === first) {
				event.preventDefault()
				last.focus()
			} else if (!event.shiftKey && document.activeElement === last) {
				event.preventDefault()
				first.focus()
			}
		}

		document.addEventListener("keydown", onKeyDown)
		return () => {
			document.removeEventListener("keydown", onKeyDown)
			document.body.style.overflow = overflow
			returnFocusRef.current?.focus?.()
		}
	}, [open, onClose])

	if (!mounted || !open) return null

	return createPortal(
		<div className="fixed inset-0 z-[80] flex items-end justify-center sm:items-center">
			<div
				className="absolute inset-0 bg-ink/40 backdrop-blur-[2px] animate-fade-in"
				onClick={onClose}
				aria-hidden="true"
			/>
			<div
				ref={panelRef}
				role="dialog"
				aria-modal="true"
				aria-label={title}
				className={cn(
					"relative z-10 w-full border border-sand bg-ivory p-5 shadow-lift sm:p-6",
					sheetOnMobile
						? "max-h-[92vh] overflow-y-auto rounded-t-4xl animate-slide-up sm:rounded-4xl sm:animate-scale-in"
						: "rounded-4xl animate-scale-in",
					size === "sm" && "sm:max-w-sm",
					size === "md" && "sm:max-w-lg",
					size === "lg" && "sm:max-w-2xl",
				)}
			>
				<div className="mb-4 flex items-start justify-between gap-4">
					<div>
						<h2 className="text-lg font-semibold">{title}</h2>
						{description ? <p className="mt-1 text-sm text-ink-soft">{description}</p> : null}
					</div>
					<button
						type="button"
						onClick={onClose}
						aria-label="إغلاق"
						className="-me-1 -mt-1 rounded-full p-2 text-ink-soft transition-colors hover:bg-rose-50 hover:text-rose-700"
					>
						<X className="h-5 w-5" />
					</button>
				</div>
				{children}
				{footer ? <div className="mt-6 flex flex-wrap justify-end gap-2">{footer}</div> : null}
			</div>
		</div>,
		document.body,
	)
}

/** Used for every destructive admin action. */
export function ConfirmDialog({
	open,
	onClose,
	onConfirm,
	title,
	description,
	confirmLabel = "تأكيد",
	pending,
}: {
	open: boolean
	onClose: () => void
	onConfirm: () => void
	title: string
	description?: string
	confirmLabel?: string
	pending?: boolean
}) {
	return (
		<Modal
			open={open}
			onClose={onClose}
			title={title}
			description={description}
			size="sm"
			sheetOnMobile={false}
			footer={
				<>
					<Button variant="outline" onClick={onClose} disabled={pending}>
						إلغاء
					</Button>
					<Button variant="danger" onClick={onConfirm} disabled={pending}>
						{pending ? "جاري..." : confirmLabel}
					</Button>
				</>
			}
		/>
	)
}
