"use client"

import { useEffect, useRef, type ElementType, type ReactNode } from "react"
import { cn } from "@/lib/utils/cn"

/**
 * Scroll reveal with zero layout cost: one IntersectionObserver per element,
 * disconnected after the first intersection. Content is visible by default
 * (see globals.css) so it never disappears without JS or with reduced motion.
 */
export function Reveal({
	children,
	className,
	delay = 0,
	as: Tag = "div",
}: {
	children: ReactNode
	className?: string
	delay?: number
	as?: ElementType
}) {
	const ref = useRef<HTMLElement>(null)

	useEffect(() => {
		const node = ref.current
		if (!node) return
		if (typeof IntersectionObserver === "undefined") {
			node.classList.add("reveal-in")
			return
		}

		const observer = new IntersectionObserver(
			(entries) => {
				for (const entry of entries) {
					if (!entry.isIntersecting) continue
					node.classList.add("reveal-in")
					observer.disconnect()
				}
			},
			{ rootMargin: "0px 0px -8% 0px", threshold: 0.08 },
		)
		observer.observe(node)
		return () => observer.disconnect()
	}, [])

	return (
		<Tag
			ref={ref}
			className={cn("reveal", className)}
			style={delay ? { transitionDelay: `${delay}ms` } : undefined}
		>
			{children}
		</Tag>
	)
}
