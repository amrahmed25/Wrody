import Link from "next/link"
import type { ComponentProps } from "react"
import { cn } from "@/lib/utils/cn"

export type ButtonVariant = "primary" | "secondary" | "outline" | "ghost" | "sage" | "danger"
export type ButtonSize = "sm" | "md" | "lg" | "icon"

const BASE =
	"inline-flex select-none items-center justify-center gap-2 rounded-full font-medium leading-none transition-all duration-200 ease-soft active:scale-[.98] disabled:pointer-events-none disabled:opacity-55"

const VARIANTS: Record<ButtonVariant, string> = {
	primary: "bg-rose-500 text-white shadow-soft hover:bg-rose-600",
	secondary: "bg-ink text-cream hover:bg-ink/90",
	outline: "border border-sand-dark bg-ivory text-ink hover:border-rose-300 hover:text-rose-700",
	ghost: "text-ink-soft hover:bg-rose-50 hover:text-rose-700",
	sage: "bg-sage-500 text-white hover:bg-sage-700",
	danger: "bg-rose-700 text-white hover:bg-rose-800",
}

/** 44px minimum touch target on every size except the compact one. */
const SIZES: Record<ButtonSize, string> = {
	sm: "min-h-9 px-4 text-sm",
	md: "min-h-11 px-5 text-[0.95rem]",
	lg: "min-h-12 px-7 text-base",
	icon: "h-11 w-11 shrink-0",
}

export function buttonClass(options?: {
	variant?: ButtonVariant
	size?: ButtonSize
	className?: string
}) {
	return cn(BASE, VARIANTS[options?.variant ?? "primary"], SIZES[options?.size ?? "md"], options?.className)
}

type ButtonProps = ComponentProps<"button"> & {
	variant?: ButtonVariant
	size?: ButtonSize
}

export function Button({ variant, size, className, type = "button", ...props }: ButtonProps) {
	return <button type={type} className={buttonClass({ variant, size, className })} {...props} />
}

type ButtonLinkProps = ComponentProps<typeof Link> & {
	variant?: ButtonVariant
	size?: ButtonSize
}

export function ButtonLink({ variant, size, className, ...props }: ButtonLinkProps) {
	return <Link className={buttonClass({ variant, size, className })} {...props} />
}
