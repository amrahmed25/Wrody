"use client"

import { CheckCircle2, Info, X, XCircle } from "lucide-react"
import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react"
import { cn } from "@/lib/utils/cn"

export type ToastTone = "success" | "error" | "info"
type ToastItem = { id: number; message: string; tone: ToastTone }

const ToastContext = createContext<((message: string, tone?: ToastTone) => void) | null>(null)

const TONES: Record<ToastTone, { icon: ReactNode; className: string }> = {
	success: {
		icon: <CheckCircle2 className="h-5 w-5 text-sage-700" />,
		className: "border-sage-300 bg-sage-50 text-sage-700",
	},
	error: {
		icon: <XCircle className="h-5 w-5 text-rose-700" />,
		className: "border-rose-200 bg-rose-50 text-rose-700",
	},
	info: {
		icon: <Info className="h-5 w-5 text-ink-soft" />,
		className: "border-sand-dark bg-ivory text-ink",
	},
}

export function ToastProvider({ children }: { children: ReactNode }) {
	const [items, setItems] = useState<ToastItem[]>([])

	const dismiss = useCallback((id: number) => {
		setItems((current) => current.filter((item) => item.id !== id))
	}, [])

	const toast = useCallback(
		(message: string, tone: ToastTone = "success") => {
			if (!message) return
			const id = Date.now() + Math.random()
			setItems((current) => [...current.slice(-2), { id, message, tone }])
			window.setTimeout(() => dismiss(id), 4000)
		},
		[dismiss],
	)

	const value = useMemo(() => toast, [toast])

	return (
		<ToastContext.Provider value={value}>
			{children}
			<div
				aria-live="polite"
				aria-atomic="false"
				className="pointer-events-none fixed inset-x-0 bottom-4 z-[70] flex flex-col items-center gap-2 px-4 sm:bottom-6"
			>
				{items.map((item) => (
					<div
						key={item.id}
						className={cn(
							"pointer-events-auto flex w-full max-w-sm items-center gap-3 rounded-2xl border px-4 py-3 text-sm shadow-lift animate-toast-in",
							TONES[item.tone].className,
						)}
					>
						{TONES[item.tone].icon}
						<p className="flex-1">{item.message}</p>
						<button
							type="button"
							onClick={() => dismiss(item.id)}
							aria-label="إغلاق التنبيه"
							className="rounded-full p-1 transition-colors hover:bg-black/5"
						>
							<X className="h-4 w-4" />
						</button>
					</div>
				))}
			</div>
		</ToastContext.Provider>
	)
}

/** Safe no-op when used outside the provider (e.g. isolated unit rendering). */
export function useToast() {
	const context = useContext(ToastContext)
	return context ?? (() => {})
}
