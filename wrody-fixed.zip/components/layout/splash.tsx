"use client"

import { useEffect, useState } from "react"
import { LogoMark } from "@/components/shared/logo"

const PETALS = [0, 60, 120, 180, 240, 300]

export function Splash() {
	const [phase, setPhase] = useState<"show" | "hiding" | "gone">("show")

	useEffect(() => {
		let seen = false
		try {
			seen = sessionStorage.getItem("wrody-splash") === "1"
		} catch {
			seen = false
		}

		const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches
		if (seen || reduceMotion) {
			setPhase("gone")
			return
		}

		const start = Date.now()
		let hidden = false
		const timers: number[] = []

		const hide = () => {
			if (hidden) return
			hidden = true
			setPhase("hiding")
			try {
				sessionStorage.setItem("wrody-splash", "1")
			} catch {
				/* private mode */
			}
			timers.push(window.setTimeout(() => setPhase("gone"), 420))
		}

		const ready = () => {
			const wait = Math.max(0, 650 - (Date.now() - start))
			timers.push(window.setTimeout(hide, wait))
		}

		if (document.readyState === "complete") ready()
		else window.addEventListener("load", ready, { once: true })

		timers.push(window.setTimeout(hide, 1500))

		return () => {
			window.removeEventListener("load", ready)
			for (const timer of timers) window.clearTimeout(timer)
		}
	}, [])

	if (phase === "gone") return null

	return (
		<div
			id="wrody-splash"
			role="status"
			aria-live="polite"
			aria-label="جاري تحميل ورودي"
			className={phase === "hiding" ? "is-hidden" : undefined}
		>
			<style>{`
#wrody-splash {
	position: fixed;
	inset: 0;
	z-index: 100;
	display: flex;
	flex-direction: column;
	align-items: center;
	justify-content: center;
	gap: 1.25rem;
	background: #FBF7F2;
	transition: opacity .4s ease, visibility .4s ease;
}
#wrody-splash.is-hidden {
	opacity: 0;
	visibility: hidden;
	pointer-events: none;
}
#wrody-splash .petal {
	transform-origin: 24px 24px;
	animation: wrody-petal .62s cubic-bezier(.22,1,.36,1) both;
}
#wrody-splash .word {
	animation: wrody-fade-up .5s .38s cubic-bezier(.22,1,.36,1) both;
}
@keyframes wrody-fade-up {
	from { opacity: 0; transform: translateY(8px); }
	to { opacity: 1; transform: none; }
}
@media (prefers-reduced-motion: reduce) {
	#wrody-splash { display: none; }
}
			`}</style>

			<div className="relative flex h-28 w-28 items-center justify-center">
				<svg viewBox="0 0 48 48" className="absolute inset-0 h-full w-full text-rose-300" aria-hidden="true">
					<g stroke="currentColor" strokeWidth="1.9" fill="none" strokeLinecap="round">
						{PETALS.map((angle, index) => (
							<ellipse
								key={angle}
								className="petal"
								cx="24"
								cy="13"
								rx="5.6"
								ry="10"
								style={{
									["--petal" as string]: `${angle}deg`,
									animationDelay: `${index * 55}ms`,
								}}
							/>
						))}
					</g>
				</svg>
				<LogoMark size={34} className="relative text-rose-500" />
			</div>

			<div className="word text-center">
				<p className="font-display text-2xl font-bold text-ink">ورودي</p>
				<p className="mt-1 text-sm text-ink-soft">ورد معمول بحب</p>
			</div>
		</div>
	)
}
