"use client"

import { Menu, X } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useEffect, useState } from "react"
import { Logo } from "@/components/shared/logo"
import { cn } from "@/lib/utils/cn"

export type MenuLink = { href: string; label: string }

export function MobileMenu({
	links,
	categories,
	account,
}: {
	links: MenuLink[]
	categories: MenuLink[]
	account: { label: string; href: string }
}) {
	const [open, setOpen] = useState(false)
	const pathname = usePathname()

	useEffect(() => setOpen(false), [pathname])

	useEffect(() => {
		if (!open) return
		const { overflow } = document.body.style
		document.body.style.overflow = "hidden"
		const onKey = (event: KeyboardEvent) => event.key === "Escape" && setOpen(false)
		document.addEventListener("keydown", onKey)
		return () => {
			document.removeEventListener("keydown", onKey)
			document.body.style.overflow = overflow
		}
	}, [open])

	return (
		<>
			<button
				type="button"
				onClick={() => setOpen(true)}
				className="flex h-11 w-11 items-center justify-center rounded-full text-ink transition-colors hover:bg-rose-50 lg:hidden"
				aria-label="فتح القائمة"
				aria-expanded={open}
			>
				<Menu className="h-5 w-5" />
			</button>

			{open ? (
				<div className="fixed inset-0 z-[90] lg:hidden">
					<div
						className="absolute inset-0 bg-ink/40 animate-fade-in"
						onClick={() => setOpen(false)}
						aria-hidden="true"
					/>
					<nav
						aria-label="قائمة التنقل"
						className="absolute inset-y-0 start-0 flex w-[86%] max-w-xs flex-col overflow-y-auto border-e border-sand bg-ivory p-5 shadow-lift animate-fade-in"
					>
						<div className="mb-6 flex items-center justify-between">
							<Logo size={32} />
							<button
								type="button"
								onClick={() => setOpen(false)}
								className="flex h-10 w-10 items-center justify-center rounded-full text-ink-soft hover:bg-rose-50"
								aria-label="إغلاق القائمة"
								autoFocus
							>
								<X className="h-5 w-5" />
							</button>
						</div>

						<ul className="space-y-1">
							{links.map((link) => (
								<li key={link.href}>
									<Link
										href={link.href}
										className={cn(
											"flex min-h-11 items-center rounded-2xl px-3 text-[0.95rem] font-medium text-ink transition-colors hover:bg-rose-50",
											pathname === link.href && "bg-rose-50 text-rose-700",
										)}
									>
										{link.label}
									</Link>
								</li>
							))}
						</ul>

						{categories.length ? (
							<div className="mt-6">
								<p className="mb-2 px-3 text-xs font-semibold uppercase tracking-widest text-ink-muted">
									الأقسام
								</p>
								<ul className="space-y-1">
									{categories.map((category) => (
										<li key={category.href}>
											<Link
												href={category.href}
												className="flex min-h-11 items-center rounded-2xl px-3 text-sm text-ink-soft transition-colors hover:bg-rose-50 hover:text-ink"
											>
												{category.label}
											</Link>
										</li>
									))}
								</ul>
							</div>
						) : null}

						<Link
							href={account.href}
							className="mt-auto flex min-h-12 items-center justify-center rounded-full bg-ink px-5 text-sm font-medium text-cream"
						>
							{account.label}
						</Link>
					</nav>
				</div>
			) : null}
		</>
	)
}
