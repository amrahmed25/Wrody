"use client"

import { useEffect } from "react"

/** Adds the `js` class after hydration so reveal CSS never mismatches SSR. */
export function JsReady() {
	useEffect(() => {
		document.documentElement.classList.add("js")
	}, [])
	return null
}
