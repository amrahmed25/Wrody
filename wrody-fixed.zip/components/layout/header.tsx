import { Heart, LayoutDashboard, Search, ShoppingBag, User } from "lucide-react"
import Link from "next/link"
import { MobileMenu } from "@/components/layout/mobile-menu"
import { Logo } from "@/components/shared/logo"
import { getProfile } from "@/lib/auth/session"
import { CartDrawer } from "@/components/cart/cart-drawer"
import { getCart } from "@/lib/services/cart"
import { getCategories } from "@/lib/services/catalog"
import { getDeliverySettings } from "@/lib/services/settings"
import { formatPrice } from "@/lib/utils/format"

const NAV_LINKS = [
	{ href: "/", label: "الرئيسية" },
	{ href: "/shop", label: "المتجر" },
	{ href: "/custom-bouquet", label: "اصنع بوكيهك" },
	{ href: "/track", label: "تتبع طلبك" },
	{ href: "/about", label: "عن ورودي" },
]

/**
 * Server component: the only client JS in the header is the mobile drawer.
 * Search is a plain GET form, so it works with JavaScript disabled.
 */
export async function SiteHeader() {
	const [profile, cart, categories, delivery] = await Promise.all([
		getProfile(),
		getCart(),
		getCategories(),
		getDeliverySettings(),
	])

	const accountHref = profile ? "/account" : "/login"
	const accountLabel = profile ? "حسابي" : "تسجيل الدخول"

	return (
		<header className="sticky top-0 z-50 border-b border-sand/80 bg-cream/90 backdrop-blur-md">
			{delivery.free_threshold ? (
				<p className="bg-ink px-4 py-2 text-center text-[13px] text-cream">
					شحن مجاني للطلبات فوق <span className="nums font-semibold">{formatPrice(delivery.free_threshold)}</span> — كل بوكيه معمول بإيدينا 🤍
				</p>
			) : null}

			<div className="container-page flex h-[var(--header-height)] items-center gap-3">
				<MobileMenu
					links={NAV_LINKS}
					categories={categories.map((category) => ({
						href: `/shop?category=${category.slug}`,
						label: category.name,
					}))}
					account={{ href: accountHref, label: accountLabel }}
				/>

				<Link href="/" className="shrink-0 rounded-2xl" aria-label="ورودي — الصفحة الرئيسية">
					<Logo />
				</Link>

				<nav aria-label="رئيسية" className="hidden lg:block">
					<ul className="flex items-center gap-1">
						{NAV_LINKS.map((link) => (
							<li key={link.href}>
								<Link
									href={link.href}
									className="flex min-h-10 items-center rounded-full px-3 text-[0.95rem] text-ink-soft transition-colors hover:bg-rose-50 hover:text-rose-700"
								>
									{link.label}
								</Link>
							</li>
						))}
					</ul>
				</nav>

				<form action="/shop" role="search" className="relative ms-auto hidden max-w-xs flex-1 md:block">
					<label htmlFor="header-search" className="sr-only">
						ابحث عن بوكيه
					</label>
					<Search className="pointer-events-none absolute inset-y-0 start-4 my-auto h-4 w-4 text-ink-muted" />
					<input
						id="header-search"
						name="q"
						type="search"
						placeholder="دوّر على بوكيه..."
						className="h-11 w-full rounded-full border border-sand-dark bg-ivory ps-11 pe-4 text-sm transition-colors hover:border-rose-200 focus:border-rose-400 focus:outline-none focus:ring-2 focus:ring-rose-200"
					/>
				</form>

				<div className="flex items-center gap-1 md:ms-0 ms-auto">
					<Link
						href="/shop"
						className="flex h-11 w-11 items-center justify-center rounded-full text-ink transition-colors hover:bg-rose-50 md:hidden"
						aria-label="بحث"
					>
						<Search className="h-5 w-5" />
					</Link>

					<Link
						href="/wishlist"
						className="hidden h-11 w-11 items-center justify-center rounded-full text-ink transition-colors hover:bg-rose-50 sm:flex"
						aria-label="المفضلة"
					>
						<Heart className="h-5 w-5" />
					</Link>

					{profile?.role === "admin" ? (
						<Link
							href="/admin"
							className="hidden h-11 w-11 items-center justify-center rounded-full text-ink transition-colors hover:bg-rose-50 sm:flex"
							aria-label="لوحة التحكم"
						>
							<LayoutDashboard className="h-5 w-5" />
						</Link>
					) : null}

					<Link
						href={accountHref}
						className="flex h-11 w-11 items-center justify-center rounded-full text-ink transition-colors hover:bg-rose-50"
						aria-label={accountLabel}
					>
						<User className="h-5 w-5" />
					</Link>

					<CartDrawer lines={cart.lines} totals={cart.totals} count={cart.count} />
				</div>
			</div>
		</header>
	)
}
