import { Instagram, Mail, MessageCircle, Phone } from "lucide-react"
import Link from "next/link"
import { Logo } from "@/components/shared/logo"
import { publicEnv } from "@/lib/config/env"
import { siteConfig } from "@/lib/config/site"
import { getCategories } from "@/lib/services/catalog"
import { getSetting } from "@/lib/services/settings"

const HELP_LINKS = [
	{ href: "/track", label: "تتبع طلبك" },
	{ href: "/orders", label: "طلباتي" },
	{ href: "/custom-bouquet", label: "اصنع بوكيهك" },
	{ href: "/about", label: "عن ورودي" },
]

export async function SiteFooter() {
	const [categories, contact] = await Promise.all([getCategories(), getSetting("store.contact")])
	const whatsapp = publicEnv.whatsappNumber
	const instagram = contact.instagram ?? siteConfig.social.instagram

	return (
		<footer className="mt-24 border-t border-sand bg-ivory">
			<div className="container-page grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-4">
				<div className="sm:col-span-2 lg:col-span-1">
					<Logo size={40} />
					<p className="mt-4 max-w-xs text-sm leading-relaxed text-ink-soft">
						ورود وبوكيهات هاند ميد معمولة من خامة الـPipe Cleaners. مابتذبلش، وبتفضل ذكرى طول العمر.
					</p>
				</div>

				<nav aria-label="الأقسام">
					<h2 className="mb-4 text-sm font-semibold text-ink">الأقسام</h2>
					<ul className="space-y-2.5 text-sm text-ink-soft">
						{categories.slice(0, 6).map((category) => (
							<li key={category.id}>
								<Link
									href={`/shop?category=${category.slug}`}
									className="transition-colors hover:text-rose-700"
								>
									{category.name}
								</Link>
							</li>
						))}
					</ul>
				</nav>

				<nav aria-label="روابط مساعدة">
					<h2 className="mb-4 text-sm font-semibold text-ink">مساعدة</h2>
					<ul className="space-y-2.5 text-sm text-ink-soft">
						{HELP_LINKS.map((link) => (
							<li key={link.href}>
								<Link href={link.href} className="transition-colors hover:text-rose-700">
									{link.label}
								</Link>
							</li>
						))}
					</ul>
				</nav>

				<div>
					<h2 className="mb-4 text-sm font-semibold text-ink">كلمنا</h2>
					<ul className="space-y-3 text-sm text-ink-soft">
						{whatsapp ? (
							<li>
								<a
									href={`https://wa.me/${whatsapp}`}
									target="_blank"
									rel="noopener noreferrer"
									className="inline-flex items-center gap-2 transition-colors hover:text-rose-700"
								>
									<MessageCircle className="h-4 w-4" />
									واتساب
								</a>
							</li>
						) : null}
						{contact.phone ? (
							<li>
								<a
									href={`tel:${contact.phone}`}
									className="nums inline-flex items-center gap-2 transition-colors hover:text-rose-700"
								>
									<Phone className="h-4 w-4" />
									{contact.phone}
								</a>
							</li>
						) : null}
						{contact.email ? (
							<li>
								<a
									href={`mailto:${contact.email}`}
									className="inline-flex items-center gap-2 transition-colors hover:text-rose-700"
								>
									<Mail className="h-4 w-4" />
									{contact.email}
								</a>
							</li>
						) : null}
						<li>
							<a
								href={instagram.startsWith("http") ? instagram : `https://instagram.com/${instagram}`}
								target="_blank"
								rel="noopener noreferrer"
								className="inline-flex items-center gap-2 transition-colors hover:text-rose-700"
							>
								<Instagram className="h-4 w-4" />
								انستجرام
							</a>
						</li>
					</ul>
				</div>
			</div>

			<div className="border-t border-sand">
				<div className="container-page flex flex-col items-center justify-between gap-3 py-5 text-xs text-ink-muted sm:flex-row">
					<p>
						© <span className="nums">{new Date().getFullYear()}</span> ورودي — كل الحقوق محفوظة.
					</p>
					<p>الدفع عند الاستلام متاح في كل المحافظات</p>
				</div>
			</div>
		</footer>
	)
}
