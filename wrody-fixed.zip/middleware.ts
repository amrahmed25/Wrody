import { NextResponse, type NextRequest } from "next/server"
import { updateSession } from "@/lib/supabase/middleware"

/** Routes that require an authenticated customer. */
const CUSTOMER_ROUTES = ["/account", "/orders", "/wishlist"]

export async function middleware(request: NextRequest) {
	const { response, supabase, user } = await updateSession(request)
	const { pathname } = request.nextUrl

	const loginRedirect = (target: string) =>
		NextResponse.redirect(new URL(`/login?next=${encodeURIComponent(target)}`, request.url))

	// Admin area: authenticated AND role = admin (checked again in the layout).
	if (pathname.startsWith("/admin")) {
		if (!user) return loginRedirect(pathname)
		const { data } = await supabase.from("profiles").select("role").eq("id", user.id).maybeSingle()
		if (data?.role !== "admin") return NextResponse.redirect(new URL("/unauthorized", request.url))
	}

	if (!user && CUSTOMER_ROUTES.some((route) => pathname.startsWith(route))) {
		return loginRedirect(pathname)
	}

	return response
}

export const config = {
	matcher: [
		"/((?!_next/static|_next/image|favicon.ico|art|products|categories|.*\\.(?:svg|png|jpg|jpeg|webp|avif|ico|txt|xml)$).*)",
	],
}
