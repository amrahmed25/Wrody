import { publicEnv } from "@/lib/config/env"

export const siteConfig = {
	name: "ورودي",
	nameEn: "Wrody",
	tagline: "ورد معمول بحب، عشان يفضل معاك.",
	description:
		"ورودي — بوكيهات وورود هاند ميد مصنوعة من خامة الـPipe Cleaners، تفضل معاك لسنين. صمم بوكيهك بنفسك واطلبه أونلاين مع الدفع عند الاستلام.",
	url: publicEnv.siteUrl,
	locale: "ar_EG",
	currency: "EGP",
	currencyLabel: "ج.م",
	timeZone: "Africa/Cairo",
	nav: [
		{ href: "/shop", label: "المتجر" },
		{ href: "/custom-bouquet", label: "اصنع بوكيهك" },
		{ href: "/track", label: "تتبع طلبك" },
		{ href: "/about", label: "عن ورودي" },
	],
	social: {
		instagram: "https://instagram.com/wrody.handmade",
		tiktok: "https://tiktok.com/@wrody.handmade",
	},
} as const

export const PRODUCTS_PER_PAGE = 12
export const CART_SESSION_COOKIE = "wrody_cart_session"
export const COUPON_COOKIE = "wrody_coupon"
export const GUEST_ORDERS_COOKIE = "wrody_guest_orders"
