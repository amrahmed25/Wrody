/**
 * Environment access.
 * Public values are inlined by Next at build time. Secrets are only ever read
 * through the helpers below, which are exclusively called from server code.
 */

function required(value: string | undefined, name: string): string {
	if (!value) {
		throw new Error(
			`متغير البيئة ${name} غير مضبوط. راجع ملف .env.local (انظر .env.example).`,
		)
	}
	return value
}

export const publicEnv = {
	siteUrl: process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000",
	supabaseUrl: process.env.NEXT_PUBLIC_SUPABASE_URL ?? "",
	supabaseAnonKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "",
	buckets: {
		products: process.env.NEXT_PUBLIC_SUPABASE_PRODUCT_BUCKET ?? "product-images",
		categories: process.env.NEXT_PUBLIC_SUPABASE_CATEGORY_BUCKET ?? "category-images",
		avatars: process.env.NEXT_PUBLIC_SUPABASE_AVATAR_BUCKET ?? "avatars",
	},
	whatsappNumber: process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "",
	onlinePaymentEnabled: process.env.NEXT_PUBLIC_ENABLE_ONLINE_PAYMENT === "true",
} as const

export function supabaseUrl(): string {
	return required(publicEnv.supabaseUrl, "NEXT_PUBLIC_SUPABASE_URL")
}

export function supabaseAnonKey(): string {
	return required(publicEnv.supabaseAnonKey, "NEXT_PUBLIC_SUPABASE_ANON_KEY")
}

export function hasServiceRoleKey(): boolean {
	return Boolean(process.env.SUPABASE_SERVICE_ROLE_KEY)
}

/** Server only. Never import this from a Client Component. */
export function supabaseServiceRoleKey(): string {
	return required(process.env.SUPABASE_SERVICE_ROLE_KEY, "SUPABASE_SERVICE_ROLE_KEY")
}

export const serverEnv = {
	emailProvider: process.env.EMAIL_PROVIDER ?? "console",
	emailFrom: process.env.EMAIL_FROM ?? "",
	resendApiKey: process.env.RESEND_API_KEY ?? "",
	whatsappToken: process.env.WHATSAPP_API_TOKEN ?? "",
	whatsappPhoneNumberId: process.env.WHATSAPP_PHONE_NUMBER_ID ?? "",
	paymentGateway: process.env.PAYMENT_GATEWAY ?? "none",
} as const
