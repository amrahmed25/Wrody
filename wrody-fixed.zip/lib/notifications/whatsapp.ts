import "server-only"

import { publicEnv, serverEnv } from "@/lib/config/env"
import { formatPrice } from "@/lib/utils/format"

/**
 * WhatsApp integration.
 *
 * Two independent layers:
 * 1. `buildWhatsAppOrderLink` — a plain wa.me deep link. No credentials, no
 *    secrets, works immediately and powers the "تأكيد الطلب عبر WhatsApp" button.
 * 2. `sendWhatsAppOrderNotification` — the official Cloud API. It only runs when
 *    WHATSAPP_API_TOKEN + WHATSAPP_PHONE_NUMBER_ID are configured; otherwise it
 *    reports `delivered: false` instead of pretending to have sent anything.
 */

export type WhatsAppOrderSummary = {
	orderNumber: string
	total: number
	customerName: string
	customerPhone: string
	items: Array<{ name: string; quantity: number }>
}

export function buildWhatsAppOrderLink(order: WhatsAppOrderSummary): string | null {
	const number = publicEnv.whatsappNumber.replace(/[^0-9]/g, "")
	if (!number) return null

	const lines = [
		`أهلاً ورودي 🤍`,
		`تم استلام طلبي #${order.orderNumber}`,
		`الاسم: ${order.customerName}`,
		...order.items.slice(0, 8).map((item) => `• ${item.name} ×${item.quantity}`),
		`الإجمالي: ${formatPrice(order.total)}`,
		`عاوز أأكد الطلب.`,
	]

	return `https://wa.me/${number}?text=${encodeURIComponent(lines.join("\n"))}`
}

export async function sendWhatsAppOrderNotification(
	order: WhatsAppOrderSummary,
): Promise<{ delivered: boolean; reason?: string }> {
	if (!serverEnv.whatsappToken || !serverEnv.whatsappPhoneNumberId) {
		console.info(
			`[whatsapp:not-sent] order=${order.orderNumber} — configure WHATSAPP_API_TOKEN and WHATSAPP_PHONE_NUMBER_ID to enable`,
		)
		return { delivered: false, reason: "WHATSAPP_API_TOKEN غير مضبوط" }
	}

	try {
		const response = await fetch(
			`https://graph.facebook.com/v21.0/${serverEnv.whatsappPhoneNumberId}/messages`,
			{
				method: "POST",
				headers: {
					Authorization: `Bearer ${serverEnv.whatsappToken}`,
					"Content-Type": "application/json",
				},
				body: JSON.stringify({
					messaging_product: "whatsapp",
					to: order.customerPhone.replace(/[^0-9]/g, ""),
					type: "text",
					text: { body: `تم استلام طلبك #${order.orderNumber} — إجمالي ${formatPrice(order.total)}. هنتواصل معاك للتأكيد 🤍` },
				}),
			},
		)
		if (!response.ok) return { delivered: false, reason: `HTTP ${response.status}` }
		return { delivered: true }
	} catch (error) {
		return { delivered: false, reason: (error as Error).message }
	}
}
