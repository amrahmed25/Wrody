import "server-only"

import { serverEnv } from "@/lib/config/env"

/**
 * Transactional email abstraction.
 *
 * Default EMAIL_PROVIDER=console: nothing is sent and the return value says so
 * (`delivered: false`). Set EMAIL_PROVIDER=resend + RESEND_API_KEY + EMAIL_FROM
 * to actually deliver mail — that path below is a real API call, not a stub.
 * Password reset mail is handled by Supabase Auth itself.
 */

export type EmailTemplate =
	| "order_confirmation"
	| "order_status_update"
	| "order_delivered"

export type EmailPayload = {
	to: string
	subject: string
	heading: string
	lines: string[]
	ctaLabel?: string
	ctaUrl?: string
	template: EmailTemplate
}

export type EmailResult = { delivered: boolean; provider: string; reason?: string }

function renderHtml(payload: EmailPayload): string {
	const body = payload.lines.map((line) => `<p style="margin:0 0 12px">${line}</p>`).join("")
	const cta =
		payload.ctaUrl && payload.ctaLabel
			? `<p style="margin:24px 0 0"><a href="${payload.ctaUrl}" style="background:#C27B8C;color:#fff;padding:12px 20px;border-radius:10px;text-decoration:none">${payload.ctaLabel}</a></p>`
			: ""
	return `<!doctype html><html dir="rtl" lang="ar"><body style="font-family:system-ui,sans-serif;background:#FBF7F2;padding:24px;color:#2B2320">
<div style="max-width:560px;margin:auto;background:#fff;border:1px solid #EFE6DA;border-radius:16px;padding:28px">
<h1 style="font-size:20px;margin:0 0 16px">${payload.heading}</h1>${body}${cta}
<p style="margin:28px 0 0;font-size:12px;color:#9A8B80">ورودي — ورد معمول بحب 🤍</p>
</div></body></html>`
}

export async function sendTransactionalEmail(payload: EmailPayload): Promise<EmailResult> {
	const provider = serverEnv.emailProvider

	if (provider === "resend") {
		if (!serverEnv.resendApiKey || !serverEnv.emailFrom) {
			return {
				delivered: false,
				provider,
				reason: "RESEND_API_KEY / EMAIL_FROM غير مضبوطين",
			}
		}
		try {
			const response = await fetch("https://api.resend.com/emails", {
				method: "POST",
				headers: {
					Authorization: `Bearer ${serverEnv.resendApiKey}`,
					"Content-Type": "application/json",
				},
				body: JSON.stringify({
					from: serverEnv.emailFrom,
					to: [payload.to],
					subject: payload.subject,
					html: renderHtml(payload),
				}),
			})
			if (!response.ok) {
				return { delivered: false, provider, reason: `HTTP ${response.status}` }
			}
			return { delivered: true, provider }
		} catch (error) {
			return { delivered: false, provider, reason: (error as Error).message }
		}
	}

	// No provider configured: log for observability and report honestly.
	console.info(
		`[email:not-sent] template=${payload.template} to=${payload.to} subject="${payload.subject}" — set EMAIL_PROVIDER to enable delivery`,
	)
	return { delivered: false, provider: "console", reason: "EMAIL_PROVIDER=console" }
}
