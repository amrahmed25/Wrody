import { siteConfig } from "@/lib/config/site"
import type { OrderStatus, PaymentMethod, PaymentStatus } from "@/types"

const numberFormatter = new Intl.NumberFormat("ar-EG-u-nu-latn", {
	minimumFractionDigits: 0,
	maximumFractionDigits: 2,
})

export function toNumber(value: unknown, fallback = 0): number {
	const parsed = typeof value === "number" ? value : Number(value)
	return Number.isFinite(parsed) ? parsed : fallback
}

/** ٤٥٠ ج.م — Latin digits keep prices scannable inside an Arabic RTL layout. */
export function formatPrice(value: unknown): string {
	return `${numberFormatter.format(toNumber(value))} ${siteConfig.currencyLabel}`
}

export function formatNumber(value: unknown): string {
	return numberFormatter.format(toNumber(value))
}

export function formatDate(value: string | Date | null | undefined): string {
	if (!value) return "—"
	const date = typeof value === "string" ? new Date(value) : value
	if (Number.isNaN(date.getTime())) return "—"
	return new Intl.DateTimeFormat("ar-EG-u-nu-latn", {
		day: "numeric",
		month: "long",
		year: "numeric",
		timeZone: siteConfig.timeZone,
	}).format(date)
}

export function formatDateTime(value: string | Date | null | undefined): string {
	if (!value) return "—"
	const date = typeof value === "string" ? new Date(value) : value
	if (Number.isNaN(date.getTime())) return "—"
	return new Intl.DateTimeFormat("ar-EG-u-nu-latn", {
		day: "numeric",
		month: "short",
		year: "numeric",
		hour: "2-digit",
		minute: "2-digit",
		timeZone: siteConfig.timeZone,
	}).format(date)
}

export function discountPercent(price: unknown, compareAt: unknown): number | null {
	const current = toNumber(price)
	const previous = toNumber(compareAt)
	if (!previous || previous <= current) return null
	return Math.round(((previous - current) / previous) * 100)
}

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
	pending: "قيد المراجعة",
	confirmed: "تم التأكيد",
	preparing: "جاري التجهيز",
	out_for_delivery: "في الطريق إليك",
	delivered: "تم التسليم",
	cancelled: "ملغي",
}

export const ORDER_TIMELINE: OrderStatus[] = [
	"pending",
	"confirmed",
	"preparing",
	"out_for_delivery",
	"delivered",
]

export const PAYMENT_STATUS_LABELS: Record<PaymentStatus, string> = {
	pending: "في انتظار الدفع",
	paid: "مدفوع",
	failed: "فشل الدفع",
	refunded: "تم الاسترداد",
}

export const PAYMENT_METHOD_LABELS: Record<PaymentMethod, string> = {
	cod: "الدفع عند الاستلام",
	card: "بطاقة بنكية",
	wallet: "محفظة إلكترونية",
}

export function truncate(text: string, max = 120): string {
	if (text.length <= max) return text
	return `${text.slice(0, max - 1).trimEnd()}…`
}
