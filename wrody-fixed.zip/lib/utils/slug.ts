/**
 * Slugify Arabic or Latin text into a URL-safe, ASCII-ish slug.
 * Arabic letters are transliterated so slugs stay readable in links and SEO.
 */
const ARABIC_MAP: Record<string, string> = {
	"ا": "a", "أ": "a", "إ": "a", "آ": "a", "ى": "a", "ب": "b", "ت": "t", "ة": "a",
	"ث": "th", "ج": "g", "ح": "h", "خ": "kh", "د": "d", "ذ": "z", "ر": "r", "ز": "z",
	"س": "s", "ش": "sh", "ص": "s", "ض": "d", "ط": "t", "ظ": "z", "ع": "a", "غ": "gh",
	"ف": "f", "ق": "q", "ك": "k", "ل": "l", "م": "m", "ن": "n", "ه": "h", "و": "w",
	"ي": "y", "ئ": "y", "ؤ": "w", "ء": "a",
}

export function slugify(input: string): string {
	const transliterated = Array.from(input.trim().toLowerCase())
		.map((char) => ARABIC_MAP[char] ?? char)
		.join("")

	const slug = transliterated
		.normalize("NFKD")
		.replace(/[\u0300-\u036f]/g, "")
		.replace(/[^a-z0-9]+/g, "-")
		.replace(/^-+|-+$/g, "")
		.slice(0, 60)

	return slug || `item-${Date.now().toString(36)}`
}

/** Escapes the PostgREST `or(...)` wildcard syntax so search input stays safe. */
export function sanitizeSearchTerm(term: string): string {
	return term.trim().replace(/[%,()\\*]/g, " ").replace(/\s+/g, " ").slice(0, 60)
}
