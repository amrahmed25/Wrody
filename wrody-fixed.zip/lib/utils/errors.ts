import type { ActionResult } from "@/types"

/**
 * Translates the error codes raised by the Postgres business-logic functions
 * into user-facing Arabic messages. Anything unrecognised is reported as a
 * generic failure — raw database errors are never leaked to the client.
 */
const STATIC_MESSAGES: Record<string, string> = {
	CART_EMPTY: "السلة فارغة.",
	CART_NOT_FOUND: "ملقيناش السلة، جرب تضيف المنتجات تاني.",
	CART_FORBIDDEN: "مفيش صلاحية للوصول لهذه السلة.",
	CUSTOMER_INVALID: "برجاء إدخال الاسم ورقم الموبايل بشكل صحيح.",
	ADDRESS_INVALID: "برجاء إكمال بيانات العنوان.",
	QUANTITY_INVALID: "الكمية غير صحيحة.",
	FORBIDDEN: "مفيش صلاحية للقيام بهذا الإجراء.",
	ORDER_NOT_FOUND: "الطلب غير موجود.",
	STATUS_TRANSITION_INVALID: "لا يمكن الانتقال لهذه الحالة من الحالة الحالية.",
	CANCEL_NOT_ALLOWED: "مش ممكن تلغي الطلب بعد ما دخل مرحلة التجهيز. كلمنا وهنساعدك.",
	BOUQUET_NOT_FOUND: "البوكيه المخصص مش موجود.",
	BOUQUET_SIZE_INVALID: "اختر حجم بوكيه متاح.",
	BOUQUET_WRAPPING_INVALID: "اختر نوع تغليف متاح.",
	BOUQUET_CARD_INVALID: "اختر كارت متاح.",
	BOUQUET_FLOWER_INVALID: "فيه ورد مختار غير متاح حاليًا.",
	BOUQUET_QUANTITY_INVALID: "عدد الورد المختار غير صحيح.",
}

const PREFIX_MESSAGES: Array<[string, (detail: string) => string]> = [
	["OUT_OF_STOCK", (name) => `الكمية المتاحة من “${name}” قلت. قلل العدد وحاول تاني.`],
	["PRODUCT_UNAVAILABLE", (name) => `“${name}” مش متاح حاليًا. احذفه من السلة عشان تكمل.`],
	["COUPON_INVALID", (message) => message || "كود الخصم غير صالح."],
	["BOUQUET_MIN_FLOWERS", (n) => `الحد الأدنى للحجم ده هو ${n} وردات.`],
	["BOUQUET_MAX_FLOWERS", (n) => `الحد الأقصى للحجم ده هو ${n} وردة.`],
]

export function translateDbError(error: unknown, fallback = "حصل خطأ غير متوقع. حاول تاني بعد شوية."): string {
	const raw =
		typeof error === "string"
			? error
			: error && typeof error === "object" && "message" in error
				? String((error as { message?: unknown }).message ?? "")
				: ""

	if (!raw) return fallback

	for (const [code, message] of Object.entries(STATIC_MESSAGES)) {
		if (raw.includes(code)) return message
	}
	for (const [prefix, build] of PREFIX_MESSAGES) {
		const index = raw.indexOf(`${prefix}:`)
		if (index >= 0) {
			const detail = raw.slice(index + prefix.length + 1).split(/[\n"]/)[0]?.trim() ?? ""
			return build(detail)
		}
		if (raw.includes(prefix)) return build("")
	}

	if (raw.includes("duplicate key")) return "العنصر ده موجود بالفعل."
	if (raw.includes("violates row-level security")) return "مفيش صلاحية للقيام بهذا الإجراء."
	return fallback
}

export function actionError(error: unknown, fallback?: string): ActionResult<never> {
	return { ok: false, error: translateDbError(error, fallback) }
}

export function actionOk<T>(data?: T, message?: string): ActionResult<T> {
	return { ok: true, data, message }
}
