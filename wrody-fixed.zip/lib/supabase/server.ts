import "server-only"

import { cache } from "react"
import { cookies } from "next/headers"
import { createServerClient } from "@supabase/ssr"
import { supabaseAnonKey, supabaseUrl } from "@/lib/config/env"

/**
 * Request-scoped Supabase client bound to the user's session cookies.
 * Every query made through it is filtered by Row Level Security, so this is the
 * default client for reads and for anything a customer or admin does as itself.
 */
export const createClient = cache(async () => {
	const cookieStore = await cookies()

	return createServerClient(supabaseUrl(), supabaseAnonKey(), {
		cookies: {
			getAll() {
				return cookieStore.getAll()
			},
			setAll(cookiesToSet) {
				try {
					for (const { name, value, options } of cookiesToSet) {
						cookieStore.set(name, value, options)
					}
				} catch {
					// Called from a Server Component: the middleware refreshes the session.
				}
			},
		},
	})
})
