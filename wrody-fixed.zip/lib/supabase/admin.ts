import "server-only"

import { createClient as createSupabaseClient, type SupabaseClient } from "@supabase/supabase-js"
import { supabaseServiceRoleKey, supabaseUrl } from "@/lib/config/env"

let cached: SupabaseClient | null = null

/**
 * Service-role client. It BYPASSES Row Level Security, so it is only used by
 * trusted server code that has already authorised the caller itself:
 *   - guest/customer cart operations (ownership proven by cookie or auth uid)
 *   - the place_order() transaction
 *   - server-side coupon and bouquet pricing
 * It must never be imported from a Client Component.
 */
export function createAdminClient(): SupabaseClient {
	if (cached) return cached
	cached = createSupabaseClient(supabaseUrl(), supabaseServiceRoleKey(), {
		auth: { autoRefreshToken: false, persistSession: false },
		global: { headers: { "x-application-name": "wrody-server" } },
	})
	return cached
}
