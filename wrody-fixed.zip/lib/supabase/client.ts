"use client"

import { createBrowserClient } from "@supabase/ssr"
import { supabaseAnonKey, supabaseUrl } from "@/lib/config/env"

/** Browser client — anon key only, always constrained by RLS. */
export function createClient() {
	return createBrowserClient(supabaseUrl(), supabaseAnonKey())
}
