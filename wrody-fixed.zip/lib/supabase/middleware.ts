import { createServerClient } from "@supabase/ssr"
import { NextResponse, type NextRequest } from "next/server"
import { supabaseAnonKey, supabaseUrl } from "@/lib/config/env"

/** Refreshes the Supabase session cookie on every matched request. */
export async function updateSession(request: NextRequest) {
	let response = NextResponse.next({ request })

	const supabase = createServerClient(supabaseUrl(), supabaseAnonKey(), {
		cookies: {
			getAll() {
				return request.cookies.getAll()
			},
			setAll(cookiesToSet) {
				for (const { name, value } of cookiesToSet) request.cookies.set(name, value)
				response = NextResponse.next({ request })
				for (const { name, value, options } of cookiesToSet) {
					response.cookies.set(name, value, options)
				}
			},
		},
	})

	// getUser() revalidates the JWT with Supabase — never trust getSession() here.
	const {
		data: { user },
	} = await supabase.auth.getUser()

	return { response, supabase, user }
}
