import "server-only"

import { publicEnv, serverEnv } from "@/lib/config/env"
import type { PaymentMethod } from "@/types"

/**
 * Payment abstraction
 * -------------------
 * Checkout never talks to a gateway directly: it asks the registry for the
 * enabled providers and calls `initiate()` after the order row exists. Adding
 * Paymob / Stripe / Fawry therefore means implementing one object below — the
 * checkout UI, validation and order RPC stay untouched.
 *
 * There is deliberately NO fake "payment succeeded" path. Cash on delivery
 * leaves payment_status = 'pending' until an admin marks the money received.
 */

export type PaymentInitiation =
	| { kind: "no_action_required" }
	| { kind: "redirect"; url: string }
	| { kind: "unavailable"; reason: string }

export type PaymentContext = {
	orderId: string
	orderNumber: string
	amount: number
	customerName: string
	customerPhone: string
	customerEmail?: string | null
}

export type PaymentProviderMeta = {
	id: PaymentMethod
	label: string
	description: string
	enabled: boolean
	note?: string
}

export type PaymentProvider = PaymentProviderMeta & {
	initiate: (context: PaymentContext) => Promise<PaymentInitiation>
}

const cashOnDelivery: PaymentProvider = {
	id: "cod",
	label: "الدفع عند الاستلام",
	description: "تدفع نقديًا لمندوب التوصيل وقت الاستلام.",
	enabled: true,
	async initiate() {
		// Nothing to charge online; the order stays payment_status = 'pending'.
		return { kind: "no_action_required" }
	},
}

/**
 * TODO(payment-gateway): implement a real provider.
 * 1. Set PAYMENT_GATEWAY=paymob and NEXT_PUBLIC_ENABLE_ONLINE_PAYMENT=true
 * 2. Add PAYMOB_API_KEY / PAYMOB_INTEGRATION_ID / PAYMOB_HMAC_SECRET
 * 3. Replace `initiate` with the real order-registration + payment-key calls
 *    and return { kind: "redirect", url: iframeUrl }
 * 4. Add app/api/payments/paymob/webhook/route.ts which verifies the HMAC and
 *    calls the set_payment_status RPC with the service-role client.
 * Until then this provider reports itself as unavailable rather than pretending.
 */
const onlineCard: PaymentProvider = {
	id: "card",
	label: "بطاقة بنكية / محفظة",
	description: "الدفع أونلاين بشكل آمن.",
	enabled:
		publicEnv.onlinePaymentEnabled &&
		serverEnv.paymentGateway !== "none" &&
		Boolean(process.env.PAYMOB_API_KEY),
	note: "يتطلب إعداد بوابة دفع حقيقية.",
	async initiate() {
		return {
			kind: "unavailable",
			reason: "بوابة الدفع الأونلاين مش مفعلة حاليًا.",
		}
	},
}

const providers: PaymentProvider[] = [cashOnDelivery, onlineCard]

export function getPaymentProvider(id: PaymentMethod): PaymentProvider | null {
	return providers.find((provider) => provider.id === id) ?? null
}

/** Serialisable metadata for the checkout UI (Client Component safe). */
export function listEnabledPaymentMethods(): PaymentProviderMeta[] {
	return providers
		.filter((provider) => provider.enabled)
		.map(({ id, label, description, enabled, note }) => ({ id, label, description, enabled, note }))
}

export function isPaymentMethodEnabled(id: PaymentMethod): boolean {
	return getPaymentProvider(id)?.enabled === true
}
