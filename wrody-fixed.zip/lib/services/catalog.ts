import "server-only"

import { cache } from "react"
import { PRODUCTS_PER_PAGE } from "@/lib/config/site"
import { createClient } from "@/lib/supabase/server"
import { sanitizeSearchTerm } from "@/lib/utils/slug"
import type {
	Category,
	ProductCardData,
	ProductVariant,
	ProductWithRelations,
	Review,
	VariantOptionGroup,
} from "@/types"

/** Only the columns a product card actually renders — keeps payloads small. */
const CARD_SELECT = `
	id, category_id, name, slug, short_description, price, compare_at_price, stock,
	is_active, is_featured, is_best_seller, sales_count, rating_avg, rating_count, created_at,
	category:categories(name, slug),
	images:product_images(image_url, alt_text)
` as const

export type SortKey = "newest" | "price_asc" | "price_desc" | "best_selling" | "featured"

export type ShopFilters = {
	q?: string
	category?: string
	minPrice?: number
	maxPrice?: number
	sort?: SortKey
	inStock?: boolean
	featured?: boolean
	bestSeller?: boolean
	page?: number
	perPage?: number
}

export const getCategories = cache(async (): Promise<Category[]> => {
	const supabase = await createClient()
	const { data } = await supabase
		.from("categories")
		.select("id, name, slug, description, image_url, sort_order, is_active")
		.eq("is_active", true)
		.order("sort_order")
		.returns<Category[]>()
	return data ?? []
})

/** Paginated, filtered, sorted catalogue query — one round trip including count. */
export async function getProducts(filters: ShopFilters = {}): Promise<{
	products: ProductCardData[]
	total: number
	page: number
	perPage: number
	totalPages: number
}> {
	const supabase = await createClient()
	const perPage = filters.perPage ?? PRODUCTS_PER_PAGE
	const page = Math.max(1, filters.page ?? 1)
	const from = (page - 1) * perPage

	let query = supabase
		.from("products")
		.select(filters.category ? CARD_SELECT.replace("category:categories(", "category:categories!inner(") : CARD_SELECT, {
			count: "exact",
		})
		.eq("is_active", true)

	if (filters.category) query = query.eq("category.slug", filters.category)
	if (filters.featured) query = query.eq("is_featured", true)
	if (filters.bestSeller) query = query.eq("is_best_seller", true)
	if (filters.inStock) query = query.gt("stock", 0)
	if (typeof filters.minPrice === "number") query = query.gte("price", filters.minPrice)
	if (typeof filters.maxPrice === "number") query = query.lte("price", filters.maxPrice)

	const term = filters.q ? sanitizeSearchTerm(filters.q) : ""
	if (term) {
		query = query.or(
			`name.ilike.%${term}%,short_description.ilike.%${term}%,description.ilike.%${term}%`,
		)
	}

	switch (filters.sort) {
		case "price_asc":
			query = query.order("price", { ascending: true })
			break
		case "price_desc":
			query = query.order("price", { ascending: false })
			break
		case "best_selling":
			query = query.order("sales_count", { ascending: false })
			break
		case "featured":
			query = query.order("is_featured", { ascending: false }).order("sales_count", { ascending: false })
			break
		default:
			query = query.order("created_at", { ascending: false })
	}

	const { data, count } = await query
		.order("sort_order", { referencedTable: "product_images", ascending: true })
		.limit(2, { referencedTable: "product_images" })
		.range(from, from + perPage - 1)
		.returns<ProductCardData[]>()

	const total = count ?? 0
	return {
		products: data ?? [],
		total,
		page,
		perPage,
		totalPages: Math.max(1, Math.ceil(total / perPage)),
	}
}

async function getProductList(
	column: "is_featured" | "is_best_seller",
	limit: number,
): Promise<ProductCardData[]> {
	const supabase = await createClient()
	const { data } = await supabase
		.from("products")
		.select(CARD_SELECT)
		.eq("is_active", true)
		.eq(column, true)
		.order(column === "is_best_seller" ? "sales_count" : "created_at", { ascending: false })
		.order("sort_order", { referencedTable: "product_images", ascending: true })
		.limit(2, { referencedTable: "product_images" })
		.limit(limit)
		.returns<ProductCardData[]>()
	return data ?? []
}

export const getFeaturedProducts = cache((limit = 4) => getProductList("is_featured", limit))
export const getBestSellers = cache((limit = 8) => getProductList("is_best_seller", limit))

export const getProductBySlug = cache(async (slug: string): Promise<ProductWithRelations | null> => {
	const supabase = await createClient()
	const { data } = await supabase
		.from("products")
		.select(
			`id, category_id, name, slug, description, short_description, price, compare_at_price,
			 stock, sku, is_active, is_featured, is_best_seller, sales_count, rating_avg, rating_count,
			 created_at, updated_at,
			 category:categories(id, name, slug),
			 images:product_images(id, image_url, alt_text, sort_order),
			 variants:product_variants(id, name, options, sku, price, stock, sort_order, is_active)`,
		)
		.eq("slug", slug)
		.eq("is_active", true)
		.order("sort_order", { referencedTable: "product_images", ascending: true })
		.order("sort_order", { referencedTable: "product_variants", ascending: true })
		.maybeSingle<ProductWithRelations>()

	if (!data) return null
	return { ...data, variants: (data.variants ?? []).filter((variant) => variant.is_active) }
})

export async function getRelatedProducts(
	productId: string,
	categoryId: string | null,
	limit = 4,
): Promise<ProductCardData[]> {
	const supabase = await createClient()
	let query = supabase
		.from("products")
		.select(CARD_SELECT)
		.eq("is_active", true)
		.neq("id", productId)

	if (categoryId) query = query.eq("category_id", categoryId)

	const { data } = await query
		.order("sales_count", { ascending: false })
		.order("sort_order", { referencedTable: "product_images", ascending: true })
		.limit(1, { referencedTable: "product_images" })
		.limit(limit)
		.returns<ProductCardData[]>()

	return data ?? []
}

export async function getProductReviews(productId: string): Promise<Review[]> {
	const supabase = await createClient()
	const { data } = await supabase
		.from("reviews")
		.select("id, user_id, product_id, order_id, rating, comment, is_approved, created_at, author:profiles(full_name, avatar_url)")
		.eq("product_id", productId)
		.eq("is_approved", true)
		.order("created_at", { ascending: false })
		.limit(20)
		.returns<Review[]>()
	return data ?? []
}

/** Homepage testimonials: highest rated approved reviews across the catalogue. */
export const getTestimonials = cache(async (limit = 6): Promise<Review[]> => {
	const supabase = await createClient()
	const { data } = await supabase
		.from("reviews")
		.select("id, user_id, product_id, order_id, rating, comment, is_approved, created_at, author:profiles(full_name, avatar_url), product:products(name, slug)")
		.eq("is_approved", true)
		.gte("rating", 4)
		.not("comment", "is", null)
		.order("created_at", { ascending: false })
		.limit(limit)
		.returns<Review[]>()
	return data ?? []
})

/**
 * Variant option groups are derived from the variants themselves, so the
 * database keeps a single source of truth (no parallel attribute tables).
 */
export function buildVariantOptionGroups(variants: ProductVariant[]): VariantOptionGroup[] {
	const groups = new Map<string, Set<string>>()
	for (const variant of variants) {
		for (const [key, value] of Object.entries(variant.options ?? {})) {
			if (!value) continue
			if (!groups.has(key)) groups.set(key, new Set())
			groups.get(key)?.add(value)
		}
	}
	return Array.from(groups.entries()).map(([name, values]) => ({ name, values: Array.from(values) }))
}

export async function getSitemapProducts() {
	const supabase = await createClient()
	const { data } = await supabase
		.from("products")
		.select("slug, updated_at")
		.eq("is_active", true)
		.order("updated_at", { ascending: false })
		.limit(5000)
		.returns<Array<{ slug: string; updated_at: string }>>()
	return data ?? []
}
