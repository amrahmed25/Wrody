import "server-only"

import { createClient } from "@/lib/supabase/server"
import { sanitizeSearchTerm } from "@/lib/utils/slug"
import type {
	AdminCustomerRow,
	Category,
	Coupon,
	DashboardStats,
	Order,
	OrderStatus,
	OrderWithItems,
	PaymentStatus,
	Product,
	ProductWithRelations,
	Review,
} from "@/types"

/**
 * Every function here uses the user-session client, so Row Level Security is
 * the enforcement layer: a non-admin session simply sees nothing. The route
 * guards (middleware + requireAdmin) are defence in depth on top of that.
 */

export async function getDashboardStats(days = 30): Promise<DashboardStats | null> {
	const supabase = await createClient()
	const { data, error } = await supabase.rpc("admin_dashboard_stats", { p_days: days })
	if (error) return null
	return data as DashboardStats
}

export async function listAdminProducts(filters: {
	q?: string
	categoryId?: string
	status?: "active" | "inactive" | "low_stock"
	page?: number
}): Promise<{ products: Array<Product & { category: { name: string } | null }>; total: number; page: number; totalPages: number }> {
	const supabase = await createClient()
	const perPage = 20
	const page = Math.max(1, filters.page ?? 1)
	const from = (page - 1) * perPage

	let query = supabase
		.from("products")
		.select(
			`id, category_id, name, slug, price, compare_at_price, stock, sku, is_active, is_featured,
			 is_best_seller, sales_count, rating_avg, rating_count, created_at,
			 category:categories(name)`,
			{ count: "exact" },
		)

	const term = filters.q ? sanitizeSearchTerm(filters.q) : ""
	if (term) query = query.or(`name.ilike.%${term}%,sku.ilike.%${term}%`)
	if (filters.categoryId) query = query.eq("category_id", filters.categoryId)
	if (filters.status === "active") query = query.eq("is_active", true)
	if (filters.status === "inactive") query = query.eq("is_active", false)
	if (filters.status === "low_stock") query = query.lte("stock", 5)

	const { data, count } = await query
		.order("created_at", { ascending: false })
		.range(from, from + perPage - 1)
		.returns<Array<Product & { category: { name: string } | null }>>()

	return {
		products: data ?? [],
		total: count ?? 0,
		page,
		totalPages: Math.max(1, Math.ceil((count ?? 0) / perPage)),
	}
}

export async function getAdminProduct(id: string): Promise<ProductWithRelations | null> {
	const supabase = await createClient()
	const { data } = await supabase
		.from("products")
		.select(
			`id, category_id, name, slug, description, short_description, price, compare_at_price, stock,
			 sku, is_active, is_featured, is_best_seller, sales_count, rating_avg, rating_count, created_at,
			 category:categories(id, name, slug),
			 images:product_images(id, image_url, alt_text, sort_order),
			 variants:product_variants(id, name, options, sku, price, stock, sort_order, is_active)`,
		)
		.eq("id", id)
		.order("sort_order", { referencedTable: "product_images", ascending: true })
		.order("sort_order", { referencedTable: "product_variants", ascending: true })
		.maybeSingle<ProductWithRelations>()
	return data ?? null
}

export async function listAdminCategories(): Promise<Array<Category & { products_count?: number }>> {
	const supabase = await createClient()
	const { data } = await supabase
		.from("categories")
		.select("id, name, slug, description, image_url, sort_order, is_active, products:products(count)")
		.order("sort_order")
		.returns<Array<Category & { products: Array<{ count: number }> }>>()

	return (data ?? []).map((row) => ({
		...row,
		products_count: row.products?.[0]?.count ?? 0,
	}))
}

export async function listAdminOrders(filters: {
	q?: string
	status?: OrderStatus
	paymentStatus?: PaymentStatus
	page?: number
}): Promise<{ orders: Order[]; total: number; page: number; totalPages: number }> {
	const supabase = await createClient()
	const perPage = 20
	const page = Math.max(1, filters.page ?? 1)
	const from = (page - 1) * perPage

	let query = supabase
		.from("orders")
		.select(
			`id, order_number, user_id, status, payment_method, payment_status, subtotal, delivery_fee,
			 discount, total, coupon_code, customer_name, customer_phone, customer_email,
			 shipping_address_snapshot, notes, created_at`,
			{ count: "exact" },
		)

	const term = filters.q ? sanitizeSearchTerm(filters.q) : ""
	if (term) {
		query = query.or(
			`order_number.ilike.%${term}%,customer_name.ilike.%${term}%,customer_phone.ilike.%${term}%`,
		)
	}
	if (filters.status) query = query.eq("status", filters.status)
	if (filters.paymentStatus) query = query.eq("payment_status", filters.paymentStatus)

	const { data, count } = await query
		.order("created_at", { ascending: false })
		.range(from, from + perPage - 1)
		.returns<Order[]>()

	return {
		orders: data ?? [],
		total: count ?? 0,
		page,
		totalPages: Math.max(1, Math.ceil((count ?? 0) / perPage)),
	}
}

export async function getAdminOrder(id: string): Promise<OrderWithItems | null> {
	const supabase = await createClient()
	const { data } = await supabase
		.from("orders")
		.select(
			`id, order_number, user_id, status, payment_method, payment_status, subtotal, delivery_fee,
			 discount, total, coupon_code, customer_name, customer_phone, customer_email,
			 shipping_address_snapshot, notes, created_at, updated_at,
			 items:order_items(id, product_id, variant_id, custom_bouquet_id, product_name, variant_name,
				image_url, custom_bouquet, quantity, unit_price, total_price),
			 events:order_events(id, status, note, created_at)`,
		)
		.eq("id", id)
		.order("created_at", { referencedTable: "order_events", ascending: true })
		.maybeSingle<OrderWithItems>()
	return data ?? null
}

export async function listAdminCustomers(q?: string, page = 1) {
	const supabase = await createClient()
	const perPage = 20
	const { data, error } = await supabase.rpc("admin_customers", {
		p_search: q ? sanitizeSearchTerm(q) : null,
		p_limit: perPage,
		p_offset: (Math.max(1, page) - 1) * perPage,
	})
	if (error) return { customers: [] as AdminCustomerRow[], page, perPage }
	return { customers: (data ?? []) as AdminCustomerRow[], page, perPage }
}

export async function listAdminCoupons(): Promise<Coupon[]> {
	const supabase = await createClient()
	const { data } = await supabase
		.from("coupons")
		.select(
			`id, code, description, discount_type, discount_value, minimum_order, maximum_discount,
			 usage_limit, usage_limit_per_user, usage_count, starts_at, expires_at, is_active`,
		)
		.order("created_at", { ascending: false })
		.returns<Coupon[]>()
	return data ?? []
}

export async function listAdminReviews(status: "pending" | "approved" | "all" = "pending"): Promise<Review[]> {
	const supabase = await createClient()
	let query = supabase
		.from("reviews")
		.select(
			`id, user_id, product_id, order_id, rating, comment, is_approved, created_at,
			 author:profiles(full_name, avatar_url),
			 product:products(name, slug)`,
		)

	if (status === "pending") query = query.eq("is_approved", false)
	if (status === "approved") query = query.eq("is_approved", true)

	const { data } = await query.order("created_at", { ascending: false }).limit(100).returns<Review[]>()
	return data ?? []
}

export async function listAdminBouquets(status?: string) {
	const supabase = await createClient()
	let query = supabase
		.from("custom_bouquets")
		.select(
			`id, user_id, size_slug, wrapping_slug, card_slug, message, items, breakdown, total_price,
			 status, order_id, created_at,
			 customer:profiles(full_name, phone),
			 order:orders(order_number, status, customer_name, customer_phone)`,
		)
		.not("status", "eq", "draft")

	if (status && status !== "all") query = query.eq("status", status)

	const { data } = await query.order("created_at", { ascending: false }).limit(100)
	return data ?? []
}

export async function getAdminSettings(): Promise<Record<string, unknown>> {
	const supabase = await createClient()
	const { data } = await supabase.from("site_settings").select("key, value")
	const map: Record<string, unknown> = {}
	for (const row of data ?? []) map[(row as { key: string }).key] = (row as { value: unknown }).value
	return map
}

export type AdminDeliveryZone = {
	id: string
	city: string
	fee: number
	estimated_days: string | null
	is_active: boolean
}

/** Admin view of delivery zones — includes inactive ones, unlike the storefront query. */
export async function listAdminDeliveryZones(): Promise<AdminDeliveryZone[]> {
	const supabase = await createClient()
	const { data } = await supabase
		.from("delivery_zones")
		.select("id, city, fee, estimated_days, is_active")
		.order("sort_order")
		.returns<AdminDeliveryZone[]>()
	return data ?? []
}
