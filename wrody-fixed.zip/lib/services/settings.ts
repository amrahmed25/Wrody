import "server-only"

import { cache } from "react"
import { createClient } from "@/lib/supabase/server"

export type DeliverySettings = { default_fee: number; free_threshold: number | null }
export type HeroSettings = {
	headline: string
	subheadline: string
	cta: string
	secondary_cta: string
	badge?: string | null
}
export type CtaSettings = { headline: string; body?: string | null }
export type ContactSettings = {
	phone?: string | null
	email?: string | null
	instagram?: string | null
	tiktok?: string | null
	address?: string | null
}
export type GallerySettings = {
	source: string
	note?: string
	items: Array<{ image: string; caption: string }>
}

const DEFAULTS = {
	"store.delivery": { default_fee: 60, free_threshold: 1500 } satisfies DeliverySettings,
	"homepage.hero": {
		headline: "ورد معمول بحب، عشان يفضل معاك.",
		subheadline:
			"بوكيهات ورد هاند ميد من الـPipe Cleaners، مصممة مخصوص عشان كل مناسبة تبقى ذكرى.",
		cta: "تسوق الآن",
		secondary_cta: "اصنع بوكيهك",
		badge: "شغل إيد مصري 100%",
	} satisfies HeroSettings,
	"homepage.cta": {
		headline: "اختار وردك، وخليه يحكي عنك.",
		body: "كل بوكيه بيتلف بإيدينا قبل ما يوصلك.",
	} satisfies CtaSettings,
	"store.contact": {} satisfies ContactSettings,
	"homepage.gallery": { source: "placeholder", items: [] } satisfies GallerySettings,
} as const

/** All settings in one query, memoised per request. */
export const getSettings = cache(async (): Promise<Record<string, unknown>> => {
	const supabase = await createClient()
	const { data } = await supabase.from("site_settings").select("key, value")
	const map: Record<string, unknown> = {}
	for (const row of data ?? []) map[(row as { key: string }).key] = (row as { value: unknown }).value
	return map
})

export async function getSetting<K extends keyof typeof DEFAULTS>(
	key: K,
): Promise<(typeof DEFAULTS)[K]> {
	const settings = await getSettings()
	const value = settings[key]
	if (!value || typeof value !== "object") return DEFAULTS[key]
	return { ...DEFAULTS[key], ...(value as object) } as (typeof DEFAULTS)[K]
}

export async function getDeliverySettings(): Promise<DeliverySettings> {
	return getSetting("store.delivery")
}

export const getDeliveryZones = cache(async () => {
	const supabase = await createClient()
	const { data } = await supabase
		.from("delivery_zones")
		.select("id, city, fee, estimated_days")
		.eq("is_active", true)
		.order("sort_order")
		.returns<Array<{ id: string; city: string; fee: number; estimated_days: string | null }>>()
	return data ?? []
})
