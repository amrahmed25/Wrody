import "server-only"

import { cookies } from "next/headers"
import { GUEST_ORDERS_COOKIE } from "@/lib/config/site"
import { getUser } from "@/lib/auth/session"
import { createAdminClient } from "@/lib/supabase/admin"
import { createClient } from "@/lib/supabase/server"
import type { Order, OrderWithItems } from "@/types"

const ORDER_COLUMNS = `id, order_number, user_id, status, payment_method, payment_status, subtotal,
	delivery_fee, discount, total, coupon_code, customer_name, customer_phone, customer_email,
	shipping_address_snapshot, notes, created_at, updated_at`

const ORDER_WITH_ITEMS = `${ORDER_COLUMNS},
	items:order_items(id, product_id, variant_id, custom_bouquet_id, product_name, variant_name,
		image_url, custom_bouquet, quantity, unit_price, total_price),
	events:order_events(id, status, note, created_at)`

/** Customer's own orders — RLS restricts rows to auth.uid(). */
export async function getMyOrders(): Promise<Order[]> {
	const supabase = await createClient()
	const { data } = await supabase
		.from("orders")
		.select(ORDER_COLUMNS)
		.order("created_at", { ascending: false })
		.limit(50)
		.returns<Order[]>()
	return data ?? []
}

export async function getMyOrderWithItems(orderNumber: string): Promise<OrderWithItems | null> {
	const supabase = await createClient()
	const { data } = await supabase
		.from("orders")
		.select(ORDER_WITH_ITEMS)
		.eq("order_number", orderNumber)
		.order("created_at", { referencedTable: "order_events", ascending: true })
		.maybeSingle<OrderWithItems>()
	return data ?? null
}

/**
 * Guest access to a confirmation page. A guest may only read an order whose
 * number was written into their own httpOnly cookie when it was placed, so
 * order numbers cannot be enumerated.
 */
export async function rememberGuestOrder(orderNumber: string): Promise<void> {
	const store = await cookies()
	const existing = store.get(GUEST_ORDERS_COOKIE)?.value
	let numbers: string[] = []
	try {
		const parsed = existing ? JSON.parse(existing) : []
		if (Array.isArray(parsed)) numbers = parsed.filter((value) => typeof value === "string")
	} catch {
		numbers = []
	}
	if (!numbers.includes(orderNumber)) numbers.unshift(orderNumber)

	store.set(GUEST_ORDERS_COOKIE, JSON.stringify(numbers.slice(0, 10)), {
		httpOnly: true,
		sameSite: "lax",
		secure: process.env.NODE_ENV === "production",
		path: "/",
		maxAge: 60 * 60 * 24 * 60,
	})
}

async function guestOrderNumbers(): Promise<string[]> {
	const store = await cookies()
	const raw = store.get(GUEST_ORDERS_COOKIE)?.value
	if (!raw) return []
	try {
		const parsed = JSON.parse(raw)
		return Array.isArray(parsed) ? parsed.filter((value): value is string => typeof value === "string") : []
	} catch {
		return []
	}
}

/** Used by /order/[orderNumber]: authenticated via RLS, guests via cookie. */
export async function getOrderForViewer(orderNumber: string): Promise<OrderWithItems | null> {
	const user = await getUser()
	if (user) return getMyOrderWithItems(orderNumber)

	const allowed = await guestOrderNumbers()
	if (!allowed.includes(orderNumber)) return null

	const admin = createAdminClient()
	const { data } = await admin
		.from("orders")
		.select(ORDER_WITH_ITEMS)
		.eq("order_number", orderNumber)
		.is("user_id", null)
		.order("created_at", { referencedTable: "order_events", ascending: true })
		.maybeSingle<OrderWithItems>()
	return data ?? null
}

/** Public tracking: order number + the phone used on the order must both match. */
export async function trackOrder(orderNumber: string, phone: string) {
	const admin = createAdminClient()
	const { data, error } = await admin.rpc("track_order", {
		p_order_number: orderNumber,
		p_phone: phone,
	})
	if (error) throw new Error(error.message)
	return data as {
		found: boolean
		order_number?: string
		status?: string
		payment_status?: string
		total?: number
		created_at?: string
		events?: Array<{ status: string; note: string | null; created_at: string }>
	}
}

export type ReviewableItem = {
	orderId: string
	orderNumber: string
	productId: string
	productName: string
	productSlug: string | null
	imageUrl: string | null
	deliveredAt: string
}

/** Delivered products the customer has not reviewed yet. */
export async function getReviewableItems(): Promise<ReviewableItem[]> {
	const user = await getUser()
	if (!user) return []

	const supabase = await createClient()
	const [itemsResult, reviewsResult] = await Promise.all([
		supabase
			.from("order_items")
			.select(
				`id, product_id, product_name, image_url, order_id,
				 order:orders!inner(order_number, status, created_at),
				 product:products(slug)`,
			)
			.eq("order.status", "delivered")
			.not("product_id", "is", null)
			.order("created_at", { ascending: false })
			.limit(60)
			.returns<
				Array<{
					id: string
					product_id: string
					product_name: string
					image_url: string | null
					order_id: string
					order: { order_number: string; status: string; created_at: string }
					product: { slug: string } | null
				}>
			>(),
		supabase.from("reviews").select("product_id").eq("user_id", user.id),
	])

	const reviewed = new Set(
		(reviewsResult.data ?? []).map((row) => (row as { product_id: string }).product_id),
	)
	const seen = new Set<string>()
	const result: ReviewableItem[] = []

	for (const item of itemsResult.data ?? []) {
		if (reviewed.has(item.product_id) || seen.has(item.product_id)) continue
		seen.add(item.product_id)
		result.push({
			orderId: item.order_id,
			orderNumber: item.order.order_number,
			productId: item.product_id,
			productName: item.product_name,
			productSlug: item.product?.slug ?? null,
			imageUrl: item.image_url,
			deliveredAt: item.order.created_at,
		})
	}

	return result
}
