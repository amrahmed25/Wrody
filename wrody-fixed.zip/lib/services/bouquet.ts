import "server-only"

import { cache } from "react"
import { createClient } from "@/lib/supabase/server"
import { createAdminClient } from "@/lib/supabase/admin"
import { getUser } from "@/lib/auth/session"
import { readCartSessionId } from "@/lib/services/cart"
import type { BouquetFlower, BouquetOption, BouquetPriceBreakdown, BouquetSelection } from "@/types"

export type BouquetCatalog = {
	flowers: BouquetFlower[]
	sizes: BouquetOption[]
	wrappings: BouquetOption[]
	cards: BouquetOption[]
}

export const getBouquetCatalog = cache(async (): Promise<BouquetCatalog> => {
	const supabase = await createClient()

	const [flowersResult, optionsResult] = await Promise.all([
		supabase
			.from("bouquet_flowers")
			.select("id, name, slug, color, image_url, unit_price, sort_order")
			.eq("is_active", true)
			.order("sort_order")
			.returns<BouquetFlower[]>(),
		supabase
			.from("bouquet_options")
			.select("id, kind, name, slug, description, price, min_flowers, max_flowers, sort_order")
			.eq("is_active", true)
			.order("sort_order")
			.returns<BouquetOption[]>(),
	])

	const options = optionsResult.data ?? []
	return {
		flowers: flowersResult.data ?? [],
		sizes: options.filter((option) => option.kind === "size"),
		wrappings: options.filter((option) => option.kind === "wrapping"),
		cards: options.filter((option) => option.kind === "card"),
	}
})

/**
 * Authoritative price. The builder shows a live estimate client-side for UX,
 * but this server value is what gets stored and charged.
 */
export async function priceBouquet(input: {
	sizeSlug: string
	wrappingSlug: string
	cardSlug?: string | null
	items: BouquetSelection[]
}): Promise<BouquetPriceBreakdown> {
	const admin = createAdminClient()
	const { data, error } = await admin.rpc("price_custom_bouquet", {
		p_size_slug: input.sizeSlug,
		p_wrapping_slug: input.wrappingSlug,
		p_card_slug: input.cardSlug ?? null,
		p_items: input.items,
	})
	if (error) throw new Error(error.message)
	return data as BouquetPriceBreakdown
}

export async function createCustomBouquet(input: {
	sizeSlug: string
	wrappingSlug: string
	cardSlug?: string | null
	message?: string | null
	items: BouquetSelection[]
}): Promise<{ id: string; breakdown: BouquetPriceBreakdown }> {
	const breakdown = await priceBouquet(input)
	const admin = createAdminClient()
	const user = await getUser()
	const sessionId = user ? null : await readCartSessionId()

	const { data, error } = await admin
		.from("custom_bouquets")
		.insert({
			user_id: user?.id ?? null,
			session_id: sessionId,
			size_slug: input.sizeSlug,
			wrapping_slug: input.wrappingSlug,
			card_slug: input.cardSlug ?? null,
			message: input.message ?? null,
			items: input.items,
			breakdown,
			total_price: breakdown.total,
			status: "draft",
		})
		.select("id")
		.single()

	if (error) throw new Error(error.message)
	return { id: (data as { id: string }).id, breakdown }
}
