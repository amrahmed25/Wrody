import "server-only"

import { createClient } from "@/lib/supabase/server"
import { getUser } from "@/lib/auth/session"
import type { Address, ProductCardData, Review } from "@/types"

export async function getMyAddresses(): Promise<Address[]> {
	const supabase = await createClient()
	const { data } = await supabase
		.from("addresses")
		.select(
			"id, user_id, full_name, phone, city, area, street, building, floor, apartment, additional_info, is_default",
		)
		.order("is_default", { ascending: false })
		.order("created_at", { ascending: false })
		.returns<Address[]>()
	return data ?? []
}

export async function getDefaultAddress(): Promise<Address | null> {
	const addresses = await getMyAddresses()
	return addresses.find((address) => address.is_default) ?? addresses[0] ?? null
}

export async function getWishlist(): Promise<ProductCardData[]> {
	const user = await getUser()
	if (!user) return []

	const supabase = await createClient()
	const { data } = await supabase
		.from("wishlist")
		.select(
			`product:products!inner(
				id, category_id, name, slug, short_description, price, compare_at_price, stock,
				is_active, is_featured, is_best_seller, sales_count, rating_avg, rating_count, created_at,
				category:categories(name, slug),
				images:product_images(image_url, alt_text)
			)`,
		)
		.order("created_at", { ascending: false })
		.returns<Array<{ product: ProductCardData }>>()

	return (data ?? []).map((row) => row.product).filter((product) => product?.is_active)
}

export async function getWishlistProductIds(): Promise<Set<string>> {
	const user = await getUser()
	if (!user) return new Set()
	const supabase = await createClient()
	const { data } = await supabase.from("wishlist").select("product_id")
	return new Set((data ?? []).map((row) => (row as { product_id: string }).product_id))
}

export async function isInWishlist(productId: string): Promise<boolean> {
	const user = await getUser()
	if (!user) return false
	const supabase = await createClient()
	const { data } = await supabase
		.from("wishlist")
		.select("id")
		.eq("product_id", productId)
		.maybeSingle()
	return Boolean(data)
}

export async function getMyReviews(): Promise<Review[]> {
	const supabase = await createClient()
	const { data } = await supabase
		.from("reviews")
		.select(
			"id, user_id, product_id, order_id, rating, comment, is_approved, created_at, product:products(name, slug)",
		)
		.order("created_at", { ascending: false })
		.returns<Review[]>()
	return data ?? []
}

/** Custom bouquet requests belonging to the signed-in customer. */
export async function getMyBouquets() {
	const supabase = await createClient()
	const { data } = await supabase
		.from("custom_bouquets")
		.select("id, size_slug, wrapping_slug, card_slug, message, breakdown, total_price, status, order_id, created_at")
		.not("status", "eq", "draft")
		.order("created_at", { ascending: false })
		.limit(20)
	return data ?? []
}
