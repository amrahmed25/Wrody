import "server-only"

import { randomUUID } from "node:crypto"
import { cookies } from "next/headers"
import { hasServiceRoleKey } from "@/lib/config/env"
import { CART_SESSION_COOKIE, COUPON_COOKIE } from "@/lib/config/site"
import { getUser } from "@/lib/auth/session"
import { createAdminClient } from "@/lib/supabase/admin"
import type { BouquetPriceBreakdown, CartLine, CartView } from "@/types"

const COOKIE_MAX_AGE = 60 * 60 * 24 * 30
const MAX_QUANTITY = 99

/**
 * Cart ownership model
 * --------------------
 * A cart belongs either to an authenticated user (carts.user_id) or to an
 * anonymous visitor identified by an httpOnly cookie (carts.session_id).
 * Because ownership is proven here, cart mutations run through the service
 * role client; the tables themselves are unreachable for anon/authenticated.
 */

type CartItemRow = {
	id: string
	quantity: number
	product_id: string | null
	variant_id: string | null
	custom_bouquet_id: string | null
	product: {
		id: string
		name: string
		slug: string
		price: number
		stock: number
		is_active: boolean
		images: Array<{ image_url: string; sort_order: number }>
	} | null
	variant: { id: string; name: string; price: number | null; stock: number; is_active: boolean } | null
	bouquet: {
		id: string
		total_price: number
		breakdown: BouquetPriceBreakdown
		message: string | null
	} | null
}

export async function readCartSessionId(): Promise<string | null> {
	const store = await cookies()
	return store.get(CART_SESSION_COOKIE)?.value ?? null
}

/** Only callable from a Server Action or Route Handler (writes a cookie). */
export async function ensureCartSessionId(): Promise<string> {
	const store = await cookies()
	const existing = store.get(CART_SESSION_COOKIE)?.value
	if (existing) return existing

	const sessionId = randomUUID()
	store.set(CART_SESSION_COOKIE, sessionId, {
		httpOnly: true,
		sameSite: "lax",
		secure: process.env.NODE_ENV === "production",
		path: "/",
		maxAge: COOKIE_MAX_AGE,
	})
	return sessionId
}

async function insertCart(payload: { user_id?: string; session_id?: string }): Promise<string | null> {
	const admin = createAdminClient()
	const { data, error } = await admin.from("carts").insert(payload).select("id").single()
	if (!error) return (data as { id: string }).id

	// Unique violation: another concurrent request created it first.
	const { data: existing } = await admin
		.from("carts")
		.select("id")
		.match(payload)
		.maybeSingle()
	return (existing as { id: string } | null)?.id ?? null
}

/**
 * Resolves the current cart. `create: false` never writes (safe in RSC),
 * `create: true` may create the cart row and the guest cookie (actions only).
 */
export async function resolveCartId({ create }: { create: boolean }): Promise<string | null> {
	const admin = createAdminClient()
	const user = await getUser()

	if (user) {
		const { data } = await admin.from("carts").select("id").eq("user_id", user.id).maybeSingle()
		if (data) return (data as { id: string }).id
		if (!create) return null
		return insertCart({ user_id: user.id })
	}

	const sessionId = create ? await ensureCartSessionId() : await readCartSessionId()
	if (!sessionId) return null

	const { data } = await admin.from("carts").select("id").eq("session_id", sessionId).maybeSingle()
	if (data) return (data as { id: string }).id
	if (!create) return null
	return insertCart({ session_id: sessionId })
}

export async function readCouponCode(): Promise<string | null> {
	const store = await cookies()
	const code = store.get(COUPON_COOKIE)?.value
	return code ? code.toUpperCase().slice(0, 32) : null
}

export async function writeCouponCode(code: string | null): Promise<void> {
	const store = await cookies()
	if (!code) {
		store.delete(COUPON_COOKIE)
		return
	}
	store.set(COUPON_COOKIE, code, {
		httpOnly: true,
		sameSite: "lax",
		secure: process.env.NODE_ENV === "production",
		path: "/",
		maxAge: 60 * 60 * 24 * 7,
	})
}

function lineFromRow(row: CartItemRow): CartLine {
	if (row.bouquet) {
		const unitPrice = Number(row.bouquet.total_price)
		return {
			id: row.id,
			quantity: row.quantity,
			product_id: null,
			variant_id: null,
			custom_bouquet_id: row.bouquet.id,
			name: `بوكيه مخصص — ${row.bouquet.breakdown?.size_name ?? ""}`.trim(),
			slug: null,
			variantName: row.bouquet.breakdown?.wrapping_name ?? null,
			imageUrl: null,
			unitPrice,
			lineTotal: Number((unitPrice * row.quantity).toFixed(2)),
			availableStock: MAX_QUANTITY,
			isAvailable: true,
			bouquet: { ...row.bouquet.breakdown, message: row.bouquet.message },
		}
	}

	const product = row.product
	const variant = row.variant
	const unitPrice = Number(variant?.price ?? product?.price ?? 0)
	const stock = variant ? variant.stock : (product?.stock ?? 0)
	const isAvailable = Boolean(product?.is_active) && (!variant || variant.is_active) && stock > 0
	const image = [...(product?.images ?? [])].sort((a, b) => a.sort_order - b.sort_order)[0]

	return {
		id: row.id,
		quantity: row.quantity,
		product_id: row.product_id,
		variant_id: row.variant_id,
		custom_bouquet_id: null,
		name: product?.name ?? "منتج غير متاح",
		slug: product?.slug ?? null,
		variantName: variant?.name ?? null,
		imageUrl: image?.image_url ?? null,
		unitPrice,
		lineTotal: Number((unitPrice * row.quantity).toFixed(2)),
		availableStock: stock,
		isAvailable,
		bouquet: null,
	}
}

function emptyCart(cartId: string | null): CartView {
	return {
		cartId,
		lines: [],
		count: 0,
		totals: {
			subtotal: 0,
			discount: 0,
			deliveryFee: 0,
			total: 0,
			couponCode: null,
			couponMessage: null,
			freeDeliveryThreshold: null,
		},
	}
}

/**
 * Builds the cart view. Every price comes from the database, and the coupon is
 * revalidated on each render so an expired code silently stops applying.
 */
export async function getCart(options: { city?: string | null } = {}): Promise<CartView> {
	if (!hasServiceRoleKey()) return emptyCart(null)

	try {
		return await loadCart(options)
	} catch {
		return emptyCart(null)
	}
}

async function loadCart(options: { city?: string | null } = {}): Promise<CartView> {
	const cartId = await resolveCartId({ create: false })
	if (!cartId) return emptyCart(null)

	const admin = createAdminClient()
	const { data } = await admin
		.from("cart_items")
		.select(
			`id, quantity, product_id, variant_id, custom_bouquet_id,
			 product:products(id, name, slug, price, stock, is_active, images:product_images(image_url, sort_order)),
			 variant:product_variants(id, name, price, stock, is_active),
			 bouquet:custom_bouquets(id, total_price, breakdown, message)`,
		)
		.eq("cart_id", cartId)
		.order("created_at")
		.returns<CartItemRow[]>()

	const lines = (data ?? []).map(lineFromRow)
	if (lines.length === 0) return emptyCart(cartId)

	const subtotal = Number(
		lines.filter((line) => line.isAvailable).reduce((sum, line) => sum + line.lineTotal, 0).toFixed(2),
	)

	let discount = 0
	let couponMessage: string | null = null
	const couponCode = await readCouponCode()

	if (couponCode && subtotal > 0) {
		const user = await getUser()
		const { data: evaluation } = await admin.rpc("evaluate_coupon", {
			p_code: couponCode,
			p_subtotal: subtotal,
			p_user_id: user?.id ?? null,
		})
		const result = evaluation as { valid?: boolean; discount?: number; message?: string } | null
		if (result?.valid) {
			discount = Number(result.discount ?? 0)
			couponMessage = result.message ?? null
		} else {
			couponMessage = result?.message ?? null
		}
	}

	const { data: feeData } = await admin.rpc("delivery_fee_for", {
		p_city: options.city ?? null,
		p_amount: Math.max(subtotal - discount, 0),
	})
	const deliveryFee = Number(feeData ?? 0)

	const { data: settingsRow } = await admin
		.from("site_settings")
		.select("value")
		.eq("key", "store.delivery")
		.maybeSingle()
	const freeThreshold =
		(settingsRow as { value?: { free_threshold?: number } } | null)?.value?.free_threshold ?? null

	return {
		cartId,
		lines,
		count: lines.reduce((sum, line) => sum + line.quantity, 0),
		totals: {
			subtotal,
			discount,
			deliveryFee,
			total: Number(Math.max(subtotal - discount + deliveryFee, 0).toFixed(2)),
			couponCode: discount > 0 ? couponCode : null,
			couponMessage,
			freeDeliveryThreshold: freeThreshold,
		},
	}
}

/** Lightweight badge count for the header (no joins, no pricing). */
export async function getCartCount(): Promise<number> {
	if (!hasServiceRoleKey()) return 0
	try {
		return await loadCartCount()
	} catch {
		return 0
	}
}

async function loadCartCount(): Promise<number> {
	const cartId = await resolveCartId({ create: false })
	if (!cartId) return 0
	const admin = createAdminClient()
	const { data } = await admin.from("cart_items").select("quantity").eq("cart_id", cartId)
	return (data ?? []).reduce((sum, row) => sum + Number((row as { quantity: number }).quantity), 0)
}

export async function addProductToCart(input: {
	productId: string
	variantId?: string | null
	quantity: number
}): Promise<void> {
	const admin = createAdminClient()

	const { data: product } = await admin
		.from("products")
		.select("id, name, stock, is_active")
		.eq("id", input.productId)
		.maybeSingle<{ id: string; name: string; stock: number; is_active: boolean }>()

	if (!product || !product.is_active) throw new Error(`PRODUCT_UNAVAILABLE:${product?.name ?? "منتج"}`)

	let stock = product.stock
	if (input.variantId) {
		const { data: variant } = await admin
			.from("product_variants")
			.select("id, stock, is_active, product_id")
			.eq("id", input.variantId)
			.maybeSingle<{ id: string; stock: number; is_active: boolean; product_id: string }>()

		if (!variant || variant.product_id !== product.id || !variant.is_active) {
			throw new Error(`PRODUCT_UNAVAILABLE:${product.name}`)
		}
		stock = variant.stock
	}

	if (stock <= 0) throw new Error(`OUT_OF_STOCK:${product.name}`)

	const cartId = await resolveCartId({ create: true })
	if (!cartId) throw new Error("CART_NOT_FOUND")

	const { data: existing } = await admin
		.from("cart_items")
		.select("id, quantity")
		.eq("cart_id", cartId)
		.eq("product_id", product.id)
		.is("custom_bouquet_id", null)
		[input.variantId ? "eq" : "is"]("variant_id", input.variantId ?? null)
		.maybeSingle<{ id: string; quantity: number }>()

	const requested = (existing?.quantity ?? 0) + input.quantity
	const quantity = Math.min(requested, stock, MAX_QUANTITY)
	if (existing && quantity === existing.quantity && requested > quantity) {
		throw new Error(`OUT_OF_STOCK:${product.name}`)
	}

	if (existing) {
		await admin.from("cart_items").update({ quantity }).eq("id", existing.id)
		return
	}

	const { error } = await admin.from("cart_items").insert({
		cart_id: cartId,
		product_id: product.id,
		variant_id: input.variantId ?? null,
		quantity,
	})
	if (error) throw new Error(error.message)
}

export async function addBouquetToCart(bouquetId: string): Promise<void> {
	const admin = createAdminClient()
	const cartId = await resolveCartId({ create: true })
	if (!cartId) throw new Error("CART_NOT_FOUND")

	const { error } = await admin.from("cart_items").insert({
		cart_id: cartId,
		custom_bouquet_id: bouquetId,
		quantity: 1,
	})
	if (error) throw new Error(error.message)
	await admin.from("custom_bouquets").update({ status: "in_cart" }).eq("id", bouquetId)
}

/** Ownership is re-checked against the caller's cart before any mutation. */
async function assertItemInCart(itemId: string): Promise<{ cartId: string }> {
	const cartId = await resolveCartId({ create: false })
	if (!cartId) throw new Error("CART_NOT_FOUND")

	const admin = createAdminClient()
	const { data } = await admin
		.from("cart_items")
		.select("id")
		.eq("id", itemId)
		.eq("cart_id", cartId)
		.maybeSingle()

	if (!data) throw new Error("CART_FORBIDDEN")
	return { cartId }
}

export async function updateCartItemQuantity(itemId: string, quantity: number): Promise<void> {
	await assertItemInCart(itemId)
	const admin = createAdminClient()

	if (quantity <= 0) {
		await admin.from("cart_items").delete().eq("id", itemId)
		return
	}

	const { data: row } = await admin
		.from("cart_items")
		.select(
			`id, custom_bouquet_id,
			 product:products(name, stock),
			 variant:product_variants(stock)`,
		)
		.eq("id", itemId)
		.maybeSingle<{
			id: string
			custom_bouquet_id: string | null
			product: { name: string; stock: number } | null
			variant: { stock: number } | null
		}>()

	if (!row) throw new Error("CART_FORBIDDEN")

	if (!row.custom_bouquet_id) {
		const stock = row.variant?.stock ?? row.product?.stock ?? 0
		if (quantity > stock) throw new Error(`OUT_OF_STOCK:${row.product?.name ?? "المنتج"}`)
	}

	await admin.from("cart_items").update({ quantity: Math.min(quantity, MAX_QUANTITY) }).eq("id", itemId)
}

export async function removeCartItem(itemId: string): Promise<void> {
	await assertItemInCart(itemId)
	const admin = createAdminClient()
	await admin.from("cart_items").delete().eq("id", itemId)
}

/** Called right after a successful sign-in / sign-up. */
export async function mergeGuestCart(userId: string): Promise<void> {
	const sessionId = await readCartSessionId()
	if (!sessionId) return

	const admin = createAdminClient()
	await admin.rpc("merge_guest_cart", { p_user_id: userId, p_session_id: sessionId })

	const store = await cookies()
	store.delete(CART_SESSION_COOKIE)
}
