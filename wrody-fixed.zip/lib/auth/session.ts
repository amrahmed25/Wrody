import "server-only"

import { cache } from "react"
import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import type { Profile } from "@/types"

export const getUser = cache(async () => {
	const supabase = await createClient()
	const {
		data: { user },
	} = await supabase.auth.getUser()
	return user
})

export const getProfile = cache(async (): Promise<Profile | null> => {
	const user = await getUser()
	if (!user) return null

	const supabase = await createClient()
	const { data } = await supabase
		.from("profiles")
		.select("id, full_name, email, phone, avatar_url, role, created_at, updated_at")
		.eq("id", user.id)
		.maybeSingle<Profile>()

	return data ?? null
})

export async function isAdmin(): Promise<boolean> {
	const profile = await getProfile()
	return profile?.role === "admin"
}

/** Server Components / route handlers: guarantee an authenticated customer. */
export async function requireUser() {
	const user = await getUser()
	if (!user) redirect("/login")
	return user
}

/** Second authorisation gate for /admin (middleware is the first). */
export async function requireAdmin(): Promise<Profile> {
	const profile = await getProfile()
	if (!profile) redirect("/login?next=/admin")
	if (profile.role !== "admin") redirect("/unauthorized")
	return profile
}

/** Server actions: returns null instead of redirecting so we can reply with a result. */
export async function currentAdmin(): Promise<Profile | null> {
	const profile = await getProfile()
	return profile?.role === "admin" ? profile : null
}
