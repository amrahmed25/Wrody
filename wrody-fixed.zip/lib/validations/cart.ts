import { z } from "zod"
import { quantitySchema, uuidSchema } from "@/lib/validations/common"

export const addToCartSchema = z.object({
	productId: uuidSchema,
	variantId: uuidSchema.optional().nullable(),
	quantity: quantitySchema.default(1),
})

export const updateCartItemSchema = z.object({
	itemId: uuidSchema,
	quantity: z.coerce.number().int().min(0).max(99),
})

export const removeCartItemSchema = z.object({ itemId: uuidSchema })

export const couponSchema = z.object({
	code: z
		.string()
		.trim()
		.toUpperCase()
		.min(3, "كود الخصم قصير أوي")
		.max(32, "كود الخصم طويل أوي")
		.regex(/^[A-Z0-9_-]+$/, "كود الخصم غير صالح"),
})

export const wishlistSchema = z.object({ productId: uuidSchema })
