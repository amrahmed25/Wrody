import { z } from "zod"

const slug = z
	.string()
	.trim()
	.min(1)
	.max(40)
	.regex(/^[a-z0-9-]+$/, "اختيار غير صالح")

export const bouquetSchema = z.object({
	sizeSlug: slug,
	wrappingSlug: slug,
	cardSlug: slug.optional().nullable(),
	message: z
		.string()
		.trim()
		.max(300, "الرسالة أطول من ٣٠٠ حرف")
		.optional()
		.or(z.literal(""))
		.transform((value) => (value ? value : null)),
	items: z
		.array(
			z.object({
				slug,
				quantity: z.coerce.number().int().min(1, "أقل عدد ١").max(50, "أقصى عدد ٥٠"),
			}),
		)
		.min(1, "اختر نوع ورد واحد على الأقل")
		.max(8, "أقصى ٨ أنواع ورد في البوكيه الواحد")
		.superRefine((items, ctx) => {
			const seen = new Set<string>()
			for (const item of items) {
				if (seen.has(item.slug)) {
					ctx.addIssue({ code: z.ZodIssueCode.custom, message: "فيه نوع ورد مكرر" })
					return
				}
				seen.add(item.slug)
			}
		}),
})

export type BouquetInput = z.infer<typeof bouquetSchema>
