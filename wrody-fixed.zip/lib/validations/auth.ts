import { z } from "zod"
import { emailSchema, nameSchema, passwordSchema, phoneSchema } from "@/lib/validations/common"

export const registerSchema = z
	.object({
		fullName: nameSchema,
		email: emailSchema,
		phone: phoneSchema,
		password: passwordSchema,
		confirmPassword: z.string(),
		next: z.string().trim().max(200).optional(),
	})
	.refine((data) => data.password === data.confirmPassword, {
		message: "كلمتا المرور مش متطابقتين",
		path: ["confirmPassword"],
	})

export const loginSchema = z.object({
	email: emailSchema,
	password: z.string().min(1, "اكتب كلمة المرور"),
	next: z.string().trim().max(200).optional(),
})

export const resetRequestSchema = z.object({ email: emailSchema })

export const updatePasswordSchema = z
	.object({
		password: passwordSchema,
		confirmPassword: z.string(),
	})
	.refine((data) => data.password === data.confirmPassword, {
		message: "كلمتا المرور مش متطابقتين",
		path: ["confirmPassword"],
	})

export const profileSchema = z.object({
	fullName: nameSchema,
	phone: phoneSchema,
})

export type RegisterInput = z.infer<typeof registerSchema>
export type LoginInput = z.infer<typeof loginSchema>
