import { z } from "zod"

export const uuidSchema = z.string().uuid("معرّف غير صالح")

/** Egyptian mobile numbers, with or without the country code. */
export const phoneSchema = z
	.string()
	.trim()
	.regex(/^(?:\+?20)?0?1[0125][0-9]{8}$/, "رقم الموبايل غير صحيح (مثال: 01012345678)")

export const nameSchema = z
	.string()
	.trim()
	.min(3, "الاسم قصير أوي")
	.max(80, "الاسم طويل أوي")

export const emailSchema = z.string().trim().toLowerCase().email("البريد الإلكتروني غير صحيح")

export const passwordSchema = z
	.string()
	.min(8, "كلمة المرور لازم تكون ٨ حروف على الأقل")
	.max(72, "كلمة المرور طويلة أوي")

export const optionalText = (max: number) =>
	z
		.string()
		.trim()
		.max(max, `النص أطول من ${max} حرف`)
		.optional()
		.or(z.literal(""))
		.transform((value) => (value ? value : null))

export const quantitySchema = z.coerce
	.number()
	.int("الكمية لازم تكون رقم صحيح")
	.min(1, "أقل كمية هي ١")
	.max(99, "أقصى كمية هي ٩٩")

export const priceSchema = z.coerce
	.number({ invalid_type_error: "السعر لازم يكون رقم" })
	.min(0, "السعر لازم يكون موجب")
	.max(1000000, "السعر كبير أوي")

export const stockSchema = z.coerce
	.number()
	.int("المخزون لازم يكون رقم صحيح")
	.min(0, "المخزون ماينفعش يكون بالسالب")
	.max(100000)

export const slugSchema = z
	.string()
	.trim()
	.regex(/^[a-z0-9-]+$/, "الرابط لازم يحتوي حروف إنجليزية صغيرة وأرقام وشرطات فقط")
	.min(2)
	.max(60)

export const checkboxSchema = z
	.union([z.boolean(), z.literal("on"), z.literal("true"), z.literal("false"), z.literal("")])
	.optional()
	.transform((value) => value === true || value === "on" || value === "true")

/** Flattens a ZodError into the shape used by ActionResult.fieldErrors. */
export function fieldErrors(error: z.ZodError): Record<string, string[]> {
	return error.flatten().fieldErrors as Record<string, string[]>
}

export function firstError(error: z.ZodError, fallback = "فيه بيانات ناقصة أو غير صحيحة."): string {
	return error.errors[0]?.message ?? fallback
}
