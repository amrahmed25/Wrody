import { z } from "zod"
import {
	checkboxSchema,
	optionalText,
	priceSchema,
	slugSchema,
	stockSchema,
	uuidSchema,
} from "@/lib/validations/common"

export const categoryFormSchema = z.object({
	id: uuidSchema.optional(),
	name: z.string().trim().min(2, "اسم القسم قصير أوي").max(60),
	slug: slugSchema,
	description: optionalText(400),
	imageUrl: optionalText(500),
	sortOrder: z.coerce.number().int().min(0).max(999).default(0),
	isActive: checkboxSchema,
})

export const productFormSchema = z
	.object({
		id: uuidSchema.optional(),
		name: z.string().trim().min(3, "اسم المنتج قصير أوي").max(120),
		slug: slugSchema,
		categoryId: uuidSchema.optional().nullable().or(z.literal("")),
		shortDescription: optionalText(200),
		description: optionalText(4000),
		price: priceSchema,
		compareAtPrice: z
			.union([priceSchema, z.literal("")])
			.optional()
			.transform((value) => (value === "" || value === undefined ? null : Number(value))),
		stock: stockSchema,
		sku: optionalText(40),
		isActive: checkboxSchema,
		isFeatured: checkboxSchema,
		isBestSeller: checkboxSchema,
	})
	.refine(
		(data) => data.compareAtPrice === null || data.compareAtPrice >= data.price,
		{ message: "السعر قبل الخصم لازم يكون أكبر من السعر الحالي", path: ["compareAtPrice"] },
	)

export const variantFormSchema = z.object({
	id: uuidSchema.optional(),
	productId: uuidSchema,
	name: z.string().trim().min(1, "اكتب اسم التنوع").max(80),
	options: z.record(z.string().trim().max(40), z.string().trim().max(60)).default({}),
	sku: optionalText(40),
	price: z
		.union([priceSchema, z.literal("")])
		.optional()
		.transform((value) => (value === "" || value === undefined ? null : Number(value))),
	stock: stockSchema,
	isActive: checkboxSchema,
})

export const productImageSchema = z.object({
	productId: uuidSchema,
	imageUrl: z.string().trim().min(1, "رابط الصورة مطلوب").max(600),
	altText: optionalText(120),
})

export const reorderImagesSchema = z.object({
	productId: uuidSchema,
	orderedIds: z.array(uuidSchema).min(1),
})

export const couponFormSchema = z
	.object({
		id: uuidSchema.optional(),
		code: z
			.string()
			.trim()
			.toUpperCase()
			.min(3)
			.max(32)
			.regex(/^[A-Z0-9_-]+$/, "الكود يحتوي حروف إنجليزية كبيرة وأرقام فقط"),
		description: optionalText(200),
		discountType: z.enum(["percentage", "fixed"]),
		discountValue: z.coerce.number().positive("قيمة الخصم لازم تكون أكبر من صفر"),
		minimumOrder: z.union([z.coerce.number().min(0), z.literal("")]).optional()
			.transform((v) => (v === "" || v === undefined ? null : Number(v))),
		maximumDiscount: z.union([z.coerce.number().min(0), z.literal("")]).optional()
			.transform((v) => (v === "" || v === undefined ? null : Number(v))),
		usageLimit: z.union([z.coerce.number().int().min(1), z.literal("")]).optional()
			.transform((v) => (v === "" || v === undefined ? null : Number(v))),
		usageLimitPerUser: z.union([z.coerce.number().int().min(1), z.literal("")]).optional()
			.transform((v) => (v === "" || v === undefined ? null : Number(v))),
		startsAt: z.string().trim().optional().or(z.literal("")).transform((v) => (v ? v : null)),
		expiresAt: z.string().trim().optional().or(z.literal("")).transform((v) => (v ? v : null)),
		isActive: checkboxSchema,
	})
	.refine((data) => data.discountType !== "percentage" || data.discountValue <= 100, {
		message: "نسبة الخصم ماينفعش تزيد عن ١٠٠%",
		path: ["discountValue"],
	})

export const orderStatusSchema = z.object({
	orderId: uuidSchema,
	status: z.enum(["pending", "confirmed", "preparing", "out_for_delivery", "delivered", "cancelled"]),
	note: optionalText(300),
})

export const paymentStatusSchema = z.object({
	orderId: uuidSchema,
	paymentStatus: z.enum(["pending", "paid", "failed", "refunded"]),
	reference: optionalText(120),
})

export const bouquetStatusSchema = z.object({
	bouquetId: uuidSchema,
	status: z.enum(["ordered", "in_production", "completed", "cancelled"]),
})

export const reviewModerationSchema = z.object({
	reviewId: uuidSchema,
	approve: z.coerce.boolean(),
})

export const settingsSchema = z.object({
	deliveryFee: z.coerce.number().min(0).max(10000),
	freeDeliveryThreshold: z.union([z.coerce.number().min(0), z.literal("")]).optional()
		.transform((v) => (v === "" || v === undefined ? null : Number(v))),
	heroHeadline: z.string().trim().min(4).max(120),
	heroSubheadline: z.string().trim().min(4).max(300),
	heroBadge: optionalText(60),
	ctaHeadline: z.string().trim().min(4).max(120),
	ctaBody: optionalText(300),
	contactPhone: optionalText(30),
	contactEmail: optionalText(80),
	instagram: optionalText(60),
})

export const deliveryZoneSchema = z.object({
	id: uuidSchema.optional(),
	city: z.string().trim().min(2).max(60),
	fee: z.coerce.number().min(0).max(10000),
	estimatedDays: optionalText(40),
	isActive: checkboxSchema,
})
