import { z } from "zod"
import { uuidSchema } from "@/lib/validations/common"

export const reviewSchema = z.object({
	productId: uuidSchema,
	orderId: uuidSchema.optional().nullable(),
	rating: z.coerce.number().int().min(1, "اختر تقييم من ١ ل٥").max(5),
	comment: z
		.string()
		.trim()
		.max(1000, "التعليق طويل أوي")
		.optional()
		.or(z.literal(""))
		.transform((value) => (value ? value : null)),
})
