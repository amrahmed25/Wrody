/**
 * Domain types for Wrody.
 * These mirror the SQL schema in supabase/migrations. Running `npm run db:types`
 * additionally generates `types/supabase.ts` straight from the live database;
 * the hand written types below stay as the app-facing contract so UI code never
 * depends on generated names.
 */

export type UserRole = "customer" | "admin"

export type OrderStatus =
	| "pending"
	| "confirmed"
	| "preparing"
	| "out_for_delivery"
	| "delivered"
	| "cancelled"

export type PaymentStatus = "pending" | "paid" | "failed" | "refunded"
export type PaymentMethod = "cod" | "card" | "wallet"
export type DiscountType = "percentage" | "fixed"
export type CustomBouquetStatus =
	| "draft"
	| "in_cart"
	| "ordered"
	| "in_production"
	| "completed"
	| "cancelled"

export type Profile = {
	id: string
	full_name: string | null
	email: string | null
	phone: string | null
	avatar_url: string | null
	role: UserRole
	created_at: string
	updated_at: string
}

export type Category = {
	id: string
	name: string
	slug: string
	description: string | null
	image_url: string | null
	sort_order: number
	is_active: boolean
}

export type ProductImage = {
	id: string
	product_id?: string
	image_url: string
	alt_text: string | null
	sort_order: number
}

export type ProductVariant = {
	id: string
	product_id?: string
	name: string
	options: Record<string, string>
	sku: string | null
	/** null = inherit the parent product price */
	price: number | null
	stock: number
	sort_order: number
	is_active: boolean
}

export type Product = {
	id: string
	category_id: string | null
	name: string
	slug: string
	description: string | null
	short_description: string | null
	price: number
	compare_at_price: number | null
	stock: number
	sku: string | null
	is_active: boolean
	is_featured: boolean
	is_best_seller: boolean
	sales_count: number
	rating_avg: number
	rating_count: number
	created_at: string
	updated_at?: string
}

export type ProductWithRelations = Product & {
	category: Pick<Category, "id" | "name" | "slug"> | null
	images: ProductImage[]
	variants: ProductVariant[]
}

export type ProductCardData = Product & {
	category: Pick<Category, "name" | "slug"> | null
	images: Pick<ProductImage, "image_url" | "alt_text">[]
}

/** Variant option groups are derived from the variants themselves. */
export type VariantOptionGroup = { name: string; values: string[] }

export type BouquetFlower = {
	id: string
	name: string
	slug: string
	color: string | null
	image_url: string | null
	unit_price: number
	sort_order: number
}

export type BouquetOptionKind = "size" | "wrapping" | "card"

export type BouquetOption = {
	id: string
	kind: BouquetOptionKind
	name: string
	slug: string
	description: string | null
	price: number
	min_flowers: number | null
	max_flowers: number | null
	sort_order: number
}

export type BouquetSelection = { slug: string; quantity: number }

export type BouquetPriceBreakdown = {
	size_slug: string
	size_name: string
	base_price: number
	wrapping_slug: string
	wrapping_name: string
	wrapping_price: number
	card_slug: string | null
	card_name: string | null
	card_price: number
	flowers: Array<{
		slug: string
		name: string
		color: string | null
		quantity: number
		unit_price: number
		total: number
	}>
	flowers_total: number
	flower_count: number
	total: number
	message?: string | null
}

export type CartLine = {
	id: string
	quantity: number
	product_id: string | null
	variant_id: string | null
	custom_bouquet_id: string | null
	name: string
	slug: string | null
	variantName: string | null
	imageUrl: string | null
	unitPrice: number
	lineTotal: number
	availableStock: number
	isAvailable: boolean
	bouquet: BouquetPriceBreakdown | null
}

export type CartTotals = {
	subtotal: number
	discount: number
	deliveryFee: number
	total: number
	couponCode: string | null
	couponMessage: string | null
	freeDeliveryThreshold: number | null
}

export type CartView = {
	cartId: string | null
	lines: CartLine[]
	count: number
	totals: CartTotals
}

export type Address = {
	id: string
	user_id: string
	full_name: string
	phone: string
	city: string
	area: string
	street: string
	building: string | null
	floor: string | null
	apartment: string | null
	additional_info: string | null
	is_default: boolean
}

export type ShippingAddressSnapshot = {
	full_name?: string | null
	phone?: string | null
	city: string
	area?: string | null
	street: string
	building?: string | null
	floor?: string | null
	apartment?: string | null
	additional_info?: string | null
}

export type OrderItem = {
	id: string
	product_id: string | null
	variant_id: string | null
	custom_bouquet_id: string | null
	product_name: string
	variant_name: string | null
	image_url: string | null
	custom_bouquet: BouquetPriceBreakdown | null
	quantity: number
	unit_price: number
	total_price: number
}

export type OrderEvent = {
	id: string
	status: OrderStatus
	note: string | null
	created_at: string
}

export type Order = {
	id: string
	order_number: string
	user_id: string | null
	status: OrderStatus
	payment_method: PaymentMethod
	payment_status: PaymentStatus
	subtotal: number
	delivery_fee: number
	discount: number
	total: number
	coupon_code: string | null
	customer_name: string
	customer_phone: string
	customer_email: string | null
	shipping_address_snapshot: ShippingAddressSnapshot
	notes: string | null
	created_at: string
	updated_at?: string
}

export type OrderWithItems = Order & { items: OrderItem[]; events: OrderEvent[] }

export type Coupon = {
	id: string
	code: string
	description: string | null
	discount_type: DiscountType
	discount_value: number
	minimum_order: number | null
	maximum_discount: number | null
	usage_limit: number | null
	usage_limit_per_user: number | null
	usage_count: number
	starts_at: string | null
	expires_at: string | null
	is_active: boolean
}

export type Review = {
	id: string
	user_id: string
	product_id: string
	order_id: string | null
	rating: number
	comment: string | null
	is_approved: boolean
	created_at: string
	author?: { full_name: string | null; avatar_url: string | null } | null
	product?: { name: string; slug: string } | null
}

export type CustomBouquet = {
	id: string
	user_id: string | null
	size_slug: string
	wrapping_slug: string
	card_slug: string | null
	message: string | null
	items: BouquetSelection[]
	breakdown: BouquetPriceBreakdown
	total_price: number
	status: CustomBouquetStatus
	order_id: string | null
	created_at: string
}

export type DashboardStats = {
	revenue_total: number
	revenue_period: number
	orders_total: number
	orders_pending: number
	orders_delivered: number
	orders_period: number
	customers_total: number
	products_total: number
	bouquets_pending: number
	reviews_pending: number
	avg_order_value: number
	low_stock: Array<{ id: string; name: string; slug: string; stock: number }>
	series: Array<{ date: string; revenue: number; orders: number }>
	top_products: Array<{ name: string; quantity: number; revenue: number }>
	category_performance: Array<{ name: string; revenue: number }>
	recent_orders: Array<{
		id: string
		order_number: string
		customer_name: string
		total: number
		status: OrderStatus
		created_at: string
	}>
}

export type AdminCustomerRow = {
	id: string
	full_name: string | null
	email: string | null
	phone: string | null
	role: UserRole
	created_at: string
	orders_count: number
	total_spent: number
	last_order_at: string | null
}

/** Uniform result contract returned by every server action. */
export type ActionResult<T = undefined> =
	| { ok: true; data?: T; message?: string }
	| { ok: false; error: string; fieldErrors?: Record<string, string[]> }
