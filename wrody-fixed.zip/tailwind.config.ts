import type { Config } from "tailwindcss"

/**
 * Wrody design tokens.
 * Warm cream paper, muted rose, sage green and a deep cocoa ink — a premium
 * handmade-gift palette rather than a florist palette. Nothing is pure white
 * or pure black, which is what makes the UI feel crafted.
 */
const config: Config = {
	content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
	theme: {
		extend: {
			colors: {
				cream: "#FBF7F2",
				ivory: "#FFFCF8",
				sand: { DEFAULT: "#EFE6DA", dark: "#E2D5C5" },
				ink: { DEFAULT: "#2B2320", soft: "#6B5C53", muted: "#9A8B80" },
				rose: {
					50: "#FDF5F6",
					100: "#F9E7EA",
					200: "#F2D0D7",
					300: "#E4AEB9",
					400: "#D4909F",
					500: "#C27B8C",
					600: "#A9647A",
					700: "#8B5064",
					DEFAULT: "#C27B8C",
				},
				sage: {
					50: "#F2F6F2",
					100: "#E4EDE5",
					300: "#B9CDBD",
					500: "#7F9C86",
					700: "#5C7663",
					DEFAULT: "#7F9C86",
				},
				gold: { 100: "#F7EEDF", 500: "#C79A63", DEFAULT: "#C79A63" },
			},
			fontFamily: {
				sans: ["var(--font-body)", "system-ui", "Segoe UI", "sans-serif"],
				display: ["var(--font-display)", "var(--font-body)", "Georgia", "serif"],
			},
			fontSize: {
				"display-lg": ["clamp(2.25rem, 1.4rem + 3.6vw, 4rem)", { lineHeight: "1.1", letterSpacing: "-0.01em" }],
				"display-md": ["clamp(1.75rem, 1.2rem + 2.2vw, 2.75rem)", { lineHeight: "1.18" }],
				"display-sm": ["clamp(1.35rem, 1.1rem + 1vw, 1.85rem)", { lineHeight: "1.3" }],
			},
			maxWidth: { content: "1180px", prose: "68ch" },
			borderRadius: { "4xl": "2rem", "5xl": "2.5rem" },
			boxShadow: {
				soft: "0 1px 2px rgba(43,35,32,.04), 0 8px 24px rgba(43,35,32,.06)",
				lift: "0 12px 40px rgba(43,35,32,.10)",
				inset: "inset 0 1px 0 rgba(255,255,255,.6)",
			},
			screens: { xs: "380px", "3xl": "1600px" },
			transitionTimingFunction: { soft: "cubic-bezier(0.22, 1, 0.36, 1)" },
			keyframes: {
				"fade-in": { from: { opacity: "0" }, to: { opacity: "1" } },
				"fade-up": {
					from: { opacity: "0", transform: "translateY(12px)" },
					to: { opacity: "1", transform: "translateY(0)" },
				},
				"scale-in": {
					from: { opacity: "0", transform: "scale(.97)" },
					to: { opacity: "1", transform: "scale(1)" },
				},
				"slide-up": {
					from: { opacity: "0", transform: "translateY(100%)" },
					to: { opacity: "1", transform: "translateY(0)" },
				},
				"toast-in": {
					from: { opacity: "0", transform: "translateY(10px) scale(.98)" },
					to: { opacity: "1", transform: "translateY(0) scale(1)" },
				},
				/* pipe-cleaner petals opening around the logo */
				bloom: {
					"0%": { opacity: "0", transform: "rotate(var(--petal, 0deg)) scale(.35)" },
					"60%": { opacity: "1", transform: "rotate(var(--petal, 0deg)) scale(1.04)" },
					"100%": { opacity: "1", transform: "rotate(var(--petal, 0deg)) scale(1)" },
				},
				sway: {
					"0%, 100%": { transform: "rotate(-1.5deg)" },
					"50%": { transform: "rotate(1.5deg)" },
				},
				shimmer: { "100%": { transform: "translateX(-100%)" } },
				spin: { to: { transform: "rotate(360deg)" } },
			},
			animation: {
				"fade-in": "fade-in .35s ease-out both",
				"fade-up": "fade-up .45s cubic-bezier(0.22, 1, 0.36, 1) both",
				"scale-in": "scale-in .22s cubic-bezier(0.22, 1, 0.36, 1) both",
				"slide-up": "slide-up .28s cubic-bezier(0.22, 1, 0.36, 1) both",
				"toast-in": "toast-in .22s cubic-bezier(0.22, 1, 0.36, 1) both",
				bloom: "bloom .7s cubic-bezier(0.22, 1, 0.36, 1) both",
				sway: "sway 6s ease-in-out infinite",
				shimmer: "shimmer 1.6s infinite",
			},
			backgroundImage: {
				"paper-grain":
					"radial-gradient(circle at 20% 20%, rgba(194,123,140,.06), transparent 45%), radial-gradient(circle at 80% 0%, rgba(127,156,134,.07), transparent 40%)",
				"rose-fade": "linear-gradient(180deg, #FDF5F6 0%, #FBF7F2 100%)",
			},
		},
	},
	plugins: [],
}

export default config
