/**
 * Generates the lightweight SVG artwork shipped in /public.
 *
 * Every product, category and flower illustration is drawn as a pipe-cleaner
 * (chenille) flower: dashed round strokes imitate the fuzzy wire texture.
 * Run with `npm run art`. Replace these files with real photography before
 * launch — the app reads the same paths either way.
 */
import { mkdirSync, writeFileSync } from "node:fs"
import { dirname, join } from "node:path"
import { fileURLToPath } from "node:url"

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..")
const PUBLIC = join(ROOT, "public")

const CREAM = "#FBF7F2"
const IVORY = "#FFFCF8"
const SAND = "#EFE6DA"
const INK_MUTED = "#9A8B80"
const LEAF = { mid: "#7F9C86", dark: "#5C7663" }

const PALETTES = {
	rose: { mid: "#D4909F", dark: "#A9647A", light: "#F9E7EA", center: "#F0D2A8" },
	tulip: { mid: "#E4AEB9", dark: "#C27B8C", light: "#FDF5F6", center: "#F4D58A" },
	lavender: { mid: "#B3A4CE", dark: "#8477A8", light: "#F1EDF7", center: "#E8D9F2" },
	sunflower: { mid: "#E9C169", dark: "#C79A63", light: "#F7EEDF", center: "#8A6636" },
	daisy: { mid: "#FDFBF6", dark: "#D9CBBB", light: "#FFFDF9", center: "#E9C169" },
	peony: { mid: "#E7B7C3", dark: "#BE8296", light: "#FBEDF0", center: "#F3DCC4" },
	gypsophila: { mid: "#F4EEE6", dark: "#CFC2B3", light: "#FFFDFA", center: "#E4EDE5" },
	sage: { mid: "#A8C0AE", dark: "#5C7663", light: "#E4EDE5", center: "#F7EEDF" },
	kraft: { mid: "#D8BE9B", dark: "#A9865C", light: "#F4E9D9", center: "#8A6636" },
}

const PRODUCTS = {
	"tulip-pink-bouquet": ["tulip", "rose", "peony"],
	"lavender-bouquet": ["lavender", "gypsophila", "sage"],
	"sunflower-bouquet": ["sunflower", "kraft", "sage"],
	"love-bouquet": ["rose", "peony", "tulip"],
	"mini-pink-bouquet": ["tulip", "peony"],
	"pastel-bouquet": ["peony", "lavender", "tulip"],
	"white-daisy-bouquet": ["daisy", "sage", "gypsophila"],
	"single-tulip": ["tulip"],
	"velvet-rose-single": ["rose"],
	"gift-box-small": ["peony", "gypsophila"],
	"gift-box-premium": ["rose", "lavender", "gypsophila"],
	"graduation-bouquet": ["sunflower", "sage", "daisy"],
	"mothers-day-bouquet": ["peony", "rose", "daisy"],
	"everlasting-vase": ["lavender", "sage", "gypsophila"],
	"mini-lavender": ["lavender"],
}

const CATEGORIES = {
	bouquets: ["tulip", "rose", "peony"],
	mini: ["peony", "tulip"],
	"single-flowers": ["rose"],
	"gift-boxes": ["lavender", "gypsophila"],
	occasions: ["sunflower", "daisy"],
	"home-decor": ["sage", "lavender", "gypsophila"],
}

const FLOWERS = ["tulip", "rose", "sunflower", "lavender", "daisy", "peony", "gypsophila"]

function write(relativePath, content) {
	const target = join(PUBLIC, relativePath)
	mkdirSync(dirname(target), { recursive: true })
	writeFileSync(target, `${content.trim()}\n`, "utf8")
}

/** Fuzzy chenille stroke shared by every shape. */
function fuzz(color, width = 3, dash = "1 5") {
	return `stroke="${color}" stroke-width="${width}" stroke-dasharray="${dash}" stroke-linecap="round"`
}

function bloom({ cx, cy, r, palette, petals = 6, rotate = 0 }) {
	const p = PALETTES[palette] ?? PALETTES.tulip
	const parts = []
	for (let i = 0; i < petals; i += 1) {
		const angle = rotate + (360 / petals) * i
		parts.push(
			`<ellipse cx="${cx}" cy="${(cy - r * 0.6).toFixed(1)}" rx="${(r * 0.36).toFixed(1)}" ry="${(r * 0.6).toFixed(1)}" fill="${p.mid}" ${fuzz(p.dark)} transform="rotate(${angle.toFixed(1)} ${cx} ${cy})" />`,
		)
	}
	parts.push(
		`<circle cx="${cx}" cy="${cy}" r="${(r * 0.3).toFixed(1)}" fill="${p.center}" ${fuzz(p.dark, 2.5, "1 4")} />`,
	)
	return parts.join("")
}

function stem({ x, y, toX, toY }) {
	const midX = (x + toX) / 2 + (toX - x) * 0.18
	return `<path d="M ${x} ${y} Q ${midX.toFixed(1)} ${((y + toY) / 2).toFixed(1)} ${toX} ${toY}" fill="none" ${fuzz(LEAF.mid, 6, "2 7")} />`
}

function leaf({ x, y, flip = false }) {
	const d = flip
		? `M ${x} ${y} q -34 -12 -46 -40 q 34 4 46 40 z`
		: `M ${x} ${y} q 34 -12 46 -40 q -34 4 -46 40 z`
	return `<path d="${d}" fill="${LEAF.mid}" ${fuzz(LEAF.dark, 2.5, "1 5")} />`
}

function wrap({ cx, baseY, width, palette }) {
	const p = PALETTES[palette] ?? PALETTES.kraft
	const half = width / 2
	return [
		`<path d="M ${cx - half} ${baseY - 210} L ${cx + half} ${baseY - 210} L ${cx + half * 0.34} ${baseY} L ${cx - half * 0.34} ${baseY} Z" fill="${p.light}" ${fuzz(p.dark, 3, "2 6")} />`,
		`<path d="M ${cx - half * 0.34} ${baseY - 70} L ${cx + half * 0.34} ${baseY - 70}" ${fuzz(p.dark, 4, "3 7")} />`,
	].join("")
}

function bouquetScene({ width, height, palettes, wrapPalette = "kraft", scale = 1 }) {
	const cx = width / 2
	const baseY = height * 0.86
	const blooms = []
	const count = Math.max(3, palettes.length * 2)
	for (let i = 0; i < count; i += 1) {
		const spread = (i - (count - 1) / 2) / Math.max(1, (count - 1) / 2)
		const bx = cx + spread * width * 0.24
		const by = height * 0.34 + Math.abs(spread) * height * 0.09
		const palette = palettes[i % palettes.length]
		blooms.push(stem({ x: bx, y: by + 20, toX: cx + spread * width * 0.06, toY: baseY - 40 }))
		blooms.push(
			bloom({
				cx: bx,
				cy: by,
				r: (width * 0.085 + (i % 2 === 0 ? 6 : 0)) * scale,
				palette,
				petals: i % 3 === 0 ? 5 : 6,
				rotate: i * 13,
			}),
		)
	}
	return [
		leaf({ x: cx - width * 0.16, y: height * 0.52 }),
		leaf({ x: cx + width * 0.16, y: height * 0.5, flip: true }),
		blooms.join(""),
		wrap({ cx, baseY, width: width * 0.52, palette: wrapPalette }),
	].join("")
}

function frame({ width, height, body, background = CREAM, radius = 32 }) {
	return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}" role="img">
<rect width="${width}" height="${height}" rx="${radius}" fill="${background}" />
<rect x="6" y="6" width="${width - 12}" height="${height - 12}" rx="${radius - 6}" fill="none" stroke="${SAND}" stroke-width="2" />
${body}
</svg>`
}

function productImage(slug, palettes, variant) {
	const width = 600
	const height = 750
	const wrapPalette = palettes.includes("kraft") ? "kraft" : variant === 3 ? "sage" : "tulip"

	if (variant === 2) {
		// Close-up of a single bloom.
		const body = [
			`<circle cx="300" cy="340" r="210" fill="${PALETTES[palettes[0]].light}" />`,
			stem({ x: 300, y: 400, toX: 300, toY: 660 }),
			leaf({ x: 300, y: 560 }),
			bloom({ cx: 300, cy: 320, r: 150, palette: palettes[0], petals: 7 }),
			`<text x="300" y="706" text-anchor="middle" font-family="system-ui, sans-serif" font-size="20" fill="${INK_MUTED}">Pipe Cleaner Handmade</text>`,
		].join("")
		return frame({ width, height, body, background: IVORY })
	}

	if (variant === 3) {
		// Flat-lay with a greeting card.
		const body = [
			`<rect x="90" y="430" width="420" height="230" rx="22" fill="${IVORY}" stroke="${SAND}" stroke-width="3" />`,
			`<path d="M 130 486 h 200 M 130 528 h 260 M 130 570 h 150" ${fuzz(SAND, 6, "4 10")} />`,
			bouquetScene({ width, height: 620, palettes, wrapPalette, scale: 0.82 }),
			`<text x="300" y="706" text-anchor="middle" font-family="system-ui, sans-serif" font-size="20" fill="${INK_MUTED}">${slug}</text>`,
		].join("")
		return frame({ width, height, body })
	}

	return frame({
		width,
		height,
		body: bouquetScene({ width, height, palettes, wrapPalette }),
	})
}

let count = 0

for (const [slug, palettes] of Object.entries(PRODUCTS)) {
	for (const variant of [1, 2, 3]) {
		write(`products/${slug}-${variant}.svg`, productImage(slug, palettes, variant))
		count += 1
	}
}

for (const [slug, palettes] of Object.entries(CATEGORIES)) {
	write(
		`categories/${slug}.svg`,
		frame({
			width: 640,
			height: 512,
			background: PALETTES[palettes[0]].light,
			body: bouquetScene({ width: 640, height: 512, palettes, wrapPalette: "kraft", scale: 0.9 }),
		}),
	)
	count += 1
}

for (const slug of FLOWERS) {
	write(
		`flowers/${slug}.svg`,
		frame({
			width: 240,
			height: 240,
			radius: 24,
			background: IVORY,
			body: [
				stem({ x: 120, y: 140, toX: 120, toY: 214 }),
				leaf({ x: 120, y: 186 }),
				bloom({ cx: 120, cy: 108, r: 62, palette: slug, petals: slug === "gypsophila" ? 8 : 6 }),
			].join(""),
		}),
	)
	count += 1
}

const GALLERY = ["tulip", "lavender", "sunflower", "peony", "daisy", "sage"]
GALLERY.forEach((palette, index) => {
	write(
		`gallery/g${index + 1}.svg`,
		frame({
			width: 420,
			height: 420,
			radius: 28,
			background: PALETTES[palette].light,
			body: bouquetScene({
				width: 420,
				height: 420,
				palettes: [palette, GALLERY[(index + 2) % GALLERY.length]],
				wrapPalette: index % 2 === 0 ? "kraft" : "sage",
				scale: 0.9,
			}),
		}),
	)
	count += 1
})

write(
	"hero-bouquet.svg",
	frame({
		width: 900,
		height: 760,
		radius: 48,
		background: IVORY,
		body: [
			`<circle cx="450" cy="330" r="290" fill="${PALETTES.tulip.light}" />`,
			bouquetScene({
				width: 900,
				height: 760,
				palettes: ["tulip", "rose", "peony", "lavender"],
				wrapPalette: "kraft",
			}),
		].join(""),
	}),
)
count += 1

write(
	"custom-bouquet.svg",
	frame({
		width: 760,
		height: 620,
		radius: 40,
		background: PALETTES.sage.light,
		body: [
			bouquetScene({
				width: 760,
				height: 620,
				palettes: ["lavender", "daisy", "sunflower", "peony"],
				wrapPalette: "sage",
			}),
			`<rect x="470" y="90" width="210" height="140" rx="18" fill="${IVORY}" stroke="${SAND}" stroke-width="3" />`,
			`<path d="M 500 140 h 150 M 500 172 h 110" ${fuzz(SAND, 6, "4 10")} />`,
		].join(""),
	}),
)
count += 1

console.log(`generated ${count} svg files in public/`)
