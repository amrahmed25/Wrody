/**
 * Promotes an existing Supabase Auth user to the `admin` role.
 *
 * Usage:  npm run admin:promote -- you@example.com
 *
 * The `profiles.role` column is protected by the `protect_profile_role()`
 * trigger, so a customer can never escalate their own role through the API.
 * This script uses the service-role key and therefore must only ever run
 * locally or in a trusted CI environment — never in the browser.
 */
import { createClient } from "@supabase/supabase-js"

const email = process.argv[2]
const url = process.env.NEXT_PUBLIC_SUPABASE_URL
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY

if (!email) {
	console.error("Usage: npm run admin:promote -- you@example.com")
	process.exit(1)
}

if (!url || !serviceRoleKey) {
	console.error("Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY (check .env.local).")
	process.exit(1)
}

const admin = createClient(url, serviceRoleKey, {
	auth: { autoRefreshToken: false, persistSession: false },
})

const { data, error } = await admin
	.from("profiles")
	.update({ role: "admin" })
	.eq("email", email)
	.select("id, email, role")

if (error) {
	console.error(`Failed: ${error.message}`)
	process.exit(1)
}

if (!data || data.length === 0) {
	console.error(`No profile found for ${email}. Register the account in the app first.`)
	process.exit(1)
}

console.log(`Done. ${email} is now an admin.`)
